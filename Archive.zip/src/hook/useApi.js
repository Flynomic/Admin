import axios from "axios";
import { BASE_URL } from "../utils/constant";
import { getErrorsList, getHeaders } from "../utils/helper";
// rahul
const useApi = () => {
  const AsyncGetApiCall = async (endpoint, query) => {
    try {
      const url = BASE_URL + endpoint;
      console.log("url : ", url);

      const response = await axios.get(url, {
        params: query,
        headers: getHeaders(),
      });
      return response?.data;
    } catch (error) {
      const errors = await getErrorsList(error?.response?.data?.message);
      return { errors };
    }
  };

  const AsyncPutApiCall = async (endpoint, data) => {
    try {
      const url = BASE_URL + endpoint;
      console.log("url is : ", url);

      const response = await axios.put(url, data, { headers: getHeaders() });
      return response?.data;
    } catch (error) {
      const errors = await getErrorsList(error?.response?.data?.message);
      return { errors };
    }
  };

  const AsyncPatchAPICall = async (endpoint, data) => {
    try {
      const url = BASE_URL + endpoint;
      const response = await axios.patch(url, data, { headers: getHeaders() });
      return response?.data;
    } catch (error) {
      const errors = await getErrorsList(error?.response?.data?.message);
      return { errors };
    }
  };

  const AsyncPostApiCall = async (endpoint, data) => {
    try {
      const url = BASE_URL + endpoint;
      console.log("url is : ", url);

      const response = await axios.post(url, data, { headers: getHeaders() });
      return response?.data;
    } catch (error) {
      const errors = await getErrorsList(error?.response?.data?.message);
      return { errors };
    }
  };

  const AsyncDeleteApiCall = async (endpoint, data) => {
    try {
      const url = BASE_URL + endpoint;
      console.log("url is : ", url);

      const response = await axios.delete(url, {
        data,
        headers: getHeaders(),
      });
      return response?.data;
    } catch (error) {
      const errors = await getErrorsList(error?.response?.data?.message);
      return { errors };
    }
  };

  return {
    AsyncGetApiCall,
    AsyncPatchAPICall,
    AsyncPutApiCall,
    AsyncPostApiCall,
    AsyncDeleteApiCall,
  };
};

export default useApi;
