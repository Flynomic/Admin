import React from "react";
import MasterLayout from "../../masterLayout/MasterLayout";
import Breadcrumb from "../../components/Breadcrumb";
import ReviewLayer from "./ReviewLayer";

const ReviewPage = () => {
  return (
    <>
      {/* MasterLayout */}
      <MasterLayout>
        {/* Breadcrumb */}
        <Breadcrumb title="Review & Rating Management" />

        <ReviewLayer />
      </MasterLayout>
    </>
  );
};

export default ReviewPage;
