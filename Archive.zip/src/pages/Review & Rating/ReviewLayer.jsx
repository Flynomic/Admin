import { Icon } from "@iconify/react/dist/iconify.js";
import React, { useEffect, useState } from "react";
import useApi from "../../hook/useApi";
import { toast } from "react-toastify";
import Paggination from "../../components/Paggination";
import Loader from "../../components/Loader/Loader";
import ReviewModal from "./ReviewModal";

const ReviewLayer = () => {
  const { AsyncGetApiCall, AsyncDeleteApiCall } = useApi();
  const [loading, setLoading] = useState(false);
  const [query, setQuery] = useState({
    pageNo: 1,
    limitVal: 50,
    search: "",
    sortOrder: "", // Default: newest first
  });
  const [data, setData] = useState({
    data: [],
    total: 0,
    totalPages: 0,
    currentPage: 1,
  });
  const [showModal, setShowModal] = useState(false);
  const [selectedReview, setSelectedReview] = useState(null);

  // Fetch all reviews based on query parameters
  const getAllReviewsList = async () => {
    setLoading(true);
    try {
      const result = await AsyncGetApiCall("/reviews/list", {
        pageNo: query.pageNo,
        limitVal: query.limitVal,
        search: query.search,
        sortOrder: query.sortOrder, // Pass sortOrder to backend
      });
      if (result.success) {
        setData({
          data: result.data || [],
          total: result.pagination?.total || 0,
          totalPages: result.pagination?.totalPages || 0,
          currentPage: result.pagination?.currentPage || 1,
        });
      } else {
        toast.error(result.errors?.[0] || "Failed to fetch reviews");
      }
    } catch (error) {
      console.error("Error fetching reviews:", error);
      toast.error("An error occurred while fetching reviews");
    } finally {
      setLoading(false);
    }
  };

  // Update page number
  const setPageNo = (pageNo) => {
    setQuery((prev) => ({
      ...prev,
      pageNo,
    }));
  };

  // Handle sort order change
  const handleSortOrderChange = (e) => {
    const sortOrder = e.target.value;
    setQuery((prev) => ({
      ...prev,
      sortOrder,
      pageNo: 1, // Always reset to first page on sort change
    }));
  };

  // Handle view action
  const handleView = (id) => {
    if (!id) {
      toast.info("Please select a review to view");
      return;
    }
    const review = data.data.find((item) => item._id === id);
    if (!review) {
      toast.error("Review not found");
      return;
    }
    setSelectedReview(review);
    setShowModal(true);
  };

  // Delete review
  const deleteReview = async (id) => {
    if (!window.confirm("Are you sure you want to delete this Review?")) return;
    setLoading(true);
    try {
      const result = await AsyncDeleteApiCall(`/reviews/${id}`);
      if (result.success) {
        toast.success("Review deleted successfully");
        getAllReviewsList();
      } else {
        toast.error(result.errors?.[0] || "Failed to delete review");
      }
    } catch (error) {
      console.error("Error deleting review:", error);
      toast.error("An error occurred while deleting the review");
    } finally {
      setLoading(false);
    }
  };

  // Fetch reviews on query change
  useEffect(() => {
    getAllReviewsList();
  }, [query.pageNo, query.limitVal, query.search, query.sortOrder]);

  return (
    <div className="card h-100 p-0 radius-12">
      {loading && <Loader />}
      <div className="card-header border-bottom bg-base py-16 px-24 d-flex align-items-center flex-wrap gap-3 justify-content-between">
        <div className="d-flex align-items-center flex-wrap gap-3">
          <span className="text-md fw-medium text-secondary-light mb-0">
            Show
          </span>
          <select
            className="form-select form-select-sm w-auto ps-12 py-6 radius-12 h-40-px"
            value={query.limitVal}
            onChange={(e) => {
              const value = parseInt(e.target.value, 10);
              setQuery((prev) => ({
                ...prev,
                limitVal: value,
                pageNo: 1, // Reset to first page on limit change
              }));
            }}>
            {Array.from({ length: 20 }, (_, i) => {
              const value = (i + 1) * 5;
              return (
                <option key={value} value={value}>
                  {value}
                </option>
              );
            })}
          </select>
          <span className="text-md fw-medium text-secondary-light mb-0">
            Sort by
          </span>
          <select
            className="form-select form-select-sm w-auto ps-12 py-6 radius-12 h-40-px"
            value={query.sortOrder}
            onChange={handleSortOrderChange}
            aria-label="Sort reviews by creation date">
            <option value="DESC">Newest</option>
            <option value="ASC">Oldest</option>
          </select>
          <form className="navbar-search">
            <input
              type="text"
              className="bg-base h-40-px w-auto"
              name="search"
              placeholder="Search by user name, hotel code, hotel name"
              value={query.search}
              onChange={(e) => {
                setQuery((prev) => ({
                  ...prev,
                  search: e.target.value,
                  pageNo: 1, // Reset to first page on search
                }));
              }}
            />
            <Icon icon="ion:search-outline" className="icon" />
          </form>
        </div>
      </div>
      <div className="card-body p-24">
        <div className="table-responsive scroll-sm">
          <table className="table bordered-table sm-table mb-0">
            <thead>
              <tr>
                <th scope="col">
                  <div className="d-flex align-items-center gap-10">S.No</div>
                </th>
                <th scope="col">Created Date</th>
                <th scope="col">Full Name</th>
                <th scope="col">Hotel Code</th>
                <th scope="col">Hotel</th>
                <th scope="col">Rating</th>
                <th scope="col">Description</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              {data?.data?.length > 0 ? (
                data.data.map((item, index) => (
                  <tr key={item?._id}>
                    <td>
                      <div className="d-flex align-items-center gap-10">
                        {(data.currentPage - 1) * query.limitVal + index + 1}
                      </div>
                    </td>
                    <td>{new Date(item?.createdAt).toLocaleDateString()}</td>
                    <td>
                      {item?.userId?.firstName || item?.userId?.lastName
                        ? `${item?.userId?.firstName || ""} ${item?.userId?.lastName || ""
                          }`.trim()
                        : "N/A"}
                    </td>
                    <td>{item?.hotelCode ?? "N/A"}</td>
                    <td>
                      {item?.bookingId?.hotelBookings?.hotel?.name &&
                        item?.bookingId?.hotelBookings?.hotel?.destinationName
                        ? `${item?.bookingId?.hotelBookings?.hotel?.name}, ${item?.bookingId?.hotelBookings?.hotel?.destinationName}`
                        : "N/A"}
                    </td>
                    <td>{item?.rating}</td>
                    <td>
                      {item?.reviewData?.length > 10
                        ? `${item?.reviewData.slice(0, 10)}...`
                        : item?.reviewData || "N/A"}
                    </td>
                    <td className="text-center d-flex gap-1">
                      <button
                        type="button"
                        className="bg-info-focus bg-hover-info-200 text-info-600 fw-medium w-40-px h-40-px d-flex justify-content-center align-items-center rounded-circle"
                        onClick={() => handleView(item?._id)}>
                        <Icon
                          icon="majesticons:eye-line"
                          className="icon text-xl"
                        />
                        <span className="tooltip-text">View</span>
                      </button>
                      <button
                        type="button"
                        className="remove-item-btn bg-danger-focus bg-hover-danger-200 text-danger-600 fw-medium w-40-px h-40-px d-flex justify-content-center align-items-center rounded-circle"
                        onClick={() =>
                          deleteReview(item?._id)
                        }
                      >
                        <Icon
                          icon="fluent:delete-24-regular"
                          className="menu-icon"
                        />
                        <span className="tooltip-text">Delete</span>
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="8" className="text-center">
                    No data found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <Paggination
          total={data.total}
          totalPages={data.totalPages}
          currentPage={data.currentPage}
          setPageNo={setPageNo}
          startFrom={(data.currentPage - 1) * query.limitVal + 1}
          endTo={(data.currentPage - 1) * query.limitVal + data.data.length}
        />
        {showModal && (
          <ReviewModal
            show={showModal}
            handleClose={() => {
              setShowModal(false);
              setSelectedReview(null);
            }}
            review={selectedReview}
          />
        )}
      </div>
    </div>
  );
};

export default ReviewLayer;
