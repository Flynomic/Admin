import React from "react";
import { Modal, Button } from "react-bootstrap";
import { IoCopyOutline } from "react-icons/io5";
import { copyToClipboard, trimAddress } from "../../utils/helper";

const ReviewModal = ({ show, handleClose, review }) => {
  // Compute fullName
  const fullName =
    review?.userId?.firstName || review?.userId?.lastName
      ? `${review?.userId?.firstName || ""} ${review?.userId?.lastName || ""
        }`.trim()
      : "N/A";

  console.log("review", review);

  return (
    <Modal
      show={show}
      onHide={handleClose}
      className="custom-modal"
      animation={true}
    >
      <Modal.Header closeButton>
        <Modal.Title className="modal-title-lg">View Review</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <div>
          <div className="mb-3">
            <strong className="d-inline-block" style={{ width: "150px" }}>
              Full Name:
            </strong>{" "}
            {fullName}
          </div>
          <div className="mb-3">
            <strong className="d-inline-block" style={{ width: "150px" }}>
              Email:
            </strong>{" "}
            {review?.userId?.email || "N/A"}
          </div>
          <div className="mb-3">
            <strong className="d-inline-block" style={{ width: "150px" }}>
              Wallet Address:
            </strong>{" "}
            {trimAddress(review?.userId?.walletAddress, 10, 8) || "N/A"}
            {review?.userId?.walletAddress && (
              <button
                onClick={() => copyToClipboard(review.userId.walletAddress)}
                className="ms-3 p-0 border-0 bg-transparent"
                style={{ lineHeight: 1 }}
              >
                <IoCopyOutline />
              </button>
            )}
          </div>
          <div className="mb-3">
            <strong className="d-inline-block" style={{ width: "150px" }}>
              Booking ID:
            </strong>{" "}
            {trimAddress(review?.bookingId?._id, 5, 5) || "N/A"}
            {review?.bookingId?._id && (
              <button
                onClick={() => copyToClipboard(review.bookingId?._id)}
                className="ms-3 p-0 border-0 bg-transparent"
                style={{ lineHeight: 1 }}
              >
                <IoCopyOutline />
              </button>
            )}
          </div>
          <div className="mb-3">
            <strong className="d-inline-block" style={{ width: "150px" }}>
              Hotel Code:
            </strong>{" "}
            {review.hotelCode || "N/A"}
          </div>
          <div className="mb-3">
            <strong className="d-inline-block" style={{ width: "150px" }}>
              Hotel Name:
            </strong>{" "}
            {`${review.bookingId?.hotelBookings?.hotel.name}, ${review.bookingId?.hotelBookings?.hotel.destinationName}` ||
              "N/A"}
          </div>
          <div className="mb-3">
            <strong className="d-inline-block" style={{ width: "150px" }}>
              Rating:
            </strong>{" "}
            {review?.rating || "N/A"}
          </div>
          <div className="mb-3">
            <strong className="d-inline-block" style={{ width: "150px" }}>
              Description:
            </strong>{" "}
            <div
              style={{
                maxHeight: "150px",
                overflowY: "auto",
                border: "1px solid #dee2e6",
                borderRadius: "4px",
                padding: "8px",
                wordBreak: "break-word",
                display: "inline-block",
                verticalAlign: "top",
                maxWidth: "calc(100% - 130px)",
              }}
            >
              {review?.reviewData || "N/A"}
            </div>
          </div>
          <div className="mb-3">
            <strong className="d-inline-block" style={{ width: "150px" }}>
              Created At:
            </strong>{" "}
            {review?.createdAt
              ? new Date(review.createdAt).toLocaleDateString("en-GB", {
                day: "2-digit",
                month: "short",
                year: "numeric",
              })
              : "N/A"}
          </div>
        </div>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="danger" onClick={handleClose}>
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default ReviewModal;
