import React from "react";
import MasterLayout from "../../../masterLayout/MasterLayout";
import Breadcrumb from "../../../components/Breadcrumb";
import PromotionalUpdateLayer from "./PromotionalUpdateLayer";

const PromotionalUpdatePage = () => {
  return (
    <div>
      <MasterLayout>
        <Breadcrumb title="Promotional Campaigns Details" />
        <PromotionalUpdateLayer />
      </MasterLayout>
    </div>
  );
};

export default PromotionalUpdatePage;
