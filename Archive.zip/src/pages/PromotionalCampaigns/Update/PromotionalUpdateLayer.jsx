import React, { useState, useEffect } from "react";
import useApi from "../../../hook/useApi";
import { toast } from "react-toastify";
import { CATEGORY } from "../../../utils/enum";
import axios from "axios";
import { getHeaders } from "../../../utils/helper";
import { BASE_URL } from "../../../utils/constant";
import { useNavigate, useParams } from "react-router-dom";
import Loader from "../../../components/Loader/Loader";
import validator from "validator";

// Dummy logo for preview
const DUMMY_LOGO =
  "https://ui-avatars.com/api/?name=Logo&background=eee&color=666&size=120";

// Ad types (sync with backend AD_TYPE enum)
const AD_TYPES = [
  {
    key: "leaderboard",
    label: "Leaderboard (max 20mb) (728x90)",
    frame: "/assets/images/ads/Leaderboard.png",
  },
  {
    key: "largeLeaderboard",
    label: "Large Leaderboard (max 20mb) (970x90)",
    frame: "/assets/images/ads/Leaderboard.png",
  },
  {
    key: "skyscraper",
    label: "Skyscraper (max 20mb) (120x300)",
    frame: "/assets/images/ads/Skyscraper.png",
  },
  {
    key: "wideSkyscraper",
    label: "Wide Skyscraper (max 20mb) (160x600)",
    frame: "/assets/images/ads/Wide Skyscraper.png",
  },
];

const PromotionalUpdateLayer = () => {
  const { AsyncGetApiCall } = useApi();
  const { id } = useParams();
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [errors, setErrors] = useState({}); // State for validation errors

  // Form state
  const [formData, setFormData] = useState({
    category: "",
    title: "",
    altText: "",
    website: "",
    logo: null,
    ads: {},
    active: false,
  });

  // File previews
  const [previewLogo, setPreviewLogo] = useState(null);
  const [previewAds, setPreviewAds] = useState({});

  // Fetch promotional item
  const fetchPromotionalItem = async () => {
    setLoading(true);
    try {
      const result = await AsyncGetApiCall(`/promotional/${id}`);
      if (result.success) {
        const promo = result.promotional;
        const adsData = {};
        AD_TYPES.forEach(({ key }) => {
          if (promo.ads?.[key]) adsData[key] = promo.ads[key];
        });
        setData({ ...promo, id: promo._id });
        setFormData({
          category: promo.category || "",
          title: promo.title || "",
          altText: promo.altText || "",
          website: promo.website || "",
          logo: promo.logo || null,
          ads: adsData,
          active: promo.active || false,
        });

        console.log("promo", promo)
        setPreviewLogo(promo.logo || null);
        setPreviewAds(adsData);
      } else {
        toast.error(result.errors?.[0] || "Failed to fetch promotional item");
      }
    } catch (error) {
      toast.error("Failed to fetch promotional item");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (id) fetchPromotionalItem();
    // eslint-disable-next-line
  }, [id]);

  // Reset form and previews when entering edit mode
  useEffect(() => {
    if (isEditing && data) {
      const adsData = {};
      AD_TYPES.forEach(({ key }) => {
        if (data.ads?.[key]) adsData[key] = data.ads[key];
      });
      setFormData({
        category: data.category || "",
        title: data.title || "",
        altText: data.altText || "",
        website: data.website || "",
        logo: data.logo || null,
        ads: adsData,
        active: data.active || false,
      });
      setPreviewLogo(data.logo || null);
      setPreviewAds(adsData);
      setErrors({});
    }
  }, [isEditing, data]);

  const validationErrors = (name, value) => {
    const newErrors = { ...errors };
    if (name === "title" && !value.trim()) {
      newErrors.title = "Title is required";
    } else if (name === "title" && value.trim()) {
      if (value.length > 100) {
        newErrors.title = "Title must not exceed 100 characters";
      } else {
        delete newErrors.title;
      }
    }
    if (name === "category" && !value) {
      newErrors.category = "Category is required";
    } else if (name === "category" && value) {
      delete newErrors.category;
    }
    if (name === "website" && !value.trim()) {
      newErrors.website = "Website is required";
    } else if (name === "website" && value.trim()) {
      if (value.length > 100) {
        newErrors.website = "Website must not exceed 100 characters";
      } else if (!validator.isURL(value.trim())) {
        newErrors.website = "Website url is not valid";
      } else {
        delete newErrors.website;
      }
    }
    if (name === "altText" && !value.trim()) {
      newErrors.altText = "Alt Text is required";
    } else if (name === "altText" && value.trim()) {
      if (value.length > 200) {
        newErrors.altText = "Alt Text must not exceed 200 characters";
      } else {
        delete newErrors.altText;
      }
    }

    return newErrors
  }

  // Real-time validation for input fields
  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? (checked ? true : prev[name]) : value,
    }));

    const updatedErros = validationErrors(name, value)
    setErrors(updatedErros);
  };

  // Logo upload with validation
  const handleLogoChange = (e) => {
    const file = e.target.files[0];
    const newErrors = { ...errors };
    const maxSizeMB = 20; // 20 MB limit
    const maxSizeBytes = maxSizeMB * 1024 * 1024; // Convert to bytes

    const validExtensions = ['jpg', 'jpeg', 'png', 'gif'];
    const fileExtension = file?.name.split('.').pop().toLowerCase();

    if (!file) {
      newErrors.logo = "Logo image is required";
    } else if (!['image/png', 'image/jpeg', 'image/jpg', 'image/gif'].includes(file.type) || !validExtensions.includes(fileExtension)) {
      newErrors.logo = "Logo image must be a PNG, JPEG, JPG, or GIF";
    } else if (file.size > maxSizeBytes) {
      newErrors.logo = `Logo image must not exceed ${maxSizeMB} MB`;
    } else {
      delete newErrors.logo;
    }
    setFormData((prev) => ({ ...prev, logo: file }));
    setPreviewLogo(file ? URL.createObjectURL(file) : previewLogo);
    setErrors(newErrors);
    e.target.value = null;
  };

  // Ad banner upload with validation
  const handleAdBannerChange = (adType, e) => {
    const file = e.target.files[0];
    const newErrors = { ...errors };
    const maxSizeMB = 20; // 20 MB limit
    const maxSizeBytes = maxSizeMB * 1024 * 1024; // Convert to bytes

    const validExtensions = ['jpg', 'jpeg', 'png', 'gif'];
    const fileExtension = file?.name.split('.').pop().toLowerCase();

    if (!file) {
      newErrors[adType] = `${adType.charAt(0).toUpperCase() + adType.slice(1)} image is required`;
    } else if (!['image/png', 'image/jpeg', 'image/jpg', 'image/gif'].includes(file.type) || !validExtensions.includes(fileExtension)) {
      newErrors[adType] = `${adType.charAt(0).toUpperCase() + adType.slice(1)} image must be a PNG, JPEG, JPG, or GIF`;
    } else if (file.size > maxSizeBytes) {
      newErrors[adType] = `${adType.charAt(0).toUpperCase() + adType.slice(1)} image must not exceed ${maxSizeMB} MB`;
    } else {
      delete newErrors[adType];
    }
    setFormData((prev) => ({
      ...prev,
      ads: { ...prev.ads, [adType]: file },
    }));
    setPreviewAds((prev) => ({
      ...prev,
      [adType]: file ? URL.createObjectURL(file) : prev[adType],
    }));
    setErrors(newErrors);
  };

  // Submit handler with final validation
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrors({});
    console.log("formData", formData)

    const validExtensions = ['jpg', 'jpeg', 'png', 'gif']; // Define validExtensions here

    // Final validation using validationErrors function
    const newErrors = validationErrors("title", formData.title);
    Object.assign(newErrors, validationErrors("category", formData.category));
    Object.assign(newErrors, validationErrors("website", formData.website));
    Object.assign(newErrors, validationErrors("altText", formData.altText));

    // Handle logo validation
    if (!formData?.logo) {
      newErrors.logo = "Logo image is required";
    } else {
      delete newErrors.logo; // Clear any previous logo error if valid
    }

    // Validate that all ad types are provided
    AD_TYPES.forEach(({ key }) => {
      if (!data?.ads?.[key]) {
        newErrors[key] = `${key} image is required`;
      }
    });

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      setLoading(false);
      return;
    }

    const dataToSend = new FormData();
    dataToSend.append("category", formData.category);
    dataToSend.append("title", formData.title);
    dataToSend.append("altText", formData.altText);
    dataToSend.append("website", formData.website);
    dataToSend.append("active", formData.active.toString());
    if (formData.logo) dataToSend.append("logo", formData.logo);
    Object.entries(formData.ads).forEach(([adType, file]) => {
      if (file) dataToSend.append(adType, file);
    });

    try {
      const response = await axios.patch(
        `${BASE_URL}/promotional/update/${id}`,
        dataToSend,
        {
          headers: { ...getHeaders(), "Content-Type": "multipart/form-data" },
        }
      );

      if (response.data.success) {
        toast.success("Promotional updated successfully");
        await fetchPromotionalItem();
        setIsEditing(false);
        setFormData((prev) => ({ ...prev }));
        setPreviewAds({});
        setErrors({});
        navigate("/promotional-campaigns");
      } else {
        setErrors({
          general: response.data.message || "Failed to update promotional",
        });
      }
    } catch (error) {
      const errorMessage =
        error.response?.data?.message ||
        error.response?.data?.errors?.[0] ||
        error.message ||
        "Failed to update promotional";
      setErrors({ general: errorMessage });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {loading && <Loader />}
      <div className="col-md-12">
        <div className="card">
          <div className="card-header">
            <h5 className="card-title mb-0">Promotional Campaign Details</h5>
          </div>
          <div className="card-body">
            {isEditing ? (
              <form onSubmit={handleSubmit}>
                <div className="row gy-3 mb-3">
                  {/* Category */}
                  <div className="col-6">
                    <label className="form-label">
                      Category <span className="text-danger">*</span>
                    </label>
                    <select
                      className="form-control"
                      name="category"
                      value={formData.category}
                      onChange={handleInputChange}>
                      <option value="">Select Category</option>
                      {Object.values(CATEGORY).map((value) => (
                        <option key={value} value={value}>
                          {value.charAt(0).toUpperCase() + value.slice(1)}
                        </option>
                      ))}
                    </select>
                    {errors.category && (
                      <div className="text-danger small mt-1">
                        {errors.category}
                      </div>
                    )}
                  </div>
                  {/* Website */}
                  <div className="col-6">
                    <label className="form-label">
                      Website <span className="text-danger">*</span>
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      name="website"
                      value={formData.website}
                      onChange={handleInputChange}
                    />
                    {errors.website && (
                      <div className="text-danger small mt-1">
                        {errors.website}
                      </div>
                    )}
                  </div>
                  {/* Active Status Checkbox */}
                  <div className="col-6">
                    <label className="form-label">Active Status</label>
                    <div className="form-check">
                      <input
                        type="checkbox"
                        id="checkbox-1"
                        className="form-check-input"
                        name="active"
                        checked={formData.active}
                        onChange={handleInputChange}
                      />
                      <label className="form-check-label">
                        Activate Promotion
                      </label>
                    </div>
                  </div>
                  {/* Title */}
                  <div className="col-6">
                    <label className="form-label">
                      Title <span className="text-danger">*</span>
                    </label>
                    <input
                      className="form-control"
                      name="title"
                      value={formData.title}
                      onChange={handleInputChange}
                    />
                    {errors.title && (
                      <div className="text-danger small mt-1">
                        {errors.title}
                      </div>
                    )}
                  </div>
                  {/* Alt Text */}
                  <div className="col-12">
                    <label className="form-label">
                      Alt Text <span className="text-danger">*</span>
                    </label>
                    <input
                      className="form-control"
                      name="altText"
                      value={formData.altText}
                      onChange={handleInputChange}
                    />
                    {errors.altText && (
                      <div className="text-danger small mt-1">
                        {errors.altText}
                      </div>
                    )}
                  </div>
                  {/* Logo */}
                  <div className="col-12">
                    <label className="form-label mb-2 d-block">
                      Logo (max 20mb)<span className="text-danger">*</span>
                    </label>
                    <div
                      style={{
                        width: 120,
                        height: 120,
                        position: "relative",
                        border: "2px dashed #e0e0e0",
                        borderRadius: "12px",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        background: "#fafafd",
                        cursor: "pointer",
                        transition: "border-color 0.2s",
                      }}
                      className="logo-upload-frame mb-2"
                      onClick={() =>
                        document.getElementById("logo-upload-input").click()
                      }
                      onMouseEnter={(e) =>
                        (e.currentTarget.style.borderColor = "#bdbdbd")
                      }
                      onMouseLeave={(e) =>
                        (e.currentTarget.style.borderColor = "#e0e0e0")
                      }>
                      <img
                        src={previewLogo || DUMMY_LOGO}
                        alt="Logo Preview"
                        className="rounded"
                        style={{
                          width: "80px",
                          height: "80px",
                          objectFit: "contain",
                          opacity: previewLogo ? 1 : 0,
                        }}
                      />
                      <input
                        id="logo-upload-input"
                        type="file"
                        accept="image/*"
                        style={{ display: "none" }}
                        onChange={handleLogoChange}
                      />
                      {!previewLogo && (
                        <span
                          style={{
                            position: "absolute",
                            bottom: 6,
                            left: 0,
                            right: 0,
                            textAlign: "center",
                            fontSize: "0.88em",
                            color: "#888",
                            background: "rgba(255,255,255,0.7)",
                            padding: "1px 0 0 0",
                          }}>
                          Click to upload
                        </span>
                      )}
                    </div>
                    {errors.logo && (
                      <div className="text-danger small mt-1">
                        {errors.logo}
                      </div>
                    )}
                  </div>
                  {/* Ad Banners */}
                  <div className="row g-4">
                    {AD_TYPES.map(({ key, label, frame }) => (
                      <div className="col-md-6 col-lg-3" key={key}>
                        <label className="form-label mb-2 d-block text-center">
                          {label} <span className="text-danger">*</span>
                        </label>
                        <div
                          style={{
                            position: "relative",
                            cursor: "pointer",
                            border: "2px solid #e0e0e0",
                            borderRadius: "8px",
                            background: "#fafafd",
                            padding: "10px",
                            textAlign: "center",
                            transition: "border 0.2s",
                            height: "auto",
                          }}
                          className="ad-banner-upload-frame"
                          onClick={() =>
                            document
                              .getElementById(`banner-upload-${key}`)
                              .click()
                          }>
                          {previewAds[key] ? (
                            <img
                              src={previewAds[key]}
                              alt={label}
                              style={{
                                width: "100%",
                                maxHeight: "140px",
                                objectFit: "contain",
                                borderRadius: "6px",
                              }}
                            />
                          ) : (
                            <img
                              src={frame}
                              alt={label}
                              style={{
                                width: "100%",
                                maxHeight: "140px",
                                opacity: 0.6,
                              }}
                            />
                          )}
                          <input
                            id={`banner-upload-${key}`}
                            type="file"
                            style={{ display: "none" }}
                            accept="image/*"
                            onChange={(e) => {
                              const file = e.target.files[0];
                              if (file) handleAdBannerChange(key, e);
                            }}
                          />
                          <div
                            style={{
                              position: "absolute",
                              left: "50%",
                              bottom: "8px",
                              transform: "translateX(-50%)",
                              background: "#fff",
                              padding: "2px 8px",
                              borderRadius: "12px",
                              fontSize: "0.95em",
                              color: "#757575",
                              boxShadow: "0 2px 8px rgba(0,0,0,0.05)",
                            }}>
                            <span>Upload</span>
                          </div>
                        </div>
                        {errors[key] && (
                          <div className="text-danger small mt-1 text-center">
                            {errors[key]}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
                {errors.general && (
                  <div className="text-danger small mt-2">{errors.general}</div>
                )}
                <div style={{ color: "red", fontSize: "12px" }}>
                  <div>* Only JPEG, JPG, PNG, and GIF files are allowed</div>
                  <div>* Logo is mandatory</div>
                </div>

                <div className="d-flex gap-2">
                  <button
                    type="submit"
                    className="btn btn-primary"
                    disabled={loading}>
                    {loading ? "Updating..." : "Update"}
                  </button>
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={() => {
                      setIsEditing(false);
                      setErrors({});
                      setFormData({
                        category: data?.category || "",
                        title: data?.title || "",
                        altText: data?.altText || "",
                        website: data?.website || "",
                        logo: null,
                        ads: data?.ads || {},
                        active: data?.active || false,
                      });
                      setPreviewLogo(data?.logo || null);
                      setPreviewAds(data?.ads || {});
                    }}>
                    Cancel
                  </button>
                </div>
              </form>
            ) : (
              <>
                {/* Readonly Details */}
                <div className="row gy-3 mb-3" role="group">
                  <div className="col-6">
                    <label className="form-label">ID</label>
                    <div className="form-control form-control-readonly">
                      {data?._id || "N/A"}
                    </div>
                  </div>
                  <div className="col-6">
                    <label className="form-label">Category</label>
                    <div className="form-control form-control-readonly">
                      {data?.category || ""}
                    </div>
                  </div>
                  <div className="col-6">
                    <label className="form-label">Title</label>
                    <div className="form-control form-control-readonly">
                      {data?.title || ""}
                    </div>
                  </div>
                  <div className="col-6">
                    <label className="form-label">Website</label>
                    <div className="form-control form-control-readonly">
                      {data?.website || ""}
                    </div>
                  </div>
                  <div className="col-6">
                    <label className="form-label">Alt Text</label>
                    <div className="form-control form-control-readonly">
                      {data?.altText || ""}
                    </div>
                  </div>
                  <div className="col-6">
                    <label className="form-label">Active Status</label>
                    <div className="form-control form-control-readonly">
                      {data?.active ? "Active" : "Inactive"}
                    </div>
                  </div>
                  <div className="col-12">
                    <label className="form-label">Logo</label>
                    <div className="image-preview">
                      {data?.logo ? (
                        <img
                          src={data.logo}
                          alt="Logo"
                          className="img-fluid rounded"
                          style={{ maxHeight: "150px" }}
                        />
                      ) : (
                        <p className="text-muted">No logo available</p>
                      )}
                    </div>
                  </div>
                  {/* Ad Banners */}
                  <div className="col-12">
                    <h6 className="text-sm fw-semibold mb-2">Ad Banners</h6>
                    <div className="row g-4">
                      {AD_TYPES.map(({ key, label }) => (
                        <div className="col-md-6 col-lg-3" key={key}>
                          <label className="form-label mb-2 d-block text-center">
                            {label}
                          </label>
                          <div
                            style={{
                              position: "relative",
                              border: "2px solid #e0e0e0",
                              borderRadius: "8px",
                              background: "#fafafd",
                              padding: "10px",
                              textAlign: "center",
                              height: "auto",
                            }}>
                            {data?.ads?.[key] ? (
                              <img
                                src={data.ads[key]}
                                alt={label}
                                style={{
                                  width: "100%",
                                  maxHeight: "140px",
                                  objectFit: "contain",
                                  borderRadius: "6px",
                                }}
                              />
                            ) : (
                              <p className="text-muted">No {label} available</p>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="mt-10">
                  <button
                    className="btn btn-primary"
                    onClick={() => setIsEditing(true)}>
                    Update Promotional
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default PromotionalUpdateLayer;
