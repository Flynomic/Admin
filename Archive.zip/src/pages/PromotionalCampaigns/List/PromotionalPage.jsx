import React from "react";
import MasterLayout from "../../../masterLayout/MasterLayout";
import Breadcrumb from "../../../components/Breadcrumb";
import PromotionalLayer from "./PromotionalLayer";

const PromotionalPage = () => {
  return (
    <>
      {/* MasterLayout */}
      <MasterLayout>
        {/* Breadcrumb */}
        <Breadcrumb title="Promotional Campaigns Management" />

        <PromotionalLayer />
      </MasterLayout>
    </>
  );
};

export default PromotionalPage;
