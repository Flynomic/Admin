import { Icon } from "@iconify/react";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import useApi from "../../../hook/useApi";
import { toast } from "react-toastify";
import Paggination from "../../../components/Paggination";
import PromotionalModal from "../CreateModal/PromotionalModal";
import Loader from "../../../components/Loader/Loader";

const PromotionalLayer = () => {
  const { AsyncGetApiCall, AsyncDeleteApiCall } = useApi();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [query, setQuery] = useState({ pageNo: 1, limitVal: 20, search: "" });
  const [data, setData] = useState({
    data: [],
    pagination: {
      total: 0,
      totalPages: 0,
      currentPage: 1,
      hasNextPage: false,
      hasPrevPage: false,
      limit: 20,
    },
  });
  const [showModal, setShowModal] = useState(false);

  // Fetch all promotional items
  const getAllPromotionalList = async () => {
    setLoading(true);
    const result = await AsyncGetApiCall("/promotional/list", query);
    if (result?.success) {
      setData({
        data: result.data || [],
        pagination: result.pagination || {
          total: 0,
          totalPages: 0,
          currentPage: 1,
          hasNextPage: false,
          hasPrevPage: false,
          limit: query.limitVal,
        },
      });
    } else {
      toast.error(result.errors?.[0] || "Failed to fetch promotional items");
    }
    setLoading(false);
  };

  // Delete promo
  const removePromotional = async (id) => {
    setLoading(true);
    try {
      const result = await AsyncDeleteApiCall(`/promotional/delete/${id}`);
      if (result.success) {
        toast.success("Promotional item deleted successfully");
        getAllPromotionalList();
      } else {
        toast.error(result.errors?.[0] || "Failed to delete promotional item");
      }
    } catch (error) {
      toast.error("An error occurred while deleting promotional item");
    }
    setLoading(false);
  };

  // Fetch promotional items on query change
  useEffect(() => {
    getAllPromotionalList();
    // eslint-disable-next-line
  }, [query]);

  const { data: promoData, pagination } = data;

  console.log("promoData", promoData);

  return (
    <div className="card h-100 p-0 radius-12">
      {loading && <Loader />}
      <div className="card-header border-bottom bg-base py-16 px-24 d-flex align-items-center flex-wrap gap-3 justify-content-between">
        <div className="d-flex align-items-center flex-wrap gap-3">
          <span className="text-md fw-medium text-secondary-light mb-0">
            Show
          </span>
          <select
            className="form-select form-select-sm w-auto ps-12 py-6 radius-12 h-40-px"
            value={query.limitVal}
            onChange={(e) =>
              setQuery((prev) => ({
                ...prev,
                limitVal: parseInt(e.target.value, 10),
                pageNo: 1,
              }))
            }>
            {[5, 10, 15, 20, 25, 30].map((v) => (
              <option key={v} value={v}>
                {v}
              </option>
            ))}
          </select>
          <div className="navbar-search">
            <input
              type="text"
              className="bg-base h-40-px w-auto"
              name="search"
              placeholder="Search"
              value={query.search}
              onChange={(e) =>
                setQuery((prev) => ({
                  ...prev,
                  search: e.target.value,
                  pageNo: 1,
                }))
              }
            />
            <Icon icon="ion:search-outline" className="icon" />
          </div>
        </div>
        <button
          type="button"
          className="btn btn-primary-600 radius-8 px-20 py-11 d-flex align-items-center gap-2"
          onClick={() => setShowModal(true)}
          disabled={loading}
          aria-label="Add new FAQ">
          <Icon
            icon="ic:baseline-plus"
            className="icon text-xl line-height-1"
          />
          Create Promotion
        </button>
      </div>
      <div className="card-body p-24">
        <div className="table-responsive scroll-sm">
          <table className="table bordered-table sm-table mb-0">
            <thead>
              <tr>
                <th>S.No</th>
                <th>Title</th>
                <th>Category</th>
                <th>Logo</th>
                <th>Alt Text</th>
                <th>Status</th>
                <th>Created Date</th>
                <th className="text-center">Action</th>
              </tr>
            </thead>
            <tbody>
              {promoData.length > 0 ? (
                promoData.map((item, index) => (
                  <tr key={item._id}>
                    <td>
                      {(pagination.currentPage - 1) * pagination.limit +
                        index +
                        1}
                    </td>
                    <td>{item?.title.length > 15 ? `${item?.title.slice(0, 15)}...` : item?.title || "N/A"}</td>
                    <td>{item.category || "N/A"}</td>
                    <td>
                      {item.logo ? (
                        <a href={item?.logo} target="_blank" rel="noopener noreferrer">
                          <img
                            src={item?.logo}
                            alt="logo"
                            style={{ width: 50, height: 50, objectFit: "cover" }}
                          />
                        </a>
                      ) : (
                        "N/A"
                      )}
                    </td>
                    <td>{item?.altText.length > 15 ? `${item?.altText.slice(0, 15)}...` : item?.altText || "N/A"}</td>
                    <td>
                      {item.active ? (
                        <span className="badge bg-success">Active</span>
                      ) : (
                        <span className="badge bg-secondary">Inactive</span>
                      )}
                    </td>
                    <td>{new Date(item.createdAt).toLocaleDateString()}</td>
                    <td className="text-center">
                      <div className="d-flex align-items-center gap-10 justify-content-center">
                        <button
                          type="button"
                          className="bg-success-focus text-success-600 bg-hover-success-200 fw-medium w-40-px h-40-px d-flex justify-content-center align-items-center rounded-circle"
                          onClick={() =>
                            navigate(
                              `/promotional-campaigns/details/${item._id}`
                            )
                          }>
                          <Icon icon="lucide:edit" className="menu-icon" />
                          <span className="tooltip-text">Edit</span>
                        </button>
                        {!item.active &&
                          <button
                            type="button"
                            className="remove-item-btn bg-danger-focus bg-hover-danger-200 text-danger-600 fw-medium w-40-px h-40-px d-flex justify-content-center align-items-center rounded-circle"
                            onClick={() => {
                              if (
                                window.confirm(
                                  "Do you want to delete this promotional item?"
                                )
                              ) {
                                removePromotional(item._id);
                              }
                            }}>
                            <Icon
                              icon="fluent:delete-24-regular"
                              className="menu-icon"
                            />
                            <span className="tooltip-text">Delete</span>
                          </button>
                        }
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="8" className="text-center">
                    No data found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <Paggination
          total={pagination.total}
          totalPages={pagination.totalPages}
          currentPage={pagination.currentPage}
          setPageNo={(pageNo) => setQuery((prev) => ({ ...prev, pageNo }))}
          startFrom={(pagination.currentPage - 1) * pagination.limit + 1}
          endTo={
            (pagination.currentPage - 1) * pagination.limit + promoData.length
          }
        />
      </div>
      <PromotionalModal
        show={showModal}
        onClose={() => setShowModal(false)}
        onSuccess={getAllPromotionalList}
      />
    </div>
  );
};

export default PromotionalLayer;
