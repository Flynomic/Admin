import React, { useState } from "react";
import { Modal } from "react-bootstrap";
import { toast } from "react-toastify";
import axios from "axios";
import { BASE_URL } from "../../../utils/constant";
import { getHeaders } from "../../../utils/helper";
import { CATEGORY } from "../../../utils/enum";
import validator from "validator";
import Loader from "../../../components/Loader/Loader";

// Dummy logo for preview
const DUMMY_LOGO =
  "https://ui-avatars.com/api/?name=Logo&background=eee&color=666&size=120";

// Ad types (sync with backend AD_TYPE enum)
const AD_TYPES = [
  {
    key: "leaderboard",
    label: "Leaderboard (max 20mb) (728x90)",
    frame: "/assets/images/ads/Leaderboard.png",
  },
  {
    key: "largeLeaderboard",
    label: "Large Leaderboard (max 20mb) (970x90)",
    frame: "/assets/images/ads/Leaderboard.png",
  },
  {
    key: "skyscraper",
    label: "Skyscraper (max 20mb) (120x300)",
    frame: "/assets/images/ads/Skyscraper.png",
  },
  {
    key: "wideSkyscraper",
    label: "Wide Skyscraper (max 20mb) (160x600)",
    frame: "/assets/images/ads/Wide Skyscraper.png",
  },
];

const PromotionalModal = ({ show, onClose, onSuccess }) => {
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [formData, setFormData] = useState({
    category: "",
    title: "",
    altText: "",
    website: "",
    logo: null,
    ads: {},
    active: "",
  });
  const [previewLogo, setPreviewLogo] = useState(null);
  const [previewAds, setPreviewAds] = useState({});

  // Handle input changes with real-time validation
  const handleInputChange = (e) => {
    const { name, value, type } = e.target;
    const checked = e.target.checked;

    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked ? checked : null : value,
    }));

    // Real-time validation
    const newErrors = { ...errors };
    if (name === "title" && !value.trim()) {
      newErrors.title = "Title is required";
    } else if (name === "title" && value.trim()) {
      if (value.length > 100) {
        newErrors.title = "Title must not exceed 100 characters";
      } else {
        delete newErrors.title;
      }
    }
    if (name === "category" && !value) {
      newErrors.category = "Category is required";
    } else if (name === "category" && value) {
      delete newErrors.category;
    }
    if (name === "website" && !value.trim()) {
      newErrors.website = "Website is required";
    } else if (name === "website" && value.trim()) {
      if (value.length > 100) {
        newErrors.website = "Website must not exceed 100 characters";
      } else if (!validator.isURL(value.trim())) {
        newErrors.website = "Website url is not valid";
      } else {
        delete newErrors.website;
      }
    }
    if (name === "altText" && !value.trim()) {
      newErrors.altText = "Alt Text is required";
    } else if (name === "altText" && value.trim()) {
      if (value.length > 200) {
        newErrors.altText = "Alt Text must not exceed 200 characters";
      } else {
        delete newErrors.altText;
      }
    }
    setErrors(newErrors);
  };

  // Handle logo upload with validation
  const handleLogoChange = (e) => {
    const file = e.target.files?.[0] || null;
    const newErrors = { ...errors };
    const maxSizeMB = 20; // 20 MB limit
    const maxSizeBytes = maxSizeMB * 1024 * 1024; // Convert to bytes

    const validExtensions = ['jpg', 'jpeg', 'png', 'gif'];
    const fileExtension = file?.name.split('.').pop().toLowerCase();

    if (!file) {
      newErrors.logo = "Logo image is required";
    } else if (!['image/png', 'image/jpeg', 'image/jpg', 'image/gif'].includes(file.type) || !validExtensions.includes(fileExtension)) {
      newErrors.logo = "Logo image must be a PNG, JPEG, JPG, or GIF";
    } else if (file.size > maxSizeBytes) {
      newErrors.logo = `Logo image must not exceed ${maxSizeMB} MB`;
    } else {
      delete newErrors.logo;
    }
    setFormData((prev) => ({ ...prev, logo: file }));
    setPreviewLogo(file ? URL.createObjectURL(file) : null);
    setErrors(newErrors);
    e.target.value = "";
  };

  // Handle ad banner upload with validation
  const handleAdBannerChange = (adType, e) => {
    const file = e.target.files?.[0] || null;
    const newErrors = { ...errors };
    const maxSizeMB = 20; // 20 MB limit
    const maxSizeBytes = maxSizeMB * 1024 * 1024; // Convert to bytes

    const validExtensions = ['jpg', 'jpeg', 'png', 'gif'];
    const fileExtension = file?.name.split('.').pop().toLowerCase();

    if (!file) {
      newErrors[adType] = `${adType.charAt(0).toUpperCase() + adType.slice(1)} image is required`;
    } else if (!['image/png', 'image/jpeg', 'image/jpg', 'image/gif'].includes(file.type) || !validExtensions.includes(fileExtension)) {
      newErrors[adType] = `${adType.charAt(0).toUpperCase() + adType.slice(1)} image must be a PNG, JPEG, JPG, or GIF`;
    } else if (file.size > maxSizeBytes) {
      newErrors[adType] = `${adType.charAt(0).toUpperCase() + adType.slice(1)} image must not exceed ${maxSizeMB} MB`;
    } else {
      delete newErrors[adType];
    }
    setFormData((prev) => ({
      ...prev,
      ads: { ...prev.ads, [adType]: file },
    }));
    setPreviewAds((prev) => ({
      ...prev,
      [adType]: file ? URL.createObjectURL(file) : prev[adType],
    }));
    setErrors(newErrors);
    e.target.value = "";
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrors({});

    // Final validation
    const newErrors = {};
    if (!formData.title.trim()) newErrors.title = "Title is required";
    if (!formData.category) newErrors.category = "Category is required";
    if (!formData.website.trim()) {
      newErrors.website = "Website is required";
    } else if (!validator.isURL(formData.website.trim())) {
      newErrors.website = "Website url is not valid";
    }
    if (!formData.altText.trim()) newErrors.altText = "Alt Text is required";
    if (!formData.logo) {
      newErrors.logo = "Logo image is required";
    }

    // Validate all ad types
    AD_TYPES.forEach(({ key }) => {
      if (!formData.ads[key]) {
        newErrors[key] = `${key.charAt(0).toUpperCase() + key.slice(1)} image is required`;
      }
    });

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      setLoading(false);
      return;
    }

    const dataToSend = new FormData();
    dataToSend.append("category", formData.category);
    dataToSend.append("title", formData.title);
    dataToSend.append("altText", formData.altText);
    dataToSend.append("website", formData.website);
    if (formData.active) {
      dataToSend.append("active", formData.active.toString());
    }
    if (formData.logo) dataToSend.append("logo", formData.logo);
    Object.entries(formData.ads).forEach(([adType, file]) => {
      if (file) dataToSend.append(adType, file);
    });

    try {
      const response = await axios.post(
        `${BASE_URL}/promotional/create`,
        dataToSend,
        {
          headers: { ...getHeaders(), "Content-Type": "multipart/form-data" },
        }
      );

      if (response.data.success) {
        toast.success("Promotional created successfully");
      } else {
        setErrors({
          general: response.data.message || "Failed to create promotional",
        });
      }
    } catch (error) {
      const errorMessage =
        error.response?.data?.message ||
        error.response?.data?.errors?.[0] ||
        error.message ||
        "Failed to create promotional";
      setErrors({ general: errorMessage });
    } finally {
      setFormData({
        category: "",
        title: "",
        altText: "",
        website: "",
        logo: null,
        ads: {},
        active: "",
      });
      setLoading(false);
      setPreviewLogo(null);
      setPreviewAds({});
      setErrors({});
      onSuccess();
      onClose();
    }
  };

  // Reset form when modal is closed
  const handleClose = () => {
    setFormData({
      category: "",
      title: "",
      altText: "",
      website: "",
      logo: null,
      ads: {},
      active: "",
    });
    setPreviewLogo(null);
    setPreviewAds({});
    setErrors({});
    setLoading(false);
    onClose();
  };

  return (
    <>
      {loading && <Loader />}
      <Modal show={show} onHide={handleClose} size="lg" centered>
        <Modal.Header closeButton>
          <Modal.Title>Create Promotional Campaign</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <form onSubmit={handleSubmit}>
            <div className="row gy-3 mb-3">
              {/* Category */}
              <div className="col-6">
                <label className="form-label">
                  Category <span className="text-danger">*</span>
                </label>
                <select
                  className="form-control"
                  name="category"
                  value={formData.category}
                  onChange={handleInputChange}>
                  <option value="">Select Category</option>
                  {Object.values(CATEGORY).map((value) => (
                    <option key={value} value={value}>
                      {value.charAt(0).toUpperCase() + value.slice(1)}
                    </option>
                  ))}
                </select>
                {errors.category && (
                  <div className="text-danger small mt-1">
                    {errors.category}
                  </div>
                )}
              </div>
              {/* Website */}
              <div className="col-6">
                <label className="form-label">
                  Website <span className="text-danger">*</span>
                </label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Enter website"
                  name="website"
                  value={formData.website}
                  onChange={handleInputChange}
                />
                {errors.website && (
                  <div className="text-danger small mt-1">{errors.website}</div>
                )}
              </div>
              {/* Active Status Checkbox */}
              <div className="col-6">
                <label className="form-label">Active Status</label>
                <div className="form-check">
                  <input
                    type="checkbox"
                    id="checkbox-create"
                    className="form-check-input"
                    name="active"
                    checked={formData.active}
                    onChange={handleInputChange}
                  />
                  <label className="form-check-label">Activate Promotion</label>
                </div>
              </div>
              {/* Title */}
              <div className="col-6">
                <label className="form-label">
                  Title <span className="text-danger">*</span>
                </label>
                <input
                  className="form-control"
                  placeholder="Enter title"
                  name="title"
                  value={formData.title}
                  onChange={handleInputChange}
                />
                {errors.title && (
                  <div className="text-danger small mt-1">{errors.title}</div>
                )}
              </div>
              {/* Alt Text */}
              <div className="col-12">
                <label className="form-label">
                  Alt Text <span className="text-danger">*</span>
                </label>
                <input
                  className="form-control"
                  placeholder="Enter alt text"
                  name="altText"
                  value={formData.altText}
                  onChange={handleInputChange}
                />
                {errors.altText && (
                  <div className="text-danger small mt-1">{errors.altText}</div>
                )}
              </div>
              {/* Logo */}
              <div className="col-12">
                <label className="form-label mb-2 d-block">
                  Logo (max 20mb) <span className="text-danger">*</span>
                </label>
                <div
                  style={{
                    width: 120,
                    height: 120,
                    position: "relative",
                    border: "2px dashed #e0e0e0",
                    borderRadius: "12px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    background: "#fafafd",
                    cursor: "pointer",
                    transition: "border-color 0.2s",
                  }}
                  className="logo-upload-frame mb-2"
                  onClick={() =>
                    document.getElementById("logo-upload-input")?.click()
                  }
                  onMouseEnter={(e) =>
                    (e.currentTarget.style.borderColor = "#bdbdbd")
                  }
                  onMouseLeave={(e) =>
                    (e.currentTarget.style.borderColor = "#e0e0e0")
                  }>
                  <img
                    src={previewLogo || DUMMY_LOGO}
                    alt="Logo Preview"
                    className="rounded"
                    style={{
                      width: "80px",
                      height: "80px",
                      objectFit: "contain",
                      opacity: previewLogo ? 1 : 0.7,
                    }}
                  />
                  <input
                    id="logo-upload-input"
                    type="file"
                    accept="image/jpeg, image/png"
                    style={{ display: "none" }}
                    onChange={handleLogoChange}
                  />
                  {!previewLogo && (
                    <span
                      style={{
                        position: "absolute",
                        bottom: 6,
                        left: 0,
                        right: 0,
                        textAlign: "center",
                        fontSize: "0.88em",
                        color: "#888",
                        background: "rgba(255,255,255,0.7)",
                        padding: "1px 0 0 0",
                      }}>
                      Click to upload
                    </span>
                  )}
                </div>
                {errors.logo && (
                  <div className="text-danger small mt-1">{errors.logo}</div>
                )}
              </div>
              {/* Ad Banners */}
              <div className="row g-4">
                {AD_TYPES.map(({ key, label, frame }) => (
                  <div className="col-md-6 col-lg-3" key={key}>
                    <label className="form-label mb-2 d-block text-center">
                      {label} <span className="text-danger">*</span>
                    </label>
                    <div
                      style={{
                        position: "relative",
                        cursor: "pointer",
                        border: "2px solid #e0e0e0",
                        borderRadius: "8px",
                        background: "#fafafd",
                        padding: "10px",
                        textAlign: "center",
                        transition: "border 0.2s",
                        height: "auto",
                      }}
                      className="ad-banner-upload-frame"
                      onClick={() =>
                        document.getElementById(`banner-upload-${key}`)?.click()
                      }>
                      {previewAds[key] ? (
                        <img
                          src={previewAds[key]}
                          alt={label}
                          style={{
                            width: "100%",
                            maxHeight: "140px",
                            objectFit: "contain",
                            borderRadius: "6px",
                          }}
                        />
                      ) : (
                        <img
                          src={frame}
                          alt={label}
                          style={{
                            width: "100%",
                            maxHeight: "140px",
                            opacity: 0.6,
                          }}
                        />
                      )}
                      <input
                        id={`banner-upload-${key}`}
                        type="file"
                        style={{ display: "none" }}
                        accept="image/jpeg, image/png"
                        onChange={(e) => handleAdBannerChange(key, e)}
                      />
                      <div
                        style={{
                          position: "absolute",
                          left: "50%",
                          bottom: "8px",
                          transform: "translateX(-50%)",
                          background: "#fff",
                          padding: "2px 8px",
                          borderRadius: "12px",
                          fontSize: "0.95em",
                          color: "#757575",
                          boxShadow: "0 2px 8px rgba(0,0,0,0.05)",
                        }}>
                        <span>Upload</span>
                      </div>
                    </div>
                    {errors[key] && (
                      <div className="text-danger small mt-1 text-center">
                        {errors[key]}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
            <div style={{ color: "red", fontSize: "12px" }}>
              <div>* Only JPEG, JPG, PNG, and GIF files are allowed</div>
              <div>* Logo is mandatory</div>
            </div>

            <div className="d-flex gap-2 justify-content-end">
              <button
                type="button"
                className="btn btn-secondary"
                onClick={handleClose}
                disabled={loading}>
                Cancel
              </button>
              <button
                type="submit"
                className="btn btn-primary"
                disabled={loading}>
                {loading ? "Creating..." : "Create"}
              </button>
            </div>
          </form>
        </Modal.Body>
      </Modal>
    </>
  );
};

export default PromotionalModal;
