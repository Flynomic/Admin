import React from "react";
import MasterLayout from "../masterLayout/MasterLayout";
import Breadcrumb from "../components/Breadcrumb";
import PrivacyPolicyLayer from "../components/PrivacyPolicyLayer";
import HomePageData from "../components/HomePageData";

const HomePageStatics = () => {
    return (
        <>
            {/* MasterLayout */}
            <MasterLayout>
                {/* Breadcrumb */}
                <Breadcrumb title="Home Page Statics" />

                {/* TermsConditionLayer */}
                <HomePageData />
            </MasterLayout>
        </>
    );
};

export default HomePageStatics;
