import React from "react";
import MasterLayout from "../masterLayout/MasterLayout";
import { Breadcrumb } from "react-bootstrap";

const ContentManagementPage = () => {
  return (
    <>
      {/* MasterLayout */}
      <MasterLayout>
        {/* Breadcrumb */}
        <Breadcrumb title="Email" />

        {/* EmailLayer */}
      </MasterLayout>
    </>
  );
};

export default ContentManagementPage;
