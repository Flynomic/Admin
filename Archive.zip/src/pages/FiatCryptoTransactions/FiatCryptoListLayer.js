import React, { useEffect, useState } from "react";
import useApi from "../../hook/useApi";
import Paggination from "../../components/Paggination";
import Loader from "../../components/Loader/Loader";

const FiatCryptoListLayer = () => {
  const { AsyncGetApiCall } = useApi();

  const [activeTab, setActiveTab] = useState("fiat");
  const [query, setQuery] = useState({
    pageNo: 1,
    limitVal: 50,
    search: "",
  });
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState(null);

  const getAllTransactions = async () => {
    setLoading(true);
    const endpoint =
      activeTab === "fiat"
        ? "/payment/fiat-list"
        : "/cryptotransactions/crypto-list";
    const result = await AsyncGetApiCall(endpoint, query);

    if (result?.success) {
      setData(result);
      // Check if current page is empty and there’s no next page, then adjust pageNo
      if (result.data.length === 0 && !result.hasNextPage && query.pageNo > 1) {
        const newPageNo = Math.max(1, result.totalPages || 1);
        if (newPageNo !== query.pageNo) {
          setQuery((prev) => ({ ...prev, pageNo: newPageNo }));
          // Immediately rerun to fetch the adjusted page
          await getAllTransactions(); // Recursive call with updated pageNo
        }
      }
    }
    setLoading(false);
  };

  const setPageNo = (pageNo) => {
    setQuery((prev) => ({
      ...prev,
      pageNo: pageNo,
    }));
  };

  useEffect(() => {
    getAllTransactions();
  }, [query, activeTab]);

  const handleTabChange = (tab) => {
    setActiveTab(tab);
    setQuery((prev) => ({ ...prev, pageNo: 1 }));
  };

  const handleLimitChange = (e) => {
    const value = parseInt(e.target.value, 10);
    setQuery((prev) => ({
      ...prev,
      limitVal: value,
      pageNo: 1, // Reset to page 1 when limit changes
    }));
  };

  return (
    <>
      {loading && <Loader />}
      <div className="card h-100 p-0 radius-12">
        <div className="card-header border-bottom bg-base py-16 px-24 d-flex align-items-center flex-wrap gap-3 justify-content-between">
          <div className="d-flex align-items-center flex-wrap gap-3">
            <span className="text-md fw-medium text-secondary-light mb-0">
              Show
            </span>
            <select
              className="form-select form-select-sm w-auto ps-12 py-6 radius-12 h-40-px"
              value={query.limitVal} // Controlled component
              onChange={handleLimitChange}
            >
              <option value="Select Number" disabled>
                Select Number
              </option>
              {Array.from({ length: 20 }, (_, i) => {
                const value = (i + 1) * 5;
                return (
                  <option key={value} value={value}>
                    {value}
                  </option>
                );
              })}
            </select>

            <div className="d-flex gap-2">
              <button
                className={`btn btn-sm ${activeTab === "fiat" ? "btn-primary" : "btn-outline-primary"
                  }`}
                onClick={() => handleTabChange("fiat")}
              >
                Fiat Transactions
              </button>
              <button
                className={`btn btn-sm ${activeTab === "crypto" ? "btn-primary" : "btn-outline-primary"
                  }`}
                onClick={() => handleTabChange("crypto")}
              >
                Crypto Transactions
              </button>
            </div>
          </div>
        </div>
        <div className="card-body p-24">
          <div className="table-responsive scroll-sm">
            <table className="table bordered-table sm-table mb-0">
              <thead>
                <tr>
                  <th scope="col">
                    <div className="d-flex align-items-center gap-10">S.No</div>
                  </th>
                  {activeTab === "fiat" ? (
                    <>
                      <th scope="col">Stripe Payment Id</th>
                      <th scope="col">Amount</th>
                      <th scope="col">Currency</th>
                      <th scope="col">Transaction Date</th>
                      <th scope="col">Status</th>
                    </>
                  ) : (
                    <>
                      <th scope="col">Payment ID</th>
                      <th scope="col">Price Amount</th>
                      <th scope="col">Price Currency</th>
                      <th scope="col">Pay Amount</th>
                      <th scope="col">Pay Currency</th>
                      <th scope="col">Order ID</th>
                      <th scope="col">Type</th>
                    </>
                  )}
                </tr>
              </thead>
              <tbody>
                {data && data.data.length > 0 ? (
                  data.data.map((item, index) => (
                    <tr key={item?._id}>
                      <td>
                        <div className="d-flex align-items-center gap-10">
                          {(data?.currentPage - 1) * query.limitVal + index + 1}
                        </div>
                      </td>
                      {activeTab === "fiat" ? (
                        <>
                          <td>{item?.stripePaymentIntentId || "N/A"}</td>
                          <td>{item?.amount || "N/A"}</td>
                          <td>{item?.currency || "N/A"}</td>
                          <td>
                            {item?.transactionDate
                              ? new Date(
                                item.transactionDate * 1000
                              ).toLocaleString("en-US", {
                                year: "numeric",
                                month: "short",
                                day: "numeric",
                                hour: "2-digit",
                                minute: "2-digit",
                                second: "2-digit",
                                hour12: true,
                              })
                              : "N/A"}
                          </td>
                          <td>{item?.status}</td>
                        </>
                      ) : (
                        <>
                          <td>{item?.payment_id || "N/A"}</td>
                          <td>{item?.price_amount || "N/A"}</td>
                          <td>{item?.price_currency || "N/A"}</td>
                          <td>{item?.pay_amount || "N/A"}</td>
                          <td>{item?.pay_currency || "N/A"}</td>
                          <td>{item?.order_id || "N/A"}</td>
                          <td>{item?.type || "N/A"}</td>
                        </>
                      )}
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td
                      colSpan={activeTab === "fiat" ? 6 : 8}
                      className="text-center"
                    >
                      No data found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          <Paggination
            total={data?.total || 0}
            totalPages={data?.totalPages || 0}
            currentPage={data?.currentPage || 0}
            setPageNo={setPageNo}
            startFrom={(data?.currentPage - 1) * query.limitVal + 1}
            endTo={
              (data?.currentPage - 1) * query.limitVal + data?.data?.length
            }
          />
        </div>
      </div>
    </>
  );
};

export default FiatCryptoListLayer;