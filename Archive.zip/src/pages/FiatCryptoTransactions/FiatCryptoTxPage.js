import React from "react";
import MasterLayout from "../../masterLayout/MasterLayout";
import Breadcrumb from "../../components/Breadcrumb";
import FiatCryptoListLayer from "./FiatCryptoListLayer";

const FiatCryptoTxPage = () => {
  return (
    <>
      {/* MasterLayout */}
      <MasterLayout>
        {/* Breadcrumb */}
        <Breadcrumb title="Fiat Crypto Transaction" />

        <FiatCryptoListLayer />
      </MasterLayout>
    </>
  );
};

export default FiatCryptoTxPage;
