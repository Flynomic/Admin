import { useEffect, useState } from "react";
import { useLocation, useParams } from "react-router-dom";
import Loader from "../components/Loader/Loader";
import useApi from "../hook/useApi";
import { toast } from "react-toastify";
import { userPageType } from "../utils/enum";
import { copyToClipboard, trimAddress, ValidateInputs } from "../utils/helper";
import { isValidEVMAddress } from "../utils/evm.helper";
import "react-phone-input-2/lib/style.css";
import { IoCopyOutline } from "react-icons/io5";

const ViewProfileLayer = () => {
  const [loading, setLoading] = useState(false);
  const [user, setUser] = useState("");
  const { id } = useParams();
  const location = useLocation();
  const { AsyncGetApiCall, AsyncPatchAPICall, AsyncPostApiCall } = useApi();
  const [isBalanceUpdated, setIsBalanceUpdated] = useState(false);

  const [passwordVisible, setPasswordVisible] = useState(false);
  const [confirmPasswordVisible, setConfirmPasswordVisible] = useState(false);
  const [errors, setErrors] = useState({});
  const from = location.state?.from;
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    countryCode: "+91",
    phoneNumber: "",
    address: "",
    walletAddress: "",
  });
  const [passwords, setPasswords] = useState({
    newPassword: "",
    confirmPassword: "",
  });
  const [notifications, setNotifications] = useState(() => ({
    generalNotification: false,
    orderNotification: false,
    generalEmail: false,
    orderEmail: false,
  }));
  const [balance, setBalance] = useState(null);

  const handleValues = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    const updatedInputs = ValidateInputs(name, value, errors);
    setErrors(updatedInputs);
  };

  const validate = () => {
    const newErrors = {};
    if (!formData?.firstName.trim()) {
      newErrors.firstName = "First name is required";
    }

    if (!formData?.lastName.trim()) {
      newErrors.lastName = "Last name is required";
    }

    if (!formData?.email.trim()) {
      newErrors.email = "Email is required";
    } else if (
      !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(formData?.email)
    ) {
      newErrors.email = "Email is invalid";
    }

    if (formData?.phoneNumber) {
      if (!/^\d{8,14}$/.test(formData?.phoneNumber)) {
        newErrors.phoneNumber = "Phone number is invalid";
      }
    }

    if (formData?.walletAddress.trim()) {
      if (!isValidEVMAddress(formData?.walletAddress.trim())) {
        newErrors.walletAddress = "Wallet address is not valid.";
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const togglePasswordVisibility = () => {
    setPasswordVisible(!passwordVisible);
  };

  const toggleConfirmPasswordVisibility = () => {
    setConfirmPasswordVisible(!confirmPasswordVisible);
  };

  const fetchUser = async () => {
    setLoading(true);

    const result = await AsyncGetApiCall(`/admin/view-user?id=${id}`);

    if (result.errors) {
      toast.error(result.errors[0]);
    } else if (result.success) {
      setUser(result?.data);
      setFormData({
        firstName: result?.data?.firstName || "",
        lastName: result?.data?.lastName || "",
        email: result?.data?.email || "",
        countryCode: result?.data?.countryCode,
        phoneNumber: result?.data?.phoneNumber,
        address: result?.data?.address || "",
        walletAddress: result?.data?.walletAddress || "",
      });
      setNotifications(result?.data?.notifications);
    }

    setLoading(false);
  };

  useEffect(() => {
    fetchUser();
  }, []);

  const handleUpdates = async (e) => {
    e.preventDefault();
    if (!validate()) {
      return;
    }
    setLoading(true);

    const result = await AsyncPatchAPICall(`/users/update`, {
      userId: id,
      ...formData,
    });

    if (result.errors) {
      toast.error(result.errors[0]);
    } else if (result.success) {
      setUser(result?.data);
      setFormData({
        firstName: result?.data?.firstName || "",
        lastName: result?.data?.lastName || "",
        email: result?.data?.email || "",
        countryCode: result?.data?.countryCode || "",
        phoneNumber: result?.data?.phoneNumber || "",
        address: result?.data?.address || "",
        walletAddress: result?.data?.walletAddress || "",
      });
      toast.success("Profile Updated Successfully");
    }
    fetchUser();
    setLoading(false);
  };

  const [phoneInputValue, setPhoneInputValue] = useState("");

  useEffect(() => {
    setPhoneInputValue(
      formData.countryCode && formData.phoneNumber
        ? `${formData.countryCode}${formData.phoneNumber}`
        : ""
    );
  }, [formData]);

  const validatePassword = (newPassword, confirmPassword) => {
    const errors = {};

    // Check if password is empty
    if (!newPassword.trim()) {
      errors.newPassword = "Password is required";
    } else if (newPassword.length < 8) {
      errors.newPassword = "Password must be at least 8 characters long";
    } else if (!/[A-Z]/.test(newPassword)) {
      errors.newPassword =
        "Password must contain at least one uppercase letter";
    } else if (!/[a-z]/.test(newPassword)) {
      errors.newPassword =
        "Password must contain at least one lowercase letter";
    } else if (!/[0-9]/.test(newPassword)) {
      errors.newPassword = "Password must contain at least one number";
    } else if (!/[!@#$%^&*(),.?":{}|<>]/.test(newPassword)) {
      errors.newPassword =
        "Password must contain at least one special character";
    }

    // Check confirm password
    if (!confirmPassword.trim()) {
      errors.confirmPassword = "Please confirm your password";
    } else if (newPassword !== confirmPassword) {
      errors.confirmPassword = "Passwords do not match";
    }

    setErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handlePasswordInput = (e) => {
    const { name, value } = e.target;
    setPasswords((prev) => ({
      ...prev,
      [name]: value,
    }));

    const updatedInputs = ValidateInputs(name, value, errors);
    setErrors(updatedInputs);
  };

  const handlePassword = async (e) => {
    e.preventDefault();
    if (!validatePassword(passwords.newPassword, passwords.confirmPassword)) {
      return;
    }
    setLoading(true);

    const result = await AsyncPostApiCall(`/users/change-password`, {
      userId: id,
      ...passwords,
    });

    if (result.errors) {
      toast.error(result.errors[0]);
    } else if (result.success) {
      toast.success("Profile Updated Successfully");
      setPasswords({
        newPassword: "",
        confirmPassword: "",
      });
    }
    setLoading(false);
  };

  const handleNotificationChange = (e) => {
    const { name, checked } = e.target;
    setNotifications((prev) => ({
      ...prev,
      [name]: checked,
    }));
  };

  const handleNotification = async (e) => {
    e.preventDefault();

    setLoading(true);
    console.log("notifications", notifications);
    const result = await AsyncPatchAPICall(`/users/update/notifications`, {
      userId: id,
      notifications: {
        ...notifications,
      },
    });
    console.log("result", result);
    if (result.success && result.notifications) {
      toast.success("Notification updated successfully");
      fetchUser();
    } else {
      toast.error(result.errors[0]);
    }
    setLoading(false);
  };

  const getBalance = async () => {
    const result = await AsyncGetApiCall(
      `/wallet/get-balance?userId=${id}`
    );
    if (result?.success) {
      setBalance(result?.data?.balance);
    }
    console.log("result of balance : ", result);
    return result?.data?.balance
  };

  useEffect(() => {
    if (isBalanceUpdated) {
      getBalance();
      setIsBalanceUpdated(false);
    }
    else {
      getBalance()
    }
  }, [isBalanceUpdated]);

  return (
    <>
      {loading && <Loader />}
      <div className="row gy-4">
        <div className={`col-lg-4 ${from === userPageType.VIEW && "w-50"} `}>
          <div className="user-grid-card position-relative border radius-16 overflow-hidden bg-base h-100">
            <div className="pb-24 ms-16 mb-24 me-16 mt-100">
              <div className="mt-24">
                <h6 className="text-xl mb-16">Personal Info</h6>
                <ul>
                  <li className="d-flex align-items-center gap-2 mb-12">
                    <span className="w-30 text-md fw-semibold text-primary-light">
                      Full Name
                    </span>
                    <span>:</span>
                    <span className="w-70 text-secondary-light fw-medium">
                      {user?.firstName || user?.lastName
                        ? `${user?.firstName || ""} ${user?.lastName || ""
                          }`.trim()
                        : "N/A"}
                    </span>
                  </li>
                  <li className="d-flex align-items-center gap-2 mb-12">
                    <span className="w-30 text-md fw-semibold text-primary-light">
                      Email
                    </span>
                    <span>:</span>
                    <span className="w-70 text-secondary-light fw-medium">
                      {user?.email || "N/A"}
                    </span>
                  </li>
                  <li className="d-flex align-items-center gap-2 mb-12">
                    <span className="w-30 text-md fw-semibold text-primary-light">
                      Phone Number
                    </span>
                    <span>:</span>
                    <span className="w-70 text-secondary-light fw-medium">
                      {user?.phoneNumber ? `${user?.countryCode} ${user?.phoneNumber}` : "N/A"}
                    </span>
                  </li>
                  <li className="d-flex align-items-center gap-2 mb-12">
                    <span className="w-30 text-md fw-semibold text-primary-light">
                      Address
                    </span>
                    <span>:</span>
                    <span className="w-70 text-secondary-light fw-medium">
                      {user?.address ? user?.address : "N/A"}
                    </span>
                  </li>
                  <li className="d-flex align-items-center gap-2 mb-12">
                    <span className="w-30 text-md fw-semibold text-primary-light">
                      Wallet Address
                    </span>
                    <span className="me-2">:</span>
                    <div className="d-flex align-items-center w-70 text-secondary-light fw-medium ">
                      <span>
                        {user?.walletAddress
                          ? trimAddress(user?.walletAddress, 10, 8)
                          : "N/A"}
                      </span>
                      {user?.walletAddress && (
                        <button
                          onClick={() => copyToClipboard(user?.walletAddress)}
                          className="ms-3 p-0 border-0 bg-transparent "
                          style={{ lineHeight: 1 }}>
                          <IoCopyOutline />
                        </button>
                      )}
                    </div>
                  </li>
                  <li className="d-flex align-items-center gap-2">
                    <span className="w-30 text-md fw-semibold text-primary-light mt-4">
                      Verification Status
                    </span>
                    <span>:</span>
                    <span className="w-70 text-secondary-light fw-medium">
                      {user?.isVerified ? "Active" : "Inactive"}
                    </span>
                  </li>
                  <li className="d-flex align-items-center gap-2 mt-4">
                    <span className="w-30 text-md fw-semibold text-primary-light">
                      Whitelisting Status
                    </span>
                    <span>:</span>
                    <span className="w-70 text-secondary-light fw-medium">
                      {user?.isWhitelisted ? "Whitelisted" : "Not Whitelisted"}
                    </span>
                  </li>
                  <li className="d-flex align-items-center gap-2 mt-4">
                    <span className="w-30 text-md fw-semibold text-primary-light">
                      Wallet Balance<span className="text-sm">(In USD)</span>
                    </span>
                    <span>:</span>
                    <span className="w-70 text-secondary-light fw-medium">
                      {balance ? balance.toFixed(2) : 0}
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {from === userPageType.UPDATE && (
          <div className="col-lg-8">
            <div className="card h-100">
              <div className="card-body p-24">
                <ul
                  className="nav border-gradient-tab nav-pills mb-20 d-inline-flex"
                  id="pills-tab"
                  role="tablist">
                  <li className="nav-item" role="presentation">
                    <button
                      className="nav-link d-flex align-items-center px-24 active"
                      id="pills-edit-profile-tab"
                      data-bs-toggle="pill"
                      data-bs-target="#pills-edit-profile"
                      type="button"
                      role="tab"
                      aria-controls="pills-edit-profile"
                      aria-selected="true">
                      Edit Profile
                    </button>
                  </li>
                  <li className="nav-item" role="presentation">
                    <button
                      className="nav-link d-flex align-items-center px-24"
                      id="pills-notification-tab"
                      data-bs-toggle="pill"
                      data-bs-target="#pills-notification"
                      type="button"
                      role="tab"
                      aria-controls="pills-notification"
                      aria-selected="false"
                      tabIndex={-1}>
                      Notification Settings
                    </button>
                  </li>
                  <li className="nav-item" role="presentation">
                    <button
                      className="nav-link d-flex align-items-center px-24"
                      id="pills-change-passwork-tab"
                      data-bs-toggle="pill"
                      data-bs-target="#pills-change-passwork"
                      type="button"
                      role="tab"
                      aria-controls="pills-change-passwork"
                      aria-selected="false"
                      tabIndex={-1}>
                      Change Password
                    </button>
                  </li>

                  <li className="nav-item" role="presentation">
                    <button
                      className="nav-link d-flex align-items-center px-24"
                      id="pills-user-wallet-tab"
                      data-bs-toggle="pill"
                      data-bs-target="#pills-user-wallet"
                      type="button"
                      role="tab"
                      aria-controls="pills-user-wallet"
                      aria-selected="false"
                      tabIndex={-1}>
                      User Wallet
                    </button>
                  </li>
                </ul>
                <div className="tab-content" id="pills-tabContent">
                  <div
                    className="tab-pane fade show active"
                    id="pills-edit-profile"
                    role="tabpanel"
                    aria-labelledby="pills-edit-profile-tab"
                    tabIndex={0}>
                    <form action="#" onSubmit={handleUpdates}>
                      <div className="row">
                        <div className="col-sm-6">
                          <div className="mb-20">
                            <label
                              htmlFor="name"
                              className="form-label fw-semibold text-primary-light text-sm mb-8">
                              First Name
                              <span className="text-danger-600">*</span>
                            </label>
                            <input
                              type="text"
                              className={`form-control radius-8 ${errors.firstName ? "is-invalid" : ""
                                }`}
                              id="firstName"
                              placeholder={
                                from === userPageType.VIEW
                                  ? user?.firstName || "Not Provided"
                                  : "Enter First Name"
                              }
                              disabled={from === userPageType.VIEW}
                              value={formData?.firstName}
                              onChange={handleValues}
                              name="firstName"
                            />
                            {errors.firstName && (
                              <div className="invalid-feedback">
                                {errors.firstName}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="col-sm-6">
                          <div className="mb-20">
                            <label
                              htmlFor="name"
                              className="form-label fw-semibold text-primary-light text-sm mb-8">
                              Last Name
                              <span className="text-danger-600">*</span>
                            </label>
                            <input
                              type="text"
                              className={`form-control radius-8 ${errors.lastName ? "is-invalid" : ""
                                }`}
                              id="lastName"
                              placeholder={
                                from === userPageType.VIEW
                                  ? user?.lastName || "Not Provided"
                                  : "Enter Last Name"
                              }
                              disabled={from === userPageType.VIEW}
                              value={formData?.lastName}
                              onChange={handleValues}
                              name="lastName"
                            />
                            {errors.lastName && (
                              <div className="invalid-feedback">
                                {errors.lastName}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="col-sm-6">
                          <div className="mb-20">
                            <label
                              htmlFor="email"
                              className="form-label fw-semibold text-primary-light text-sm mb-8">
                              Email <span className="text-danger-600">*</span>
                            </label>
                            <input
                              type="text"
                              className={`form-control radius-8 ${errors.email ? "is-invalid" : ""
                                }`}
                              id="email"
                              placeholder={
                                from === userPageType.VIEW
                                  ? user?.email || "Not Provided"
                                  : "Enter Email"
                              }
                              disabled={from === userPageType.VIEW}
                              value={formData?.email}
                              onChange={handleValues}
                              name="email"
                            />
                            {errors.email && (
                              <div className="invalid-feedback">
                                {errors.email}
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="col-sm-6">
                          <div className="mb-20">
                            <label
                              htmlFor="phone"
                              className="form-label fw-semibold text-primary-light text-sm mb-8">
                              Phone Number
                            </label>
                            <input
                              type="text"
                              className={`form-control radius-8 ${errors.phoneNumber ? "is-invalid" : ""
                                }`}
                              id="phone"
                              placeholder={
                                from === userPageType.VIEW
                                  ? user?.phoneNumber || "Not Provided"
                                  : "Enter Phone Number"
                              }
                              disabled={from === userPageType.VIEW}
                              value={formData?.phoneNumber}
                              onChange={handleValues}
                              name="phoneNumber"
                            />
                            {errors.phoneNumber && (
                              <div className="invalid-feedback d-block">
                                {errors.phoneNumber}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="col-sm-6">
                          <div className="mb-20">
                            <label
                              htmlFor="number"
                              className="form-label fw-semibold text-primary-light text-sm mb-8">
                              Address
                            </label>
                            <input
                              type="text"
                              className={`form-control radius-8 ${errors.address ? "is-invalid" : ""
                                }`}
                              id="number"
                              placeholder={
                                from === userPageType.VIEW
                                  ? user?.address || "Not Provided"
                                  : "Enter Address"
                              }
                              disabled={from === userPageType.VIEW}
                              value={formData?.address}
                              onChange={handleValues}
                              name="address"
                            />
                            {errors.address && (
                              <div className="invalid-feedback">
                                {errors.address}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="col-sm-6">
                          <div className="mb-20">
                            <label
                              htmlFor="number"
                              className="form-label fw-semibold text-primary-light text-sm mb-8">
                              Wallet Address
                            </label>
                            <input
                              type="text"
                              className={`form-control radius-8 ${errors.walletAddress ? "is-invalid" : ""
                                }`}
                              id="number"
                              placeholder={
                                from === userPageType.VIEW
                                  ? user?.walletAddress || "Not Provided"
                                  : "Enter Wallet Address"
                              }
                              disabled={from === userPageType.VIEW}
                              value={formData?.walletAddress}
                              onChange={handleValues}
                              name="walletAddress"
                            />
                            {errors.walletAddress && (
                              <div className="invalid-feedback">
                                {errors.walletAddress}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                      {from === userPageType.UPDATE && (
                        <div className="d-flex align-items-center justify-content-center gap-3">
                          <button
                            type="submit"
                            className="btn btn-primary border border-primary-600 text-md px-56 py-12 radius-8">
                            Save
                          </button>
                        </div>
                      )}
                    </form>
                  </div>

                  <div
                    className="tab-pane fade"
                    id="pills-change-passwork"
                    role="tabpanel"
                    aria-labelledby="pills-change-passwork-tab"
                    tabIndex={0}>
                    <form onSubmit={handlePassword}>
                      <div className="mb-20">
                        <label
                          htmlFor="your-password"
                          className="form-label fw-semibold text-primary-light text-sm mb-8">
                          New Password{" "}
                          <span className="text-danger-600">*</span>
                        </label>
                        <div className="position-relative">
                          <input
                            name="newPassword"
                            type={passwordVisible ? "text" : "password"}
                            className={`form-control radius-8 ${errors.newPassword ? "is-invalid" : ""
                              }`}
                            id="your-password"
                            placeholder="Enter New Password*"
                            value={passwords.newPassword}
                            onChange={handlePasswordInput}
                            disabled={from === userPageType.VIEW}
                          />
                          {errors.newPassword ? (
                            <div className="invalid-feedback">
                              {errors.newPassword}
                            </div>
                          ) : (
                            <span
                              className={`toggle-password ${passwordVisible
                                ? "ri-eye-off-line"
                                : "ri-eye-line"
                                } cursor-pointer position-absolute end-0 top-50 translate-middle-y me-16 text-secondary-light`}
                              onClick={togglePasswordVisibility}></span>
                          )}
                        </div>
                      </div>

                      <div className="mb-20">
                        <label
                          htmlFor="confirm-password"
                          className="form-label fw-semibold text-primary-light text-sm mb-8">
                          Confirm Password{" "}
                          <span className="text-danger-600">*</span>
                        </label>
                        <div className="position-relative">
                          <input
                            name="confirmPassword"
                            type={confirmPasswordVisible ? "text" : "password"}
                            className={`form-control radius-8 ${errors.confirmPassword ? "is-invalid" : ""
                              }`}
                            id="confirm-password"
                            placeholder="Confirm Password*"
                            value={passwords.confirmPassword}
                            onChange={handlePasswordInput}
                            disabled={from === userPageType.VIEW}
                          />
                          {errors.confirmPassword ? (
                            <div className="invalid-feedback">
                              {errors.confirmPassword}
                            </div>
                          ) : (
                            <span
                              className={`toggle-password ${confirmPasswordVisible
                                ? "ri-eye-off-line"
                                : "ri-eye-line"
                                } cursor-pointer position-absolute end-0 top-50 translate-middle-y me-16 text-secondary-light`}
                              onClick={toggleConfirmPasswordVisibility}></span>
                          )}
                        </div>
                      </div>

                      <div className="d-flex align-items-center justify-content-center gap-3">
                        <button
                          type="submit"
                          className="btn btn-primary border border-primary-600 text-md px-56 py-12 radius-8">
                          Save
                        </button>
                      </div>
                    </form>
                  </div>

                  <div
                    className="tab-pane fade"
                    id="pills-notification"
                    role="tabpanel"
                    aria-labelledby="pills-notification-tab"
                    tabIndex={0}>
                    <form onSubmit={handleNotification}>
                      <div className="form-switch switch-primary py-12 px-16 border radius-8 position-relative mb-16">
                        <label
                          htmlFor="companzNew"
                          className="position-absolute w-100 h-100 start-0 top-0"
                        />
                        <div className="d-flex align-items-center gap-3 justify-content-between">
                          <span className="form-check-label line-height-1 fw-medium text-secondary-light">
                            General Notification
                          </span>
                          <input
                            className="form-check-input"
                            type="checkbox"
                            role="switch"
                            id="companzNew"
                            name="generalNotification"
                            checked={notifications.generalNotification}
                            onChange={handleNotificationChange}
                          />
                        </div>
                      </div>

                      <div className="form-switch switch-primary py-12 px-16 border radius-8 position-relative mb-16">
                        <label
                          htmlFor="pushNotifcation"
                          className="position-absolute w-100 h-100 start-0 top-0"
                        />
                        <div className="d-flex align-items-center gap-3 justify-content-between">
                          <span className="form-check-label line-height-1 fw-medium text-secondary-light">
                            Order Notification
                          </span>
                          <input
                            className="form-check-input"
                            type="checkbox"
                            role="switch"
                            id="pushNotifcation"
                            name="orderNotification"
                            checked={notifications?.orderNotification}
                            onChange={handleNotificationChange}
                          />
                        </div>
                      </div>

                      <div className="form-switch switch-primary py-12 px-16 border radius-8 position-relative mb-16">
                        <label
                          htmlFor="weeklyLetters"
                          className="position-absolute w-100 h-100 start-0 top-0"
                        />
                        <div className="d-flex align-items-center gap-3 justify-content-between">
                          <span className="form-check-label line-height-1 fw-medium text-secondary-light">
                            General Email
                          </span>
                          <input
                            className="form-check-input"
                            type="checkbox"
                            role="switch"
                            id="weeklyLetters"
                            name="generalEmail"
                            checked={notifications?.generalEmail}
                            onChange={handleNotificationChange}
                          />
                        </div>
                      </div>

                      <div className="form-switch switch-primary py-12 px-16 border radius-8 position-relative mb-16">
                        <label
                          htmlFor="meetUp"
                          className="position-absolute w-100 h-100 start-0 top-0"
                        />
                        <div className="d-flex align-items-center gap-3 justify-content-between">
                          <span className="form-check-label line-height-1 fw-medium text-secondary-light">
                            Order Email
                          </span>
                          <input
                            className="form-check-input"
                            type="checkbox"
                            role="switch"
                            id="meetUp"
                            name="orderEmail"
                            checked={notifications?.orderEmail}
                            onChange={handleNotificationChange}
                          />
                        </div>
                      </div>

                      <div className="d-flex align-items-center justify-content-center gap-3">
                        <button
                          type="submit"
                          className="btn btn-primary border border-primary-600 text-md px-56 py-12 radius-8">
                          Save
                        </button>
                      </div>
                    </form>
                  </div>

                  <WalletManuplate from={from} userId={id} getBalance={getBalance} isBalanceUpdated={isBalanceUpdated} setIsBalanceUpdated={setIsBalanceUpdated} />
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default ViewProfileLayer;

const WalletManuplate = ({ userId, from, getBalance, isBalanceUpdated, setIsBalanceUpdated }) => {
  const { AsyncGetApiCall, AsyncPatchAPICall } = useApi();
  const [balance, setBalance] = useState(0);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({
    balance: "",
  });

  const handleWalletManuplation = async (e) => {
    e.preventDefault();
    setErrors({ balance: "" });

    // Validation
    if (!balance || isNaN(balance)) {
      setErrors({ balance: "Balance must be a number" });
      return;
    }
    if (parseFloat(balance) < 0) {
      setErrors({ balance: "Balance cannot be negative" });
      return;
    }

    setLoading(true);

    const result = await AsyncPatchAPICall(`/wallet/balance-manipulate`, {
      balance: parseFloat(balance),
      userId: userId,
    });

    if (result?.success) {
      toast.success(result.message);
      setIsBalanceUpdated(true);
    } else {
      toast.error(result?.errors?.[0] || "Something went wrong");
    }

    console.log("result handleWalletManuplation: ", result);
    setLoading(false);
    getBalance()
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    // Handle different field types
    if (name === "balance") {
      const computedValue = value === "" ? "" : Number(Math.max(0, Math.min(1000000, Number(value)).toFixed(2) || 0));
      setBalance(computedValue)
    }
  }

  const fetchBalance = async () => {
    const currentBalance = await getBalance()
    setBalance(currentBalance)
  }

  useEffect(() => {
    if (isBalanceUpdated) {
      getBalance();
      setIsBalanceUpdated(false);
    }
    else {
      getBalance()
      fetchBalance()
    }
  }, [isBalanceUpdated]);

  return (
    <>
      {loading && <Loader />}
      <div
        className="tab-pane fade"
        id="pills-user-wallet"
        role="tabpanel"
        aria-labelledby="pills-user-wallet-tab"
        tabIndex={0}>
        <form>
          <div className="mb-20">
            <label
              htmlFor="balance"
              className="form-label fw-semibold text-primary-light text-sm mb-8">
              Current Balance (In USD) <span className="text-danger-600">*</span>
            </label>
            <div className="position-relative">
              <input
                name="balance"
                type="number"
                className={`form-control radius-8 ${errors.balance ? "is-invalid" : ""
                  }`}
                id="balance"
                placeholder="Enter New Balance*"
                value={balance ? balance.toFixed(2) : 0}
                onChange={handleChange}
                disabled={from === userPageType.VIEW}
                min="0"
                max="1000000"
              />

              {errors.balance && (
                <div className="invalid-feedback">{errors.balance}</div>
              )}
            </div>
          </div>

          <div className="d-flex align-items-center justify-content-center gap-3">
            <button
              type="submit"
              className="btn btn-primary border border-primary-600 text-md px-56 py-12 radius-8"
              onClick={handleWalletManuplation}>
              Update
            </button>
          </div>
        </form>
      </div>
    </>
  );
};
