import React from "react";
import ViewProfileLayerAdmin from "./ViewProfileLayerAdmin";
import MasterLayout from "../../masterLayout/MasterLayout";
import Breadcrumb from "../../components/Breadcrumb";

const ViewProfilePageAdmin = () => {
  return (
    <>
      {/* MasterLayout */}
      <MasterLayout>
        {/* Breadcrumb */}
        <Breadcrumb title="View Profile" />

        {/* ViewProfileLayer */}
        <ViewProfileLayerAdmin />
      </MasterLayout>
    </>
  );
};

export default ViewProfilePageAdmin;
