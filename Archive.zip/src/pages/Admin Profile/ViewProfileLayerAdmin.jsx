import React, { useEffect, useState } from "react";
import { useAuth } from "../../context/AuthContext";
import { formatDate, ValidateInputs } from "../../utils/helper";
import useApi from "../../hook/useApi";
import { toast } from "react-toastify";

const ViewProfileLayerAdmin = () => {
  const { profile, setProfile } = useAuth();
  const { AsyncPatchAPICall } = useApi();
  const [errors, setErrors] = useState({});

  const tab = {
    PROFILE: "PROFILE",
    PASSWORD: "PASSWORD",
  };

  const [currentTab, setCurrentTab] = useState(tab.PROFILE);

  const [data, setData] = useState({
    name: profile.name || "",
    contactNumber: profile.contactNumber || "",
    email: profile.email || "",
    createdAt: profile.createdAt || "",
  });

  const [dataToUpdate, setDataToUpdate] = useState({ ...data });

  const handleValues = (e) => {
    const { name, value } = e.target;

    setDataToUpdate((prev) => ({
      ...prev,
      [name]: value,
    }));
    const updatedInputs = ValidateInputs(name, value, errors);
    setErrors(updatedInputs);
  };

  const validate = () => {
    const newErrors = {};

    // Validate name
    if (!dataToUpdate?.name?.trim()) {
      newErrors.name = "Name is required";
    } else if (dataToUpdate.name.trim().length > 50) {
      newErrors.name = "Name cannot exceed 50 characters";
    }

    // Validate phone
    if (!dataToUpdate?.contactNumber) {
      newErrors.contactNumber = "Phone number is required";
    } else if (dataToUpdate.contactNumber.length > 14) {
      newErrors.contactNumber = "Phone number cannot exceed 14 digits";
    } else if (!/^\d{8,14}$/.test(dataToUpdate.contactNumber)) {
      newErrors.contactNumber = "Phone number must be 8–14 digits";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const saveAdminProfile = async () => {
    if (!validate()) {
      return;
    }
    // TODO: Add update logic here
    const result = await AsyncPatchAPICall(
      "/admin/update-profile",
      dataToUpdate
    );
    if (result.success) {
      localStorage.setItem("profile", JSON.stringify(result.admin));
      setProfile(result.admin);
      toast.success("Profile updated successfully");
    } else {
      toast.error(result.errors[0]);
    }
  };

  useEffect(() => {
    if (profile) {
      const updatedData = {
        name: profile.name || "",
        contactNumber: profile.contactNumber || "",
        email: profile.email || "",
        createdAt: profile.createdAt || "",
      };
      setData(updatedData);
      setDataToUpdate(updatedData);
    }
  }, [profile]);

  useEffect(() => {
    setErrors({});
    if (currentTab === tab.PROFILE) {
      setDataToUpdate(data); // restore latest profile data
    }
  }, [currentTab, data]);

  return (
    <div className="row gy-4">
      <div className="col-lg-4">
        <div className="user-grid-card border radius-16 overflow-hidden bg-base h-100 position-relative">
          <img
            src="https://wow-dash.com/demo/assets/images/user-grid/user-grid-bg1.png"
            alt=""
            className="w-100 object-fit-cover"
          />
          <div className="pb-24 ms-16 mb-24 me-16 mt--100">
            <div className="text-center border-bottom border-top">
              <img
                src="https://wow-dash.com/demo/assets/images/user-grid/user-grid-img14.png"
                alt=""
                className="border br-white border-width-2-px w-200-px h-200-px rounded-circle object-fit-cover"
              />
              <h6 className="mb-0 mt-16">{data.name}</h6>
              <span className="text-secondary-light mb-16">{data.email}</span>
            </div>
            <div className="mt-24">
              <h6 className="text-xl mb-16">Personal Info</h6>
              <ul>
                <InfoItem label="Full Name" value={data.name} />
                <InfoItem label="Email" value={data.email} />
                <InfoItem label="Phone Number" value={data.contactNumber} />
                <InfoItem
                  label="Created At"
                  value={formatDate(data.createdAt, true)}
                />
                <InfoItem label="Languages" value="English" />
                <InfoItem label="Bio" value="--" />
              </ul>
            </div>
          </div>
        </div>
      </div>

      <div className="col-lg-8">
        <div className="card h-100">
          <div className="card-body p-24">
            <ul
              className="nav border-gradient-tab nav-pills mb-20 d-inline-flex"
              role="tablist"
            >
              <li className="nav-item" role="presentation">
                <button
                  className="nav-link active px-24"
                  id="edit-tab"
                  data-bs-toggle="pill"
                  data-bs-target="#edit-profile"
                  type="button"
                  role="tab"
                  aria-selected="true"
                  onClick={() => {
                    setCurrentTab(tab.PROFILE);
                  }}
                >
                  Edit Profile
                </button>
              </li>
              <li className="nav-item" role="presentation">
                <button
                  className="nav-link px-24"
                  id="password-tab"
                  data-bs-toggle="pill"
                  data-bs-target="#change-password"
                  type="button"
                  role="tab"
                  aria-selected="false"
                  onClick={() => setCurrentTab(tab.PASSWORD)}
                >
                  Change Password
                </button>
              </li>
            </ul>

            <div className="tab-content">
              <div
                className="tab-pane fade show active"
                id="edit-profile"
                role="tabpanel"
              >
                <form>
                  <div className="row">
                    <FormInput
                      label="Full Name"
                      id="name"
                      name="name"
                      value={dataToUpdate.name}
                      onChange={handleValues}
                      errors={errors}
                    />
                    <FormInput
                      name="email"
                      label="Email"
                      id="email"
                      value={dataToUpdate.email}
                      errors={errors}
                      readOnly
                    />
                    <FormInput
                      label="Phone"
                      id="number"
                      name="contactNumber"
                      value={dataToUpdate.contactNumber}
                      errors={errors}
                      onChange={handleValues}
                    />
                  </div>

                  <div className="d-flex justify-content-center gap-3 mt-4">
                    <button
                      type="button"
                      className="btn btn-primary border border-primary-600 text-md px-56 py-12 radius-8"
                      onClick={saveAdminProfile}
                    >
                      Save
                    </button>
                  </div>
                </form>
              </div>

              <div
                className="tab-pane fade"
                id="change-password"
                role="tabpanel"
              >
                <ChangePassword clearSignal={currentTab} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ViewProfileLayerAdmin;

// 👇 Info List Item Component
function InfoItem({ label, value }) {
  return (
    <li className="d-flex align-items-center gap-1 mb-12">
      <span className="w-30 text-md fw-semibold text-primary-light">
        {label}
      </span>
      <span className="w-70 text-secondary-light fw-medium">: {value}</span>
    </li>
  );
}

// 👇 Reusable Form Input Component
function FormInput({ errors, name, label, id, value, onChange, readOnly }) {
  return (
    <div className="col-sm-6 mb-20">
      <label
        htmlFor={id}
        className="form-label fw-semibold text-primary-light text-sm mb-8"
      >
        {label}
      </label>
      <input
        name={name}
        type="text"
        className={`form-control radius-8 ${errors[name] ? "is-invalid" : ""}`}
        id={id}
        placeholder={`Enter ${label}`}
        value={value}
        readOnly={readOnly}
        onChange={onChange}
      />
      {errors[name] && <div className="invalid-feedback">{errors[name]}</div>}
    </div>
  );
}

// 👇 ChangePassword Component (unchanged)
function ChangePassword({ clearSignal }) {
  const { logout } = useAuth();
  const { AsyncPostApiCall } = useApi();
  const [errors, setErrors] = useState({});

  useEffect(() => {
    setErrors({});
    setPayload({
      oldPassword: "",
      newPassword: "",
      confirmPassword: "",
    });
  }, [clearSignal]);

  const [payload, setPayload] = useState({
    oldPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const [visible, setVisible] = useState({
    oldPassword: false,
    newPassword: false,
    confirmPassword: false,
  });

  const updateVisible = (field) => {
    setVisible((prev) => ({
      ...prev,
      [field]: !prev[field],
    }));
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setPayload((prev) => ({
      ...prev,
      [name]: value,
    }));
    const updatedInputs = ValidateInputs(name, value, errors);
    setErrors(updatedInputs);
  };

  const validate = () => {
    const newErrors = {};

    if (!payload.oldPassword.trim()) {
      newErrors.oldPassword = "Old Password is required";
    }

    // Check if password is empty
    if (!payload.newPassword.trim()) {
      newErrors.newPassword = "Password is required";
    } else if (payload.newPassword.length < 8) {
      newErrors.newPassword = "Password must be at least 8 characters long";
    } else if (!/[A-Z]/.test(payload.newPassword)) {
      newErrors.newPassword =
        "Password must contain at least one uppercase letter";
    } else if (!/[a-z]/.test(payload.newPassword)) {
      newErrors.newPassword =
        "Password must contain at least one lowercase letter";
    } else if (!/[0-9]/.test(payload.newPassword)) {
      newErrors.newPassword = "Password must contain at least one number";
    } else if (!/[!@#$%^&*(),.?":{}|<>]/.test(payload.newPassword)) {
      newErrors.newPassword =
        "Password must contain at least one special character";
    }

    if (!payload.confirmPassword.trim()) {
      newErrors.confirmPassword = "Confirm Password is required";
    } else if (payload.newPassword !== payload.confirmPassword) {
      newErrors.confirmPassword = "Passwords don't match";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handlePassword = async (e) => {
    e.preventDefault();
    if (!validate()) {
      return;
    }
    // TODO: Call password update API here
    const result = await AsyncPostApiCall("/admin/change-password", payload);
    console.log("result : ", result);
    if (result.success) {
      toast.success("Password changed successfully");
      setErrors({});
      await logout();
    } else {
      toast.error(result.errors[0]);
    }
  };

  return (
    <>
      {/* Old Password */}
      <div className="mb-20">
        <label
          htmlFor="oldPassword"
          className="form-label fw-semibold text-primary-light text-sm mb-8"
        >
          Old Password <span className="text-danger-600">*</span>
        </label>
        <div className="position-relative">
          <input
            name="oldPassword"
            type={visible.oldPassword ? "text" : "password"}
            className={`form-control radius-8 ${errors.oldPassword ? "is-invalid" : ""
              }`}
            id="oldPassword"
            placeholder="Enter Old Password*"
            value={payload.oldPassword}
            onChange={handleChange}
          />
          <span
            className={`toggle-password ri ${visible.oldPassword ? "ri-eye-off-line" : "ri-eye-line"
              } cursor-pointer position-absolute end-0 top-50 translate-middle-y me-16 text-secondary-light`}
            onClick={() => updateVisible("oldPassword")}
          ></span>
          {errors.oldPassword && (
            <div className="invalid-feedback">{errors.oldPassword}</div>
          )}
        </div>
      </div>

      {/* New Password */}
      <div className="mb-20">
        <label
          htmlFor="newPassword"
          className="form-label fw-semibold text-primary-light text-sm mb-8"
        >
          New Password <span className="text-danger-600">*</span>
        </label>
        <div className="position-relative">
          <input
            name="newPassword"
            type={visible.newPassword ? "text" : "password"}
            className={`form-control radius-8 ${errors.newPassword ? "is-invalid" : ""
              }`}
            id="newPassword"
            placeholder="Enter New Password*"
            value={payload.newPassword}
            onChange={handleChange}
          />
          <span
            className={`toggle-password ri ${visible.newPassword ? "ri-eye-off-line" : "ri-eye-line"
              } cursor-pointer position-absolute end-0 top-50 translate-middle-y me-16 text-secondary-light`}
            onClick={() => updateVisible("newPassword")}
          ></span>
          {errors.newPassword && (
            <div className="invalid-feedback">{errors.newPassword}</div>
          )}
        </div>
      </div>

      {/* Confirm Password */}
      <div className="mb-20">
        <label
          htmlFor="confirmPassword"
          className="form-label fw-semibold text-primary-light text-sm mb-8"
        >
          Confirm Password <span className="text-danger-600">*</span>
        </label>
        <div className="position-relative">
          <input
            name="confirmPassword"
            type={visible.confirmPassword ? "text" : "password"}
            className={`form-control radius-8 ${errors.confirmPassword ? "is-invalid" : ""
              }`}
            id="confirmPassword"
            placeholder="Confirm Password*"
            value={payload.confirmPassword}
            onChange={handleChange}
          />
          <span
            className={`toggle-password ri ${visible.confirmPassword ? "ri-eye-off-line" : "ri-eye-line"
              } cursor-pointer position-absolute end-0 top-50 translate-middle-y me-16 text-secondary-light`}
            onClick={() => updateVisible("confirmPassword")}
          ></span>
          {errors.confirmPassword && (
            <div className="invalid-feedback">{errors.confirmPassword}</div>
          )}
        </div>
      </div>

      {/* Submit (logic pending - you can replace with real API call) */}
      <div className="d-flex justify-content-center gap-3 mt-4">
        <button
          type="button"
          className="btn btn-primary border border-primary-600 text-md px-56 py-12 radius-8"
          onClick={handlePassword}
        >
          Change Password
        </button>
      </div>
    </>
  );
}
