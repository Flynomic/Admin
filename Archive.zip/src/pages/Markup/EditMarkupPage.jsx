import React from "react";
import MasterLayout from "../../masterLayout/MasterLayout";
import Breadcrumb from "../../components/Breadcrumb";
import { useParams } from "react-router-dom";
import EditMarkupLayer from "../../components/Markup/EditMarkupLayer";

const EditMarkupPage = () => {
  const { id } = useParams("id");

  console.log("id", id);

  return (
    <>
      {/* MasterLayout */}
      <MasterLayout>
        {/* Breadcrumb */}
        <Breadcrumb title="Edit Markup" />

        <EditMarkupLayer id={id} />
      </MasterLayout>
    </>
  );
};

export default EditMarkupPage;
