import React from "react";
import MasterLayout from "../../masterLayout/MasterLayout";
import Breadcrumb from "../../components/Breadcrumb";
import { useLocation, useParams } from "react-router-dom";
import ViewFlightBookingLayer from "./ViewFlightBookingLayer";
import { BOOKING_PAGE_TYPE } from "../../utils/constant";

const ViewFlightBookingPage = () => {
  const { id } = useParams("id");
  const location = useLocation();
  const { pageType } = location.state || {}

  return (
    <>
      {/* MasterLayout */}
      <MasterLayout>
        {/* Breadcrumb */}
        <Breadcrumb title={`Flight Booking ${pageType === BOOKING_PAGE_TYPE.REFUND ? "Refund" : "View"}`} />

        <ViewFlightBookingLayer id={id} pageType={pageType} />
      </MasterLayout>
    </>
  );
};

export default ViewFlightBookingPage;
