import React from "react";
import MasterLayout from "../../masterLayout/MasterLayout";
import Breadcrumb from "../../components/Breadcrumb";
import FlightListLayer from "./FlightListLayer";

const FlightListPage = () => {
  return (
    <>
      {/* MasterLayout */}
      <MasterLayout>
        {/* Breadcrumb */}
        <Breadcrumb title="Flight Booking Management" />

        <FlightListLayer />
      </MasterLayout>
    </>
  );
};

export default FlightListPage;
