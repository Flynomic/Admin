import { Icon } from "@iconify/react/dist/iconify.js";
import React, { useEffect, useState } from "react";
import useApi from "../../hook/useApi";
import Paggination from "../../components/Paggination";
import { useNavigate } from "react-router-dom";
import Loader from "../../components/Loader/Loader";
import { BOOKING_PAGE_TYPE, CURRENCY_CODE, FLIGHT_BOOKING_STATUS, REFUND_STATUS } from "../../utils/constant";
import { findAirport } from 'aircodes';

const FlightListLayer = () => {
  const { AsyncGetApiCall } = useApi();
  const navigate = useNavigate();

  const [query, setQuery] = useState({
    pageNo: 1,
    limitVal: 50,
    search: "",
    refundStatus: "",
  });
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState(null);

  const getAllBookingList = async () => {
    setLoading(true);
    const result = await AsyncGetApiCall("/flight/bookings", query);
    console.log("Result : ", result);

    if (result.success) {
      setData(result);
    }
    setLoading(false);
  };

  const setPageNo = (pageNo) => {
    setQuery((prev) => ({
      ...prev,
      pageNo: pageNo,
    }));
  };

  useEffect(() => {
    getAllBookingList();
  }, [query]);

  console.log("data : ", data);

  const handleRefundStatusChange = (e) => {
    setQuery((prev) => ({
      ...prev,
      refundStatus: e.target.value === "Select Refund Status" ? "" : e.target.value,
      pageNo: 1, // Reset to first page on status change
    }));
  };

  const findAirport = async () => {
    const airportInfo = await findAirport('LHR'); // Returns an array of matching airports
    console.log("airportInfo", airportInfo);
    if (airportInfo.length > 0) {
      const airportName = airportInfo[0].name; // e.g., "London Heathrow Airport"
      console.log("airportName", airportName);
    }
  }

  useEffect(() => {
    findAirport();
  }, []);

  return (
    <>
      {loading && <Loader />}
      <div className="card h-100 p-0 radius-12">
        <div className="card-header border-bottom bg-base py-16 px-24 d-flex align-items-center flex-wrap gap-3 justify-content-between">
          <div className="d-flex align-items-center flex-wrap gap-3">
            <span className="text-md fw-medium text-secondary-light mb-0">
              Show
            </span>
            <select
              className="form-select form-select-sm w-auto ps-12 py-6 radius-12 h-40-px"
              defaultValue="Select Number"
              onChange={(e) => {
                const value = parseInt(e.target.value, 10);
                setQuery((prev) => ({
                  ...prev,
                  limitVal: value,
                }));
              }}>
              <option value="Select Number" disabled>
                Select Number
              </option>
              {Array.from({ length: 20 }, (_, i) => {
                const value = (i + 1) * 5;
                return (
                  <option key={value} value={value}>
                    {value}
                  </option>
                );
              })}
            </select>
            <form className="navbar-search">
              <input
                type="text"
                className="bg-base h-40-px w-auto"
                name="search"
                placeholder="Search by MF No."
                value={query.search}
                onChange={(e) => {
                  setQuery((prev) => ({
                    ...prev,
                    search: e.target.value,
                  }));
                }}
              />
              <Icon icon="ion:search-outline" className="icon" />
            </form>
            <select
              className="form-select w-auto form-select-sm ps-12 py-6 radius-12 h-40-px"
              value={query.refundStatus || "Select Refund Status"}
              onChange={handleRefundStatusChange}>
              <option value="Select Refund Status">Select Refund Status</option>
              <option value="completed">Completed</option>
              <option value="pending">Pending</option>
              <option value="not_applicable">Not Applicable</option>
              <option value="failed">Failed</option>
              <option value="rejected">Rejected</option>
            </select>
          </div>
        </div>
        <div className="card-body p-24">
          <div className="table-responsive scroll-sm">
            <table className="table bordered-table sm-table mb-0">
              <thead>
                <tr>
                  <th scope="col">
                    <div className="d-flex align-items-center gap-10">S.No</div>
                  </th>
                  <th scope="col">Mystifly Reference</th>
                  <th scope="col">Booking Date</th>
                  <th scope="col">Email</th>
                  <th scope="col">Origin</th>
                  <th scope="col">Destination</th>
                  <th scope="col">Trip Type</th>
                  <th scope="col">Paid Amount</th>
                  <th scope="col">Original Amount</th>
                  <th scope="col">Booking Status</th>
                  <th scope="col">Refund Status</th>
                  <th scope="col" className="text-center">
                    Action
                  </th>
                </tr>
              </thead>
              <tbody>
                {data && data.data.length > 0 ? (
                  data.data.map((item, index) => (
                    <tr key={item._id}>
                      <td>
                        <div className="d-flex align-items-center gap-10">
                          {(data?.currentPage - 1) * query.limitVal + index + 1}
                        </div>
                      </td>
                      <td
                        onClick={(e) => {
                          e.preventDefault();
                          navigate(
                            "/flight-booking/view-booking/" + item._id
                          );
                        }}
                        style={{ cursor: "pointer" }} // Default cursor
                        onMouseEnter={(e) => (e.target.style.cursor = "pointer")} // Ensure pointer on hover
                        onMouseLeave={(e) => (e.target.style.cursor = "default")} // Optional: reset on leave
                      >
                        {item?.tripDetails?.TravelItinerary?.MFRef || "N/A"}
                      </td>
                      <td>{new Date(item.createdAt).toLocaleDateString()}</td>
                      <td>{item?.userId?.email || "N/A"}</td>
                      <td>{item?.tripDetails?.TravelItinerary?.Origin || "N/A"}</td>
                      <td>{item?.tripDetails?.TravelItinerary?.Destination || "N/A"}</td>
                      <td>{item?.tripDetails?.TravelItinerary?.TripType || "N/A"}</td>
                      <td>{`${CURRENCY_CODE[item?.txData?.paidCurrency] || ""} ${Number(item?.txData?.paidAmount).toFixed(2) || "N/A"}`}</td>
                      <td>{`${CURRENCY_CODE[item?.txData?.originalCurrency] || ""} ${Number(item?.txData?.originalAmount).toFixed(2) || "N/A"}`}</td>
                      <td>
                        <span
                          className={`badge ${item?.tripDetails?.TravelItinerary?.BookingStatus === FLIGHT_BOOKING_STATUS.BOOKED
                            ? "bg-success-100 text-success-600"
                            : item?.tripDetails?.TravelItinerary?.BookingStatus === FLIGHT_BOOKING_STATUS.PENDING
                              ? "bg-warning-100 text-warning-600"
                              : "bg-danger-100 text-danger-600"
                            } text-sm py-4 px-10 radius-4`}>
                          {item?.tripDetails?.TravelItinerary?.BookingStatus}
                        </span>
                      </td>
                      <td className="text-center">
                        <span
                          className={`badge ${item?.refundStatus === 'completed'
                            ? 'bg-success-100 text-success-600'
                            : item?.refundStatus === 'pending'
                              ? 'bg-warning-100 text-warning-600'
                              : item?.refundStatus === 'not_applicable'
                                ? 'bg-primary-300 text-secondary-600'
                                : item?.refundStatus === 'failed' || item?.refundStatus === 'rejected'
                                  ? 'bg-danger-100 text-danger-600'
                                  : 'background-gray-100'
                            } text-sm py-4 px-10 radius-4`}
                        >
                          {REFUND_STATUS[item?.refundStatus] || 'None'}
                        </span>
                      </td>
                      <td className="text-center">
                        <div className="d-flex align-items-center gap-10 justify-content-center">
                          {item?.refundStatus === "pending" && (
                            <button
                              type="button"
                              className=" text-success-600 bg-hover-success-200 fw-medium w-40-px h-40-px d-flex justify-content-center align-items-center rounded-circle"
                              style={{ backgroundColor: "rgb(238, 242, 208)" }}
                              onClick={(e) => {
                                e.preventDefault();
                                navigate(`/flight-booking/view-booking/${item._id}`,
                                  {
                                    state: { pageType: BOOKING_PAGE_TYPE.REFUND }, // Pass the item as state
                                  })
                              }}
                            >
                              <Icon
                                icon="mdi:cash"
                                className="icon text-xl"
                              />
                              <span className="tooltip-text">Refund</span>
                            </button>
                          )}
                          <button
                            type="button"
                            className="bg-info-focus bg-hover-info-200 text-info-600 fw-medium w-40-px h-40-px d-flex justify-content-center align-items-center rounded-circle"
                            onClick={() => {
                              navigate(
                                "/flight-booking/view-booking/" + item._id
                              );
                            }}
                          >
                            <Icon
                              icon="majesticons:eye-line"
                              className="icon text-xl"
                            />
                            <span className="tooltip-text">View</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="6" className="text-center">
                      No data found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          <Paggination
            total={data?.total || 0}
            totalPages={data?.totalPages || 0}
            currentPage={data?.currentPage || 0}
            setPageNo={setPageNo}
            startFrom={(data?.currentPage - 1) * query.limitVal + 1}
            endTo={
              (data?.currentPage - 1) * query.limitVal + data?.data?.length
            }
          />
        </div>
      </div>
    </>
  );
};

export default FlightListLayer;
