import React, { useEffect, useState } from "react";
import useApi from "../../hook/useApi";
import GeneralDetails from "./FormData/GeneralDetails";
import dayjs from "dayjs";
import { BOOKING_PAGE_TYPE, CURRENCY_CODE } from "../../utils/constant";
import { toast } from "react-toastify";
import { Icon } from "@iconify/react";
import Loader from "../../components/Loader/Loader";

const ViewFlightBookingLayer = ({ id, pageType }) => {
  const { AsyncGetApiCall, AsyncPostApiCall } = useApi();
  const [booking, setBooking] = useState(null);
  const [loading, setLoading] = useState(false);
  const [cancellationPercent, setCancellationPercent] = useState(""); // Initial 1%
  const [cancellationAmount, setCancellationAmount] = useState("");
  const [refundStatus, setRefundStatus] = useState("");
  const [refundAmount, setRefundAmount] = useState(0);

  const getFlightBookingData = async () => {
    if (!id) return;
    setLoading(true);
    const result = await AsyncGetApiCall(`/flight/get-booking/${id}`);
    if (result?.success) {
      setBooking(result.booking)
      const txData = result?.booking?.txData
      setCancellationPercent(txData?.cancellationCharge || 1);
      const cancellationAmount = txData?.paidAmount * (txData.cancellationCharge / 100)
      setCancellationAmount(cancellationAmount || 0);
      setRefundAmount(txData?.refundAmount || 0);
      setRefundStatus(result?.booking?.refundStatus);
    };
    setLoading(false);
  };

  useEffect(() => {
    getFlightBookingData();
  }, [id]);

  if (loading) return <Loader />;
  if (!booking) return <p className="text-center my-5">No data found.</p>;

  console.log("booking", booking)

  return (
    <div className="row gy-4">
      <GeneralDetails booking={booking} />

      {/* 🔻 More purpose-built sections that read from booking */}
      <ItineraryDetails
        segments={
          booking?.tripDetails?.TravelItinerary?.Itineraries?.[0]
            ?.ItineraryInfo?.ReservationItems || []
        }
      />

      <FareBreakdown
        txData={
          booking?.txData
        }
        pageType={pageType}
        id={booking?._id}
        cancellationPercent={cancellationPercent}
        cancellationAmount={cancellationAmount}
        setCancellationPercent={setCancellationPercent}
        setCancellationAmount={setCancellationAmount}
        refundStatus={refundStatus}
        setRefundStatus={setRefundStatus}
        getFlightBookingData={getFlightBookingData}
        refundAmount={refundAmount}
        setRefundAmount={setRefundAmount}
      />

      <PassengerDetails
        passengers={
          booking?.tripDetails?.TravelItinerary?.PassengerInfos || []
        }
      />
    </div>
  );
};

export default ViewFlightBookingLayer;


const ItineraryDetails = ({ segments }) => (
  <div className="col-12">
    <div className="card">
      <div className="card-header">
        <h5 className="card-title mb-0">Itinerary</h5>
      </div>
      <div className="card-body">
        {segments.length === 0 && <p>No segments</p>}
        {segments.map((s, i) => (
          <p key={i}>
            {s.DepartureAirportLocationCode} → {s.ArrivalAirportLocationCode}{" "}
            ({s.MarketingAirlineCode}
            {s.FlightNumber}) – {dayjs(s.DepartureDateTime).format("DD MMM HH:mm")}
          </p>
        ))}
      </div>
    </div>
  </div>
);

const FareBreakdown = ({ txData, pageType, id, cancellationPercent, cancellationAmount, setCancellationPercent, setCancellationAmount, refundStatus, setRefundStatus, getFlightBookingData, refundAmount, setRefundAmount }) => {
  const {
    AsyncPostApiCall
  } = useApi();

  const [loading, setLoading] = useState(false);

  // Calculate initial amount based on 1% of paidAmount
  useEffect(() => {
    if (txData?.paidAmount && refundStatus !== "completed") {
      const initialPercent = 1; // Set initial percent to 1
      setCancellationPercent(initialPercent);
      const initialAmount = (txData.paidAmount * initialPercent) / 100; // Calculate amount based on 1%
      setCancellationAmount(Number(initialAmount.toFixed(2)));
      const refundAmount = txData.paidAmount - initialAmount
      setRefundAmount(Number(refundAmount.toFixed(2)));
    }
  }, [txData?.paidAmount, setCancellationAmount, setCancellationPercent]);

  // Handle percentage change with clearing logic
  const handlePercentChange = (e) => {
    const value = e.target.value;
    if (value === '' || value === null) {
      setCancellationPercent(0); // Clear to 0 when empty
      setCancellationAmount(0); // Reset amount when percent is cleared
      setRefundAmount(0);
    } else {
      // Remove extra decimal places and ensure valid number
      const sanitizedValue = Number(value.replace(/[^0-9.]/g, '')).toFixed(2); // Limit to 2 decimal places
      const percent = Math.max(1, Math.min(100, Number(sanitizedValue) || ""));
      setCancellationPercent(percent);
      if (txData?.paidAmount && txData.paidAmount > 0) {
        const newAmount = (txData.paidAmount * percent) / 100;
        setCancellationAmount(Number(newAmount.toFixed(2)));
        const refundAmount = txData.paidAmount - newAmount
        setRefundAmount(Number(refundAmount.toFixed(2)));
      }
    }
  };

  // Handle amount change with clearing logic
  const handleAmountChange = (e) => {
    const value = e.target.value;
    if (value === '' || value === null) {
      setCancellationPercent(0); // Clear to 0 when empty
      setCancellationAmount(0); // Reset amount when percent is cleared
      setRefundAmount(0);
    } else {
      // Remove extra decimal places and ensure valid number
      const sanitizedValue = Number(value.replace(/[^0-9.]/g, '')).toFixed(2); // Limit to 2 decimal places
      const amount = Math.max(0, Math.min(txData?.paidAmount || "", Number(sanitizedValue) || ""));
      setCancellationAmount(Number(amount.toFixed(2)));
      if (txData?.paidAmount && txData.paidAmount > 0) {
        const newPercent = (amount / txData.paidAmount) * 100;
        setCancellationPercent(Number(newPercent.toFixed(2)));
        const refundAmount = txData.paidAmount - amount
        setRefundAmount(Number(refundAmount.toFixed(2)));
      }
    }
  };

  // Toggle edit mode and mark as used
  const handleRefund = async () => {
    try {
      if (cancellationPercent < 1) {
        toast.error("Cancellation charge must be between 1 and 100");
        return;
      }
      setLoading(true);
      const payload = {
        id: id,
        model: "FLIGHT",
        cancellationCharge: cancellationPercent
      };

      const result = await AsyncPostApiCall(`/hotel-booking/initiate-refund`, payload);

      if (result?.success) {
        toast.success(result.message);
        const txData = result?.data?.txData
        setCancellationPercent(txData?.cancellationCharge || 1);
        const cancellationAmount = txData?.paidAmount * (txData.cancellationCharge / 100)
        setCancellationAmount(cancellationAmount || 0);
        setRefundAmount(txData?.refundAmount || 0);
        setRefundStatus(result?.data?.refundStatus);
        getFlightBookingData();
      } else {
        toast.error(result?.errors?.[0] || "Something went wrong");
      }
    } catch (error) {
      console.error("Something went wrong", error);
      toast.error("Failed to update booking data.");
    } finally {
      setLoading(false);
    }
  };

  // Cleanup effect to clear inputs when leaving the page
  useEffect(() => {
    return () => {
      setCancellationPercent(""); // Clear percent when component unmounts
      setCancellationAmount(""); // Clear amount when component unmounts
    };
  }, [setCancellationPercent, setCancellationAmount]);

  console.log("cancellationPercent", cancellationPercent)
  console.log("cancellationAmount", cancellationAmount)

  return (
    <>
      {loading && <Loader />}
      <div className="col-12">
        <div className="card">
          <div className="card-header">
            <h5 className="card-title mb-0">Fare Breakdown</h5>
          </div>
          <div className="card-body">
            <div className="row gy-3">
              <div className="col-md-6">
                <label className="form-label">Paid Amount</label>
                <p className="text-secondary-light">
                  {`${txData?.paidAmount ? CURRENCY_CODE[txData?.paidCurrency] : ""} ${Number(txData?.paidAmount).toFixed(2) || "N/A"
                    }`}
                </p>
              </div>
              <div className="col-md-6">
                <label className="form-label">Payment Method</label>
                <p className="text-secondary-light">
                  {txData?.paymentMethod.toUpperCase() || "N/A"}
                </p>
              </div>
              <div className="col-md-6">
                <label className="form-label">Original Amount</label>
                <p className="text-secondary-light">
                  {`${txData?.originalAmount ? CURRENCY_CODE[txData?.originalCurrency] : ""} ${Number(txData?.originalAmount).toFixed(2) || "N/A"
                    }`}
                </p>
              </div>
              {txData?.coupon?.couponApplied && txData?.couponAmount ? (
                <div className="col-md-6">
                  <label className="form-label">Discounts</label>
                  <p className="text-secondary-light">
                    - {CURRENCY_CODE[txData?.paidCurrency]} {txData?.couponAmount}
                  </p>
                </div>
              ) : (
                <div className="col-md-6">
                  <p className="text-secondary-light">No discounts applied.</p>
                </div>
              )}
              {(pageType === BOOKING_PAGE_TYPE.REFUND || refundStatus === "completed") && (
                <div className="col-md-6">
                  <label className="form-label" style={{ marginBottom: '5px' }}>
                    {refundStatus === "completed" ? "Initiated Refund (Including Charges)" : "Initiate Refund (Apply Cancellation Charge)"}
                  </label>
                  <div className="card" style={{ padding: '15px', marginBottom: '15px', margin: '0 auto' }}>
                    <div className="d-flex flex-column align-items-start" style={{ marginBottom: '10px' }}>
                      <span className="text-secondary-light" style={{ marginBottom: '5px', fontSize: '14px', color: '#6c757d' }}>Charges:</span>
                      <div className="input-group flex-nowrap" style={{ width: '50%', padding: '5px 0' }}>
                        <input
                          type="number"
                          className="form-control"
                          value={cancellationPercent || ''}
                          onChange={handlePercentChange}
                          min="1"
                          max="100"
                          step="0.01"
                          onKeyDown={(e) => ["e", "E", "+", "-"].includes(e.key) && e.preventDefault()}
                          placeholder="%"
                          style={{ maxWidth: '80px', padding: '6px 10px', fontSize: '14px' }}
                          disabled={refundStatus === "completed"}
                        />
                        <span className="input-group-text" style={{ padding: '6px 10px', backgroundColor: '#f8f9fa', border: '1px solid #ced4da' }}>%</span>
                        <input
                          type="number"
                          className="form-control"
                          value={refundStatus === "completed" ? cancellationAmount.toFixed(2) : cancellationAmount || ''}
                          onChange={handleAmountChange}
                          min="0"
                          max={txData?.paidAmount || 2000}
                          step="0.01"
                          onKeyDown={(e) => ["e", "E", "+", "-"].includes(e.key) && e.preventDefault()}
                          placeholder="Amount"
                          style={{ maxWidth: '100px', padding: '6px 10px', fontSize: '14px' }}
                          disabled={refundStatus === "completed"}
                        />
                        <span className="input-group-text" style={{ padding: '6px 10px', backgroundColor: '#f8f9fa', border: '1px solid #ced4da' }}>
                          {txData?.paidCurrency ? CURRENCY_CODE[txData.paidCurrency] : ""}
                        </span>
                      </div>
                      <span className="text-secondary-light" style={{ marginBottom: '5px', fontSize: '14px', color: '#6c757d' }}>Refund Amount:</span>
                      <div className="input-group flex-nowrap" style={{ width: '50%', padding: '5px 0' }}>
                        <input
                          type="number"
                          className="form-control"
                          value={refundAmount.toFixed(2)}
                          style={{ maxWidth: '180px', padding: '6px 10px', fontSize: '14px' }}
                          disabled
                        />
                      </div>
                    </div>
                    <span className="text-secondary-light" style={{ marginBottom: '5px', fontSize: '14px', color: '#6c757d' }}>User have paid {txData?.paidAmount} {txData?.paidCurrency} for this booking, after deducting {cancellationAmount.toFixed(2)} {txData?.paidCurrency} ({cancellationPercent}%) as cancellation charge, {refundAmount.toFixed(2)} {txData?.paidCurrency} is the refunded amount.</span>
                    <div className="d-flex justify-content-center" style={{ marginTop: '15px' }}>
                      {refundStatus !== "completed" && (
                        <button
                          className="btn btn-primary"
                          onClick={() => {
                            if (window.confirm("Are you sure you want to initiate refund?")) { handleRefund() }
                          }}
                          disabled={refundStatus === "completed" || cancellationPercent < 1}
                          style={{ minWidth: '100px', padding: '6px 15px' }}
                        >
                          Submit
                        </button>
                      )}
                    </div>
                  </div>
                </div>
                // <div className="col-md-6">
                //   <label className="form-label">
                //     {refundStatus === "completed" ? "Initiated Refund (Including Charges)" : "Initiate Refund (Apply Cancellation Charge)"}
                //   </label>
                //   <div className="d-flex gap-2 align-items-center">
                //     <>
                //       <span className="text-secondary-light">Cancellation Charge:</span>
                //       <input
                //         type="number"
                //         className="form-control"
                //         value={cancellationPercent || ''} // Show empty string when cleared
                //         onChange={handlePercentChange}
                //         min="1"
                //         max="100"
                //         step="0.01"
                //         onKeyDown={(e) => ["e", "E", "+", "-"].includes(e.key) && e.preventDefault()}
                //         placeholder="%"
                //         style={{ width: '100px' }}
                //         disabled={refundStatus === "completed"}
                //       />
                //       <span className="text-secondary-light">%</span>
                //       <span className="text-secondary-light mx-3">=</span>
                //       <input
                //         type="number"
                //         className="form-control"
                //         value={refundStatus === "completed" ? cancellationAmount.toFixed(2) : cancellationAmount || ''} // Show empty string when cleared
                //         onChange={handleAmountChange}
                //         min="0"
                //         max={txData?.paidAmount || 2000}
                //         step="0.01"
                //         onKeyDown={(e) => ["e", "E", "+", "-"].includes(e.key) && e.preventDefault()}
                //         placeholder="Amount"
                //         style={{ width: '150px' }}
                //         disabled={refundStatus === "completed"}
                //       />
                //       <span className="text-secondary-light">
                //         {txData?.paidCurrency ? CURRENCY_CODE[txData?.paidCurrency] : ""}
                //       </span>
                //       {refundStatus !== "completed" && (
                //         <button
                //           className="btn btn-primary"
                //           onClick={
                //             () => {
                //               if (window.confirm("Are you sure you want to initiate refund?")) { handleRefund() }
                //             }}
                //           disabled={refundStatus === "completed" || cancellationPercent < 1}
                //           style={{ marginRight: "10px" }}
                //         >
                //           Submit
                //         </button>
                //       )}
                //     </>
                //   </div>
                // </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

const PassengerDetails = ({ passengers }) => (
  <div className="col-12">
    <div className="card">
      <div className="card-header">
        <h5 className="card-title mb-0">Passengers</h5>
      </div>
      <div className="card-body">
        {passengers.length === 0 && <p>No passengers</p>}
        {passengers.map((p, i) => (
          <div key={i} className="row gy-3 mb-4">
            <div className="col-md-6">
              <label className="form-label">Name</label>
              <p className="text-secondary-light">
                {`${p?.Passenger?.PaxName?.PassengerTitle} ${p?.Passenger?.PaxName?.PassengerFirstName} ${p?.Passenger?.PaxName?.PassengerLastName}` || "N/A"}
              </p>
            </div>
            <div className="col-md-6">
              <label className="form-label">Gender</label>
              <p className="text-secondary-light">{p?.Passenger?.Gender || "N/A"}</p>
            </div>
            <div className="col-md-6">
              <label className="form-label">Date of Birth</label>
              <p className="text-secondary-light">
                {p?.Passenger?.DateOfBirth
                  ? new Date(p?.Passenger?.DateOfBirth).toLocaleDateString()
                  : "N/A"}
              </p>
            </div>
            <div className="col-md-6">
              <label className="form-label">Email Address</label>
              <p className="text-secondary-light">{p?.Passenger?.EmailAddress || "N/A"}</p>
            </div>
            <div className="col-md-6">
              <label className="form-label">Phone Number</label>
              <p className="text-secondary-light">{p?.Passenger?.PhoneNumber || "N/A"}</p>
            </div>
            <div className="col-md-6">
              <label className="form-label">Passport Number</label>
              <p className="text-secondary-light">{p?.Passenger?.PassportNumber || "N/A"}</p>
            </div>
            <div className="col-md-6">
              <label className="form-label">Passport Expires On</label>
              <p className="text-secondary-light">
                {p?.Passenger?.PassportExpiresOn
                  ? new Date(p?.Passenger?.PassportExpiresOn).toLocaleDateString()
                  : "N/A"}
              </p>
            </div>
            <div className="col-md-6">
              <label className="form-label">Nationality</label>
              <p className="text-secondary-light">{p?.Passenger?.PassengerNationality || "N/A"}</p>
            </div>
            <div className="col-md-6">
              <label className="form-label">Ticket Status</label>
              <p className="text-secondary-light">{p?.Passenger?.TicketStatus || "N/A"}</p>
            </div>
            <div className="col-md-6">
              <label className="form-label">e-Ticket Number</label>
              <p className="text-secondary-light">
                {p?.ETickets?.[0]?.ETicketNumber || "N/A"}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  </div>
);