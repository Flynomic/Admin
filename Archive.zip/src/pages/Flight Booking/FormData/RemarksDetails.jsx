import { Icon } from "@iconify/react/dist/iconify.js";
import React from "react";

const RemarksDetails = ({ data }) => {
  const remarks = data?.general || [];

  return (
    <div className="col-md-12">
      <div className="card">
        <div className="card-header">
          <h5 className="card-title mb-0">Remarks</h5>
        </div>
        <div className="card-body">
          {remarks.length === 0 ? (
            <p className="text-muted">No remarks available</p>
          ) : (
            remarks.map((remark, index) => (
              <div
                key={index}
                className={`row gy-3 ${
                  index > 0 ? "mt-4 pt-4 border-top" : ""
                }`}
                role="group"
                aria-labelledby={`remark-${index}-header`}
              >
                <p id={`remark-${index}-header`} className="col-12">
                  Remark {index + 1}
                </p>
                <div className="col-6">
                  <label className="form-label">Sub Type</label>
                  <div className="icon-field">
                    <span className="icon">
                      <Icon icon="f7:info-circle" />
                    </span>
                    <span className="form-control form-control-readonly">
                      {remark.subType || "N/A"}
                    </span>
                  </div>
                </div>
                <div className="col-6">
                  <label className="form-label">Text</label>
                  <div className="icon-field">
                    <span className="icon">
                      <Icon icon="solar:text-linear" />
                    </span>
                    <span className="form-control form-control-readonly">
                      {remark.text || "N/A"}
                    </span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default RemarksDetails;
