import { Icon } from "@iconify/react/dist/iconify.js";
import React from "react";

const AutomatedProcessDetails = ({ data }) => {
  const automatedProcesses = Array.isArray(data) ? data : [];

  return (
    <div className="col-md-12">
      <div className="card">
        <div className="card-header">
          <h5 className="card-title mb-0">Automated Process</h5>
        </div>
        <div className="card-body">
          {automatedProcesses.length === 0 ? (
            <p className="text-muted">
              No automated process information available
            </p>
          ) : (
            automatedProcesses.map((process, index) => (
              <div
                key={index}
                className={`row gy-3 ${
                  index > 0 ? "mt-4 pt-4 border-top" : ""
                }`}
                role="group"
                aria-labelledby={`process-${index}-header`}
              >
                <p id={`process-${index}-header`} className="col-12">
                  Automated Process {index + 1}
                </p>
                <div className="col-4">
                  <label className="form-label">Code</label>
                  <div className="icon-field">
                    <span className="icon">
                      <Icon icon="f7:info-circle" />
                    </span>
                    <span className="form-control form-control-readonly">
                      {process.code || "N/A"}
                    </span>
                  </div>
                </div>
                <div className="col-4">
                  <label className="form-label">Queue</label>
                  <div className="icon-field">
                    <span className="icon">
                      <Icon icon="solar:sort-linear" />
                    </span>
                    <span className="form-control form-control-readonly">
                      {process.queue
                        ? `${process.queue.number}/${process.queue.category}`
                        : "N/A"}
                    </span>
                  </div>
                </div>
                <div className="col-4">
                  <label className="form-label">Office ID</label>
                  <div className="icon-field">
                    <span className="icon">
                      <Icon icon="solar:buildings-linear" />
                    </span>
                    <span className="form-control form-control-readonly">
                      {process.officeId || "N/A"}
                    </span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default AutomatedProcessDetails;
