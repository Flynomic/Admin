import { Icon } from "@iconify/react/dist/iconify.js";
import React from "react";

const ContactsDetails = ({ data }) => {
  const contacts = Array.isArray(data) ? data : [];

  return (
    <div className="col-md-12">
      <div className="card">
        <div className="card-header">
          <h5 className="card-title mb-0">Contacts</h5>
        </div>
        <div className="card-body">
          {contacts.length === 0 ? (
            <p className="text-muted">No contact information available</p>
          ) : (
            contacts.map((contact, index) => (
              <div
                key={index}
                className={`row gy-3 ${
                  index > 0 ? "mt-4 pt-4 border-top" : ""
                }`}
                role="group"
                aria-labelledby={`contact-${index}-header`}
              >
                <p id={`contact-${index}-header`} className="col-12">
                  Contact {index + 1}
                </p>
                <div className="col-4">
                  <label className="form-label">Addressee Name</label>
                  <div className="icon-field">
                    <span className="icon">
                      <Icon icon="f7:person" />
                    </span>
                    <span className="form-control form-control-readonly">
                      {contact.addresseeName?.firstName || "N/A"}
                    </span>
                  </div>
                </div>
                <div className="col-4">
                  <label className="form-label">Company Name</label>
                  <div className="icon-field">
                    <span className="icon">
                      <Icon icon="solar:buildings-linear" />
                    </span>
                    <span className="form-control form-control-readonly">
                      {contact.companyName || "N/A"}
                    </span>
                  </div>
                </div>
                <div className="col-4">
                  <label className="form-label">Email</label>
                  <div className="icon-field">
                    <span className="icon">
                      <Icon icon="mage:email" />
                    </span>
                    <span className="form-control form-control-readonly">
                      {contact.emailAddress || "N/A"}
                    </span>
                  </div>
                </div>
                <div className="col-6">
                  <label className="form-label">Address</label>
                  <div className="icon-field">
                    <span className="icon">
                      <Icon icon="solar:map-point-linear" />
                    </span>
                    <span className="form-control form-control-readonly">
                      {contact.address
                        ? `${contact.address.lines?.join(", ")}, ${
                            contact.address.cityName
                          }, ${contact.address.postalCode}, ${
                            contact.address.countryCode
                          }`
                        : "N/A"}
                    </span>
                  </div>
                </div>
                <div className="col-6">
                  <label className="form-label">Phones</label>
                  <div className="icon-field">
                    <span className="icon">
                      <Icon icon="solar:phone-calling-linear" />
                    </span>
                    <span className="form-control form-control-readonly">
                      {contact.phones?.length > 0
                        ? contact.phones
                            .map(
                              (phone) =>
                                `${phone.deviceType}: ${phone.countryCallingCode} ${phone.number}`
                            )
                            .join(", ")
                        : "N/A"}
                    </span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default ContactsDetails;
