import { Icon } from "@iconify/react/dist/iconify.js";
import React from "react";

const TicketingAgreementDetails = ({ data }) => {
  const ticketingAgreement = data || {};

  return (
    <div className="col-md-12">
      <div className="card">
        <div className="card-header">
          <h5 className="card-title mb-0">Ticketing Agreement</h5>
        </div>
        <div className="card-body">
          {Object.keys(ticketingAgreement).length === 0 ? (
            <p className="text-muted">
              No ticketing agreement information available
            </p>
          ) : (
            <div
              className="row gy-3"
              role="group"
              aria-labelledby="ticketing-agreement-header"
            >
              <p id="ticketing-agreement-header" className="col-12">
                Ticketing Agreement Details
              </p>
              <div className="col-6">
                <label className="form-label">Option</label>
                <div className="icon-field">
                  <span className="icon">
                    <Icon icon="f7:info-circle" />
                  </span>
                  <span className="form-control form-control-readonly">
                    {ticketingAgreement.option || "N/A"}
                  </span>
                </div>
              </div>
              <div className="col-6">
                <label className="form-label">Delay</label>
                <div className="icon-field">
                  <span className="icon">
                    <Icon icon="solar:clock-circle-linear" />
                  </span>
                  <span className="form-control form-control-readonly">
                    {ticketingAgreement.delay || "N/A"}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TicketingAgreementDetails;
