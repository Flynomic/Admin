import { Icon } from "@iconify/react";
import dayjs from "dayjs";
import React from "react";
import { MdOutlineAirlineSeatReclineNormal } from "react-icons/md";
import { CABIN_PREFERENCE } from "../../../utils/constant";

const Field = ({ label, value, icon = "ph:info" }) => (
  <div className="col-lg-3 col-md-4 col-sm-6">
    <label className="form-label">{label}</label>
    <div className="icon-field">
      <span className="icon">
        {label === "Cabin Class" ? <MdOutlineAirlineSeatReclineNormal /> :
          <Icon icon={icon} width="20" height="20" />}
      </span>
      <span className="form-control form-control-readonly">{value ?? "—"}</span>
    </div>
  </div>
);

const GeneralDetails = ({ booking }) => {
  const trip = booking?.tripDetails?.TravelItinerary;

  console.log("booking ------ : ", booking);

  const firstCabinClass = CABIN_PREFERENCE[booking?.tripDetails?.TravelItinerary?.Itineraries[0]?.ItineraryInfo?.ReservationItems[0]?.CabinClass] || "N/A";

  return (
    <div className="col-12">
      <div className="card">
        <div className="card-header">
          <h5 className="card-title mb-0">Booking Summary</h5>
        </div>

        <div className="card-body">
          <div className="row gy-3">
            <Field
              label="Booking ID"
              value={booking?._id}
              icon="mdi:identifier"
            />
            <Field
              label={
                booking?.userId?.walletAddress ? "User Wallet" : "User Email"
              }
              value={booking?.userId?.walletAddress || booking?.userId?.email}
              icon="tabler:wallet"
            />
            <Field
              label="Provider"
              value={booking?.tripDetails?.Provider}
              icon="ph:airplane"
            />
            <Field
              label="Trip Type"
              value={trip?.TripType}
              icon="mdi:family-tree"
            />
            {trip?.TicketStatus && (
              <Field
                label="Ticket Status"
                value={trip?.TicketStatus}
                icon="mdi:ticket-confirmation"
              />
            )}
            <Field
              label="Booking Status"
              value={trip?.BookingStatus}
              icon="material-symbols:event-available"
            />
            <Field
              label="Origin"
              value={trip?.Origin}
              icon="mdi:airplane-takeoff"
            />
            <Field
              label="Destination"
              value={trip?.Destination}
              icon="mdi:airplane-landing"
            />
            <Field
              label="Created On"
              value={dayjs(booking?.tripDetails?.BookingCreatedOn).format(
                "DD MMM YYYY HH:mm"
              )}
              icon="mdi:calendar-clock"
            />
            <Field
              label="Cabin Class"
              value={firstCabinClass}
            // icon={firstCabinClass}
            />
            <Field
              label="Refund Status"
              value={booking?.refundStatus === "not_applicable" ? "Not Applicable" : booking.refundStatus.charAt(0).toUpperCase() + booking.refundStatus.slice(1)}
              icon="mdi:cash"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default GeneralDetails;
