import { Icon } from "@iconify/react/dist/iconify.js";
import React from "react";

const FlightOfferDetails = ({ data }) => {
  const flightOffers = Array.isArray(data) ? data : [];

  const formatDateTime = (dateTime) => {
    if (!dateTime) return "N/A";
    return new Date(dateTime).toLocaleString("en-US", {
      dateStyle: "medium",
      timeStyle: "short",
    });
  };

  const formatDuration = (duration) => {
    if (!duration) return "N/A";
    const match = duration.match(/PT(\d+H)?(\d+M)?/);
    const hours = match[1] ? parseInt(match[1]) : 0;
    const minutes = match[2] ? parseInt(match[2]) : 0;
    return `${hours}h ${minutes}m`;
  };

  return (
    <div className="col-md-12">
      <div className="card">
        <div className="card-header">
          <h5 className="card-title mb-0">Flight Offer Details</h5>
        </div>
        <div className="card-body">
          {flightOffers.length === 0 ? (
            <p className="text-muted">No flight offer information available</p>
          ) : (
            flightOffers.map((offer, index) => (
              <div
                key={offer.id}
                className={`row gy-3 ${
                  index > 0 ? "mt-4 pt-4 border-top" : ""
                }`}
                role="group"
                aria-labelledby={`offer-${offer.id}-header`}
              >
                <p id={`offer-${offer.id}-header`} className="col-12">
                  Flight Offer {index + 1}
                </p>
                {/* General Flight Offer Info */}
                <div className="col-3">
                  <label className="form-label">Source</label>
                  <div className="icon-field">
                    <span className="icon">
                      <Icon icon="f7:info-circle" />
                    </span>
                    <span className="form-control form-control-readonly">
                      {offer.source || "N/A"}
                    </span>
                  </div>
                </div>
                <div className="col-3">
                  <label className="form-label">Last Ticketing Date</label>
                  <div className="icon-field">
                    <span className="icon">
                      <Icon icon="solar:calendar-linear" />
                    </span>
                    <span className="form-control form-control-readonly">
                      {offer.lastTicketingDate || "N/A"}
                    </span>
                  </div>
                </div>
                <div className="col-3">
                  <label className="form-label">Total Price</label>
                  <div className="icon-field">
                    <span className="icon">
                      <Icon icon="solar:tag-linear" />
                    </span>
                    <span className="form-control form-control-readonly">
                      {offer.price?.grandTotal} {offer.price?.currency}
                    </span>
                  </div>
                </div>
                <div className="col-3">
                  <label className="form-label">Validating Airline</label>
                  <div className="icon-field">
                    <span className="icon">
                      <Icon icon="f7:airplane" />
                    </span>
                    <span className="form-control form-control-readonly">
                      {offer.validatingAirlineCodes?.join(", ") || "N/A"}
                    </span>
                  </div>
                </div>

                {/* Itineraries */}
                {offer.itineraries?.map((itinerary, itinIndex) => (
                  <div
                    key={itinIndex}
                    className="col-12 mt-3"
                    aria-labelledby={`itinerary-${itinIndex}-header`}
                  >
                    <p id={`itinerary-${itinIndex}-header`}>
                      Itinerary {itinIndex + 1}
                    </p>
                    {itinerary.segments?.map((segment, segIndex) => (
                      <div
                        key={segment.id}
                        className="row gy-3 mb-3"
                        role="group"
                        aria-labelledby={`segment-${segment.id}-header`}
                      >
                        <p
                          id={`segment-${segment.id}-header`}
                          className="col-12 font-weight-bold"
                        >
                          Segment {segIndex + 1}
                        </p>
                        <div className="col-3">
                          <label className="form-label">Flight Number</label>
                          <div className="icon-field">
                            <span className="icon">
                              <Icon icon="f7:airplane" />
                            </span>
                            <span className="form-control form-control-readonly">
                              {segment.carrierCode}
                              {segment.number}
                            </span>
                          </div>
                        </div>
                        <div className="col-3">
                          <label className="form-label">Departure</label>
                          <div className="icon-field">
                            <span className="icon">
                              <Icon icon="solar:map-point-linear" />
                            </span>
                            <span className="form-control form-control-readonly">
                              {segment.departure?.iataCode} (
                              {formatDateTime(segment.departure?.at)})
                            </span>
                          </div>
                        </div>
                        <div className="col-3">
                          <label className="form-label">Arrival</label>
                          <div className="icon-field">
                            <span className="icon">
                              <Icon icon="solar:map-point-linear" />
                            </span>
                            <span className="form-control form-control-readonly">
                              {segment.arrival?.iataCode} (
                              {formatDateTime(segment.arrival?.at)})
                            </span>
                          </div>
                        </div>
                        <div className="col-3">
                          <label className="form-label">Duration</label>
                          <div className="icon-field">
                            <span className="icon">
                              <Icon icon="solar:clock-circle-linear" />
                            </span>
                            <span className="form-control form-control-readonly">
                              {formatDuration(segment.duration)}
                            </span>
                          </div>
                        </div>
                        <div className="col-3">
                          <label className="form-label">Aircraft</label>
                          <div className="icon-field">
                            <span className="icon">
                              <Icon icon="f7:airplane" />
                            </span>
                            <span className="form-control form-control-readonly">
                              {segment.aircraft?.code || "N/A"}
                            </span>
                          </div>
                        </div>
                        <div className="col-3">
                          <label className="form-label">CO2 Emissions</label>
                          <div className="icon-field">
                            <span className="icon">
                              <Icon icon="solar:leaf-linear" />
                            </span>
                            <span className="form-control form-control-readonly">
                              {segment.co2Emissions?.[0]?.weight || "N/A"}{" "}
                              {segment.co2Emissions?.[0]?.weightUnit || ""}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ))}

                {/* Traveler Pricings */}
                <div
                  className="col-12 mt-3"
                  aria-labelledby={`traveler-pricing-header`}
                >
                  <p id={`traveler-pricing-header`}>Traveler Pricing</p>
                  {offer.travelerPricings?.map((pricing, priceIndex) => (
                    <div
                      key={pricing.travelerId}
                      className="row gy-3 mb-3"
                      role="group"
                      aria-labelledby={`pricing-${pricing.travelerId}-header`}
                    >
                      <p
                        id={`pricing-${pricing.travelerId}-header`}
                        className="col-12 font-weight-bold"
                      >
                        Traveler {pricing.travelerId}
                      </p>
                      <div className="col-3">
                        <label className="form-label">Traveler Type</label>
                        <div className="icon-field">
                          <span className="icon">
                            <Icon icon="f7:person" />
                          </span>
                          <span className="form-control form-control-readonly">
                            {pricing.travelerType || "N/A"}
                          </span>
                        </div>
                      </div>
                      <div className="col-3">
                        <label className="form-label">Total Price</label>
                        <div className="icon-field">
                          <span className="icon">
                            <Icon icon="solar:tag-linear" />
                          </span>
                          <span className="form-control form-control-readonly">
                            {pricing.price?.total} {pricing.price?.currency}
                          </span>
                        </div>
                      </div>
                      <div className="col-3">
                        <label className="form-label">Fare Option</label>
                        <div className="icon-field">
                          <span className="icon">
                            <Icon icon="f7:info-circle" />
                          </span>
                          <span className="form-control form-control-readonly">
                            {pricing.fareOption || "N/A"}
                          </span>
                        </div>
                      </div>
                      <div className="col-3">
                        <label className="form-label">Refundable Taxes</label>
                        <div className="icon-field">
                          <span className="icon">
                            <Icon icon="solar:tag-linear" />
                          </span>
                          <span className="form-control form-control-readonly">
                            {pricing.price?.refundableTaxes || "N/A"}{" "}
                            {pricing.price?.currency}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default FlightOfferDetails;
