import { Icon } from "@iconify/react/dist/iconify.js";
import React from "react";

const TravelerDetails = ({ data }) => {
  const travelers = Array.isArray(data) ? data : [];

  return (
    <div className="col-md-12">
      <div className="card">
        <div className="card-header">
          <h5 className="card-title mb-0">Traveler Information</h5>
        </div>
        <div className="card-body">
          {travelers.length === 0 ? (
            <p className="text-muted">No traveler information available</p>
          ) : (
            travelers.map((traveler, index) => (
              <div
                key={traveler.id}
                className={`row gy-3 ${
                  index > 0 ? "mt-4 pt-4 border-top" : ""
                }`}
                role="group"
                aria-labelledby={`traveler-${traveler.id}-header`}
              >
                <p id={`traveler-${traveler.id}-header`} className="col-12">
                  Traveler {index + 1}
                </p>
                <div className="col-3">
                  <label className="form-label">Name</label>
                  <div className="icon-field">
                    <span className="icon">
                      <Icon icon="f7:person" />
                    </span>
                    <span className="form-control form-control-readonly">
                      {traveler.name?.firstName}{" "}
                      {traveler.name?.lastName || "N/A"}
                    </span>
                  </div>
                </div>
                <div className="col-3">
                  <label className="form-label">Date of Birth</label>
                  <div className="icon-field">
                    <span className="icon">
                      <Icon icon="solar:calendar-linear" />
                    </span>
                    <span className="form-control form-control-readonly">
                      {traveler.dateOfBirth || "N/A"}
                    </span>
                  </div>
                </div>
                <div className="col-3">
                  <label className="form-label">Gender</label>
                  <div className="icon-field">
                    <span className="icon">
                      <Icon icon="f7:person" />
                    </span>
                    <span className="form-control form-control-readonly">
                      {traveler.gender || "N/A"}
                    </span>
                  </div>
                </div>
                <div className="col-3">
                  <label className="form-label">Email</label>
                  <div className="icon-field">
                    <span className="icon">
                      <Icon icon="mage:email" />
                    </span>
                    <span className="form-control form-control-readonly">
                      {traveler.contact?.emailAddress || "N/A"}
                    </span>
                  </div>
                </div>
                <div className="col-3">
                  <label className="form-label">Phone</label>
                  <div className="icon-field">
                    <span className="icon">
                      <Icon icon="solar:phone-calling-linear" />
                    </span>
                    <span className="form-control form-control-readonly">
                      {traveler.contact?.phones?.[0]
                        ? `${traveler.contact.phones[0].countryCallingCode} ${traveler.contact.phones[0].number}`
                        : "N/A"}
                    </span>
                  </div>
                </div>
                {traveler.documents?.length > 0 && (
                  <div className="col-3">
                    <label className="form-label">Passport</label>
                    <div className="icon-field">
                      <span className="icon">
                        <Icon icon="solar:passport-linear" />
                      </span>
                      <span className="form-control form-control-readonly">
                        {traveler.documents[0].number || "N/A"} (Expires:{" "}
                        {traveler.documents[0].expiryDate || "N/A"})
                      </span>
                    </div>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default TravelerDetails;
