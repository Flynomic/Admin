import { Icon } from "@iconify/react/dist/iconify.js";
import { useEffect, useState } from "react";
import useApi from "../../hook/useApi";
import { toast } from "react-toastify";
import Paggination from "../../components/Paggination";
import Loader from "../../components/Loader/Loader";
import CustomerSupportModal from "./CustomerSupportModal";

const CustomerSupportLayer = () => {
  const { AsyncGetApiCall, AsyncPostApiCall } = useApi();
  const [loading, setLoading] = useState(false);
  const [query, setQuery] = useState({
    pageNo: 1,
    limitVal: 50,
    search: "",
    isReply: false,
  });
  const [data, setData] = useState([]);
  const [show, setShow] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState(null);
  const [action, setAction] = useState("view");

  const [pagination, setPagination] = useState({
    total: 0,
    currentPage: 1,
    hasNextPage: false,
    hasPrevPage: false,
    totalPages: 1,
    limit: 10,
  });

  // Admin reply handler
  const handleAdminReply = async (id, adminReply) => {
    setLoading(true);
    const res = await AsyncPostApiCall(`/customer-support/admin-reply`, {
      id,
      adminReply,
    });
    if (res.success) {
      toast.success("Reply sent successfully!");
      // Optionally refresh tickets or update UI as needed
      getAllTickets();
    } else {
      toast.error(res.errors[0] || "Failed to send reply");
    }

    setLoading(false);
  };

  const getAllTickets = async () => {
    setLoading(true);
    try {
      const result = await AsyncGetApiCall(
        "/customer-support/list",
        query?.isReply.toString() === "true"
          ? query
          : {
            pageNo: query.pageNo,
            limitVal: query.limitVal,
            search: query.search,
          }
      );
      if (result.success) {
        setData(result.data || []);
        setPagination(result.pagination);
      } else {
        toast.error(result.errors?.[0] || "Failed to fetch tickets");
      }
    } catch (error) {
      toast.error("An error occurred while fetching tickets");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    getAllTickets();
  }, [query]);

  const setPageNo = (pageNo) => {
    setQuery((prev) => ({
      ...prev,
      pageNo,
    }));
  };

  return (
    <div className="card h-100 p-0 radius-12">
      {loading && <Loader />}
      <div className="card-header border-bottom bg-base py-16 px-24 d-flex align-items-center flex-wrap gap-3 justify-content-between">
        <div className="d-flex align-items-center flex-wrap gap-3">
          <span className="text-md fw-medium text-secondary-light mb-0">
            Show
          </span>
          <select
            className="form-select form-select-sm w-auto ps-12 py-6 radius-12 h-40-px"
            value={query.limitVal}
            onChange={(e) => {
              const value = parseInt(e.target.value, 10);
              setQuery((prev) => ({
                ...prev,
                limitVal: value,
                pageNo: 1,
              }));
            }}>
            {[5, 10, 15, 20].map((value) => (
              <option key={value} value={value}>
                {value}
              </option>
            ))}
          </select>
          <span className="text-md fw-medium text-secondary-light mb-0">
            Filter By
          </span>
          <select
            className="form-select form-select-sm w-auto ps-12 py-6 radius-12 h-40-px"
            value={String(query.isReply)}
            onChange={(e) => {
              console.log(
                "e.target.value : ",
                e.target.value,
                typeof e.target.value
              );

              setQuery((prev) => ({
                ...prev,
                isReply: e.target.value.toString() === "true" ? true : false, // This converts to boolean
                pageNo: 1,
              }));
            }}
            aria-label="Filter by replied/unreplied">
            <option value="false">Not Replied</option>
            <option value="true">Replied</option>
          </select>

          <form className="navbar-search">
            <input
              type="text"
              className="bg-base h-40-px w-auto min-w-310"
              name="search"
              placeholder="Search by name, subject, email"
              value={query.search}
              onChange={(e) =>
                setQuery((prev) => ({
                  ...prev,
                  search: e.target.value,
                  pageNo: 1,
                }))
              }
            />
            <Icon icon="ion:search-outline" className="icon" />
          </form>
        </div>
      </div>
      <div className="card-body p-24">
        <div className="table-responsive scroll-sm">
          <table className="table bordered-table sm-table mb-0">
            <thead>
              <tr>
                <th>S.No</th>
                <th>Created Date</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Subject</th>
                <th>Message</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {data?.length > 0 ? (
                data.map((item, index) => (
                  <tr key={item?._id}>
                    <td>
                      {(pagination.currentPage - 1) * pagination.limit +
                        index +
                        1}
                    </td>
                    <td>
                      {new Date(item?.createdAt).toLocaleString(undefined, {
                        day: "2-digit",
                        month: "short",
                        year: "2-digit",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </td>
                    <td>
                      {item?.name.length > 30
                        ? item?.name.slice(0, 30) + "..."
                        : item?.name}
                    </td>

                    <td>
                      {item?.email.length > 30
                        ? item?.email.slice(0, 30) + "..."
                        : item?.email}
                    </td>

                    <td>
                      {item?.subject.length > 30
                        ? item?.subject.slice(0, 30) + "..."
                        : item?.subject}
                    </td>
                    <td>
                      {item?.message?.length > 30
                        ? item?.message.slice(0, 30) + "..."
                        : item?.message}
                    </td>
                    <td className="text-center">
                      <div className="d-flex align-items-center gap-10 justify-content-center">
                        <button
                          type="button"
                          className="bg-info-focus bg-hover-info-200 text-info-600 fw-medium w-40-px h-40-px d-flex justify-content-center align-items-center rounded-circle"
                          onClick={() => {
                            setShow(true);
                            setSelectedTicket(item);
                            setAction("view");
                          }}>
                          <Icon
                            icon="majesticons:eye-line"
                            className="icon text-xl"
                          />
                          <span className="tooltip-text">View</span>
                        </button>
                        <button
                          type="button"
                          className="bg-success-focus text-success-600 bg-hover-success-200 fw-medium w-40-px h-40-px d-flex justify-content-center align-items-center rounded-circle"
                          onClick={() => {
                            setShow(true);
                            setSelectedTicket(item);
                            setAction("reply");
                          }}>
                          <Icon icon="lucide:reply" className="menu-icon" />
                          <span className="tooltip-text">Reply</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={7} className="text-center">
                    No data found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <Paggination
          total={pagination.total}
          totalPages={pagination.totalPages}
          currentPage={pagination.currentPage}
          setPageNo={setPageNo}
          startFrom={(pagination.currentPage - 1) * pagination.limit + 1}
          endTo={
            (pagination.currentPage - 1) * pagination.limit +
            (data?.length || 0)
          }
        />

        {show && (
          <CustomerSupportModal
            show={show}
            handleClose={() => {
              setShow(false);
              setSelectedTicket(null);
            }}
            data={selectedTicket}
            action={action}
            onReply={handleAdminReply}
          />
        )}
      </div>
    </div>
  );
};

export default CustomerSupportLayer;
