import MasterLayout from "../../masterLayout/MasterLayout";
import Breadcrumb from "../../components/Breadcrumb";
import CustomerSupportLayer from "./CustomerSupportLayer";

const CustomerSupportPage = () => {
  return (
    <>
      {/* MasterLayout */}
      <MasterLayout>
        {/* Breadcrumb */}
        <Breadcrumb title="Customer Support & Help" />

        <CustomerSupportLayer />
      </MasterLayout>
    </>
  );
};

export default CustomerSupportPage;
