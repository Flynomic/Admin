import { Modal, Button, Form } from "react-bootstrap";
import { useState } from "react";

const CustomerSupportModal = ({
  show,
  handleClose,
  data,
  action = "view",
  onReply,
}) => {
  const [reply, setReply] = useState("");
  const [submitting, setSubmitting] = useState(false);

  console.log("---------data : ", data);

  const handleReply = async () => {
    if (!reply.trim()) return;
    setSubmitting(true);
    try {
      await onReply(data._id, reply);
      setReply("");
      handleClose();
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal
      show={show}
      onHide={handleClose}
      className="custom-modal"
      size="lg" // Increase modal size to accommodate more content
      centered
      animation>
      <Modal.Header closeButton>
        <Modal.Title className="modal-title-lg">
          {action === "reply" ? "Reply to Ticket" : "Support Ticket Details"}
        </Modal.Title>
      </Modal.Header>
      <Modal.Body
        className="p-3"
        style={{ maxHeight: "70vh", overflowY: "auto" }}>
        {data ? (
          <>
            <div className="form-list-row mb-2">
              <strong>Name:</strong> {data.name}
            </div>
            <div className="form-list-row mb-2">
              <strong>Email:</strong> {data.email}
            </div>
            <div className="mb-2 form-list-row">
              <strong>Subject:</strong>
              <div className="text-break">{data.subject}</div>
            </div>
            <div className="mb-2 form-list-row">
              <strong>Message:</strong>
              <div className="p-2 bg-light rounded border text-break">
                {data.message}
              </div>
            </div>
            <div className="mb-2 form-list-row">
              <strong>Created At:</strong>{" "}
              {new Date(data.createdAt).toLocaleString()}
            </div>
            {data.documents?.length > 0 && (
              <div className="mb-2">
                <strong>Attachments:</strong>
                <div className="d-flex flex-wrap gap-3">
                  {data.documents.map((doc, i) => (
                    <div key={i}>
                      <a
                        href={`${process.env.REACT_APP_API_URL}/${doc}`}
                        target="_blank"
                        rel="noopener noreferrer">
                        <img
                          src={`${process.env.REACT_APP_API_URL}/${doc}`}
                          alt={`attachment-${i}`}
                          style={{
                            maxWidth: "150px",
                            maxHeight: "150px",
                            borderRadius: "6px",
                          }}
                        />
                      </a>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {action === "reply" && (
              <Form.Group className="mb-3">
                <Form.Label>Reply to user</Form.Label>
                <Form.Control
                  as="textarea"
                  rows={3}
                  value={reply}
                  onChange={(e) => setReply(e.target.value)}
                  disabled={submitting}
                  placeholder="Type your reply here..."
                  className="text-break" // Ensure reply text wraps
                  maxLength={500}
                />
              </Form.Group>
            )}
          </>
        ) : (
          <div>No data found.</div>
        )}
      </Modal.Body>
      <Modal.Footer>
        {action === "reply" ? (
          <>
            <Button
              variant="success"
              onClick={handleReply}
              disabled={submitting || !reply.trim()}>
              {submitting ? "Sending..." : "Send Reply"}
            </Button>
            <Button
              variant="secondary"
              onClick={handleClose}
              disabled={submitting}>
              Cancel
            </Button>
          </>
        ) : (
          <Button variant="danger" onClick={handleClose}>
            Close
          </Button>
        )}
      </Modal.Footer>
    </Modal>
  );
};

export default CustomerSupportModal;
