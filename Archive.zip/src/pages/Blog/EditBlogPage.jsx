import React from "react";
import MasterLayout from "../../masterLayout/MasterLayout";
import Breadcrumb from "../../components/Breadcrumb";
import EditBlogLayer from "../../components/Blog/EditBlogLayer";
import { useParams } from "react-router-dom";

const EditBlogPage = () => {
  const { id } = useParams("id");

  console.log("id", id);
  return (
    <>
      {/* MasterLayout */}
      <MasterLayout>
        {/* Breadcrumb */}
        <Breadcrumb title="Edit Blog" />

        <EditBlogLayer id={id} />
      </MasterLayout>
    </>
  );
};

export default EditBlogPage;
