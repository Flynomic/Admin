import React from "react";
import MasterLayout from "../../masterLayout/MasterLayout";
import Breadcrumb from "../../components/Breadcrumb";
import { useLocation, useParams } from "react-router-dom";
import ViewHotelBookingLayer from "./ViewHotelBookingLayer";
import { BOOKING_PAGE_TYPE } from "../../utils/constant";

const ViewHotelBookingPage = () => {
  const { id } = useParams("id");
  const location = useLocation();
  const { pageType } = location.state || {}

  return (
    <>
      {/* MasterLayout */}
      <MasterLayout>
        {/* Breadcrumb */}
        <Breadcrumb title={`Hotel Booking ${pageType === BOOKING_PAGE_TYPE.REFUND ? "Refund" : pageType === BOOKING_PAGE_TYPE.VIEW ? "View" : "Edit"}`} />

        <ViewHotelBookingLayer id={id} pageType={pageType} />
      </MasterLayout>
    </>
  );
};

export default ViewHotelBookingPage;
