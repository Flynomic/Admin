import { Icon } from "@iconify/react/dist/iconify.js";
import React, { useEffect, useState } from "react";
import useApi from "../../hook/useApi";
import Paggination from "../../components/Paggination";
import { useNavigate } from "react-router-dom";
import Loader from "../../components/Loader/Loader";
import { BOOKING_PAGE_TYPE, HOTEL_BOOKING_STATUS, CURRENCY_CODE, REFUND_STATUS } from "../../utils/constant";
import { toast } from "react-toastify";

const HotelsListLayer = () => {
  const { AsyncGetApiCall, AsyncDeleteApiCall } = useApi();
  const navigate = useNavigate();

  const [query, setQuery] = useState({
    pageNo: 1,
    limitVal: 50,
    search: "",
    status: "",
    refundStatus: "",
  });
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState(null);
  const [pagination, setPagination] = useState(null);

  const getAllBookingList = async () => {
    setLoading(true);
    try {
      const result = await AsyncGetApiCall("/hotel-booking/admin/list", query);
      console.log("Result: ", result);

      if (result.success) {
        setData(result.data);
        setPagination(result.pagination);
      } else {
        setData([]);
        setPagination(null);
      }
    } catch (error) {
      console.error("Error fetching bookings:", error);
      setData([]);
      setPagination(null);
    }
    setLoading(false);
  };

  const setPageNo = (pageNo) => {
    setQuery((prev) => ({
      ...prev,
      pageNo,
    }));
  };
  console.log("Data", data);

  useEffect(() => {
    getAllBookingList();
  }, [query]);

  const handleSearchChange = (e) => {
    setQuery((prev) => ({
      ...prev,
      search: e.target.value,
      pageNo: 1, // Reset to first page on search
    }));
  };

  const handleStatusChange = (e) => {
    setQuery((prev) => ({
      ...prev,
      status: e.target.value === "Select Status" ? "" : e.target.value,
      pageNo: 1, // Reset to first page on status change
    }));
  };

  const handleCancelBooking = async (bookingRef) => {
    setLoading(true);
    if (bookingRef) {
      const result = await AsyncDeleteApiCall(
        `/hotel-booking/cancellation/${bookingRef}`
      );
      console.log("Result", result)
      if (result?.success) {
        toast.success("Booking cancelled successfully");
      } else {
        toast.error(result?.errors[0] || "Failed to cancel booking.");
      }
    }
    getAllBookingList()
    setLoading(false);
  };

  const handleRefundStatusChange = (e) => {
    setQuery((prev) => ({
      ...prev,
      refundStatus: e.target.value === "Select Refund Status" ? "" : e.target.value,
      pageNo: 1, // Reset to first page on status change
    }));
  };

  return (
    <>
      {loading && <Loader />}
      <div className="card h-100 p-0 radius-12">
        <div className="card-header border-bottom bg-base py-16 px-24 d-flex align-items-center flex-wrap gap-3 justify-content-between">
          <div className="d-flex align-items-center flex-nowrap gap-3 w-100">
            <form
              className="navbar-search "
              onSubmit={(e) => e.preventDefault()}>
              <input
                type="text"
                className="bg-base h-40-px w-full"
                name="search"
                placeholder="Search by hotel or destination"
                value={query.search}
                onChange={handleSearchChange}
                aria-label="Search by hotel or destination"
              />
              <Icon icon="ion:search-outline" className="icon" />
            </form>

            <span className="text-md fw-medium text-secondary-light mb-0 whitespace-nowrap ms-auto">
              Show
            </span>
            <select
              className="form-select w-auto form-select-sm ps-12 py-6 radius-12 h-40-px"
              value={query.limitVal}
              onChange={(e) => {
                const value = parseInt(e.target.value, 10);
                setQuery((prev) => ({
                  ...prev,
                  limitVal: value,
                  pageNo: 1, // Reset to first page
                }));
              }}>
              <option value="Select Number" disabled>
                Select Number
              </option>
              {Array.from({ length: 20 }, (_, i) => {
                const value = (i + 1) * 5;
                return (
                  <option key={value} value={value}>
                    {value}
                  </option>
                );
              })}
            </select>

            <select
              className="form-select w-auto form-select-sm ps-12 py-6 radius-12 h-40-px"
              value={query.status || "Select Status"}
              onChange={handleStatusChange}>
              <option value="Select Status">Select Booking Status</option>
              <option value={HOTEL_BOOKING_STATUS.CONFIRMED}>Confirmed</option>
              <option value={HOTEL_BOOKING_STATUS.PENDING}>Pending</option>
              <option value={HOTEL_BOOKING_STATUS.CANCELLED}>Cancelled</option>
            </select>

            <select
              className="form-select w-auto form-select-sm ps-12 py-6 radius-12 h-40-px"
              value={query.refundStatus || "Select Refund Status"}
              onChange={handleRefundStatusChange}>
              <option value="Select Refund Status">Select Refund Status</option>
              <option value="completed">Completed</option>
              <option value="pending">Pending</option>
              <option value="not_applicable">Not Applicable</option>
              <option value="failed">Failed</option>
              <option value="rejected">Rejected</option>
            </select>
          </div>
        </div>
        <div className="card-body p-24">
          <div className="table-responsive scroll-sm">
            <table className="table bordered-table sm-table mb-0">
              <thead>
                <tr>
                  <th scope="col">
                    <div className="d-flex align-items-center gap-10">S.No</div>
                  </th>
                  <th scope="col">Booking Ref</th>
                  <th scope="col">Name</th>
                  <th scope="col">Email</th>
                  <th scope="col">Hotel Id</th>
                  <th scope="col">Paid Amount</th>
                  <th scope="col">Original Amount</th>
                  <th scope="col">Created At</th>
                  <th scope="col" className="text-center">
                    Booking Status
                  </th>
                  <th scope="col" className="text-center">
                    Refund Status
                  </th>
                  <th scope="col" className="text-center">
                    Action
                  </th>
                </tr>
              </thead>
              <tbody>
                {data && data.length > 0 ? (
                  data.map((item, index) => (
                    <tr key={item._id}>
                      <td>
                        <div className="d-flex align-items-center gap-10">
                          {(pagination?.currentPage - 1) * query.limitVal +
                            index +
                            1}
                        </div>
                      </td>
                      <td>
                        <a
                          href={`/hotel-booking/view-booking/${item._id}`}
                          onClick={() => {
                            navigate(
                              `/hotel-booking/view-booking/${item._id}`,
                              {
                                state: { pageType: BOOKING_PAGE_TYPE.VIEW }, // Pass the item as state
                              })
                          }}>
                          {item.hotelBookings[0]?.reference || "N/A"}
                        </a>
                      </td>
                      <td>{item.hotelBookings[0]?.holder?.name || "N/A"}</td>
                      <td>
                        {item.hotelBookings[0]?.holder?.email ||
                          item?.userId?.email ||
                          "N/A"}
                      </td>
                      <td>{item.hotelBookings[0]?.hotel?.code || "N/A"}</td>
                      <td>{`${CURRENCY_CODE[item?.txData?.paidCurrency] || ""} ${Number(item?.txData?.paidAmount).toFixed(2) || "N/A"}`}</td>
                      <td>{`${CURRENCY_CODE[item?.txData?.originalCurrency] || ""} ${Number(item?.txData?.originalAmount).toFixed(2) || "N/A"}`}</td>
                      <td>
                        {new Date(item.createdAt).toLocaleString("en-IN", {
                          timeZone: "Asia/Kolkata",
                          dateStyle: "short",
                          timeStyle: "short",
                        })}
                      </td>
                      <td className="text-center">
                        <span
                          className={`badge ${item.hotelBookings[0]?.status === HOTEL_BOOKING_STATUS.CONFIRMED
                            ? "bg-success-100 text-success-600"
                            : item.hotelBookings[0]?.status === HOTEL_BOOKING_STATUS.PENDING
                              ? "bg-warning-100 text-warning-600"
                              : "bg-danger-100 text-danger-600"
                            } text-sm py-4 px-10 radius-4`}>
                          {item.hotelBookings[0]?.status}
                        </span>
                      </td>
                      <td className="text-center">
                        <span
                          className={`badge ${item?.refundStatus === 'completed'
                            ? 'bg-success-100 text-success-600'
                            : item?.refundStatus === 'pending'
                              ? 'bg-warning-100 text-warning-600'
                              : item?.refundStatus === 'not_applicable'
                                ? 'bg-primary-300 text-secondary-600'
                                : item?.refundStatus === 'failed' || item?.refundStatus === 'rejected'
                                  ? 'bg-danger-100 text-danger-600'
                                  : 'background-gray-100'
                            } text-sm py-4 px-10 radius-4`}
                        >
                          {REFUND_STATUS[item?.refundStatus] || 'None'}
                        </span>
                      </td>
                      <td className="text-center">
                        <div className="d-flex align-items-center gap-10 justify-content-center">
                          {
                            item.hotelBookings[0]?.status === HOTEL_BOOKING_STATUS.CONFIRMED ?
                              <button
                                type="button"
                                className="bg-danger-100 bg-hover-danger-200 text-danger-600 fw-medium w-40-px h-40-px d-flex justify-content-center align-items-center rounded-circle"
                                onClick={() => {
                                  if (
                                    window.confirm(
                                      "Do you want to cancel this booking?"
                                    )
                                  ) {
                                    handleCancelBooking(item.hotelBookings[0]?.reference)
                                  }
                                }}
                              >
                                <Icon
                                  icon="majesticons:close-line" // Replace with cancel icon
                                  className="icon text-xl"
                                />
                                <span className="tooltip-text">Cancel</span>
                              </button>
                              : item.hotelBookings[0]?.status === HOTEL_BOOKING_STATUS.CANCELLED && item?.refundStatus === "pending" ?
                                (<button
                                  type="button"
                                  className=" text-success-600 bg-hover-success-200 fw-medium w-40-px h-40-px d-flex justify-content-center align-items-center rounded-circle"
                                  style={{ backgroundColor: "rgb(238, 242, 208)" }}
                                  onClick={(e) => {
                                    e.preventDefault();
                                    navigate(`/hotel-booking/view-booking/${item._id}`,
                                      {
                                        state: { pageType: BOOKING_PAGE_TYPE.REFUND }, // Pass the item as state
                                      })
                                  }}
                                >
                                  <Icon
                                    icon="mdi:cash"
                                    className="icon text-xl"
                                  />
                                  <span className="tooltip-text">Refund</span>
                                </button>
                                ) : <></>
                          }
                          {/* <button
                            type="button"
                            className="bg-success-focus text-success-600 bg-hover-success-200 fw-medium w-40-px h-40-px d-flex justify-content-center align-items-center rounded-circle"
                            onClick={(e) => {
                              e.preventDefault();
                              navigate(`/hotel-booking/view-booking/${item._id}`,
                                {
                                  state: { pageType: BOOKING_PAGE_TYPE.EDIT }, // Pass the item as state
                                })
                            }}
                          >
                            <Icon icon="lucide:edit" className="menu-icon" />
                            <span className="tooltip-text">Edit</span>
                          </button> */}
                          <button
                            type="button"
                            className="bg-info-focus bg-hover-info-200 text-info-600 fw-medium w-40-px h-40-px d-flex justify-content-center align-items-center rounded-circle"
                            onClick={() => {
                              navigate(
                                `/hotel-booking/view-booking/${item._id}`,
                                {
                                  state: { pageType: BOOKING_PAGE_TYPE.VIEW }, // Pass the item as state
                                })
                            }}>
                            <Icon
                              icon="majesticons:eye-line"
                              className="icon text-xl"
                            />
                            <span className="tooltip-text">View</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="12" className="text-center">
                      No data found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          <Paggination
            total={pagination?.total || 0}
            totalPages={pagination?.totalPages || 0}
            currentPage={pagination?.currentPage || 1}
            setPageNo={setPageNo}
            startFrom={(pagination?.currentPage - 1) * query.limitVal + 1}
            endTo={
              data?.length
                ? (pagination.currentPage - 1) * query.limitVal + data.length
                : 0
            }
          />
        </div>
      </div>
    </>
  );
};

export default HotelsListLayer;
