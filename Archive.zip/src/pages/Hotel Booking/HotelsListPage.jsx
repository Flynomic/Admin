import React from "react";
import MasterLayout from "../../masterLayout/MasterLayout";
import Breadcrumb from "../../components/Breadcrumb";
import HotelsListLayer from "./HotelsListLayer";

const HotelsListPage = () => {
  return (
    <>
      {/* MasterLayout */}
      <MasterLayout>
        {/* Breadcrumb */}
        <Breadcrumb title="Hotel Booking Management" />

        <HotelsListLayer />
      </MasterLayout>
    </>
  );
};

export default HotelsListPage;
