import React from "react";

const HotelDetails = ({ data }) => {
  const hotel = data?.hotelBookings?.[0]?.hotel || {};

  return (
    <div className="col-12">
      <div className="card p-24 radius-12">
        <h5 className="text-md fw-semibold mb-24">Hotel Details</h5>
        <div className="row gy-3">
          <div className="col-md-6">
            <label className="form-label">Hotel Name</label>
            <p className="text-secondary-light">{hotel.name || "N/A"}</p>
          </div>
          <div className="col-md-6">
            <label className="form-label">Category</label>
            <p className="text-secondary-light">
              {hotel.categoryName || "N/A"}
            </p>
          </div>
          <div className="col-md-6">
            <label className="form-label">Check-In Date</label>
            <p className="text-secondary-light">
              {hotel.checkIn
                ? new Date(hotel.checkIn).toLocaleDateString("en-IN", {
                    timeZone: "Asia/Kolkata",
                  })
                : "N/A"}
            </p>
          </div>
          <div className="col-md-6">
            <label className="form-label">Check-Out Date</label>
            <p className="text-secondary-light">
              {hotel.checkOut
                ? new Date(hotel.checkOut).toLocaleDateString("en-IN", {
                    timeZone: "Asia/Kolkata",
                  })
                : "N/A"}
            </p>
          </div>
          <div className="col-md-6">
            <label className="form-label">Destination</label>
            <p className="text-secondary-light">
              {hotel.destinationName || "N/A"}
            </p>
          </div>
          <div className="col-md-6">
            <label className="form-label">Zone</label>
            <p className="text-secondary-light">{hotel.zoneName || "N/A"}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HotelDetails;
