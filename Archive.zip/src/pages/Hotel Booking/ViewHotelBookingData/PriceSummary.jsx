import React from "react";

const PriceSummary = ({ data }) => {
  const booking = data?.hotelBookings?.[0] || {};
  const rate = booking?.hotel?.rates?.[0] || {};
  const discounts = rate?.rateBreakDown?.rateDiscounts || [];

  return (
    <div className="col-12">
      <div className="card p-24 radius-12">
        <h5 className="text-md fw-semibold mb-24">Price Summary</h5>
        <div className="row gy-3">
          <div className="col-md-6">
            <label className="form-label">Total Net</label>
            <p className="text-secondary-light">
              {booking.totalNet && booking.currency
                ? `${booking.currency}${booking.totalNet.toFixed(2)}`
                : "N/A"}
            </p>
          </div>
          {discounts.length > 0 ? (
            <div className="col-12">
              <h6 className="text-sm fw-medium">Discounts</h6>
              {discounts.map((discount, index) => (
                <p key={index} className="text-secondary-light">
                  {discount.name}: {discount.amount} {booking.currency}
                </p>
              ))}
            </div>
          ) : (
            <div className="col-12">
              <p className="text-secondary-light">No discounts applied.</p>
            </div>
          )}
          <div className="col-12">
            <label className="form-label">Rate Comments</label>
            <p className="text-secondary-light">{rate.rateComments || "N/A"}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PriceSummary;
