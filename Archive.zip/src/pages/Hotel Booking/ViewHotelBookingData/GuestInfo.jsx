import React from "react";

const GuestInfo = ({ data }) => {
  const holder = data?.hotelBookings?.[0]?.holder || {};
  const paxes = data?.hotelBookings?.[0]?.hotel?.rooms?.[0]?.paxes || [];

  return (
    <div className="col-12">
      <div className="card p-24 radius-12">
        <h5 className="text-md fw-semibold mb-24">Guest Information</h5>
        <div className="row gy-3">
          <div className="col-md-6">
            <label className="form-label">Email</label>
            <p className="text-secondary-light">{data?.email || "N/A"}</p>
          </div>
          <div className="col-md-6">
            <label className="form-label">Holder Name</label>
            <p className="text-secondary-light">
              {holder.name && holder.surname
                ? `${holder.name} ${holder.surname}`
                : "N/A"}
            </p>
          </div>
          {paxes.length > 0 ? (
            paxes.map((pax, index) => (
              <div key={index} className="col-12">
                <h6 className="text-sm fw-medium">Guest {index + 1}</h6>
                <div className="row gy-3">
                  <div className="col-md-6">
                    <label className="form-label">Name</label>
                    <p className="text-secondary-light">
                      {pax.name && pax.surname
                        ? `${pax.name} ${pax.surname}`
                        : "N/A"}
                    </p>
                  </div>
                  <div className="col-md-6">
                    <label className="form-label">Type</label>
                    <p className="text-secondary-light">{pax.type || "N/A"}</p>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="col-12">
              <p className="text-secondary-light">
                No guest details available.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default GuestInfo;
