import React from "react";

const PaymentInfo = ({ data }) => {
  const booking = data?.hotelBookings?.[0] || {};
  const rate = booking?.hotel?.rates?.[0] || {};

  return (
    <div className="col-12">
      <div className="card p-24 radius-12">
        <h5 className="text-md fw-semibold mb-24">Payment Information</h5>
        <div className="row gy-3">
          <div className="col-md-6">
            <label className="form-label">Total Net</label>
            <p className="text-secondary-light">
              {booking.totalNet && booking.currency
                ? `${booking.currency}${booking.totalNet.toFixed(2)}`
                : "N/A"}
            </p>
          </div>
          <div className="col-md-6">
            <label className="form-label">Payment Type</label>
            <p className="text-secondary-light">{rate.paymentType || "N/A"}</p>
          </div>
          <div className="col-md-6">
            <label className="form-label">Pending Amount</label>
            <p className="text-secondary-light">
              {booking.pendingAmount && booking.currency
                ? `${booking.currency}${booking.pendingAmount.toFixed(2)}`
                : "N/A"}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaymentInfo;
