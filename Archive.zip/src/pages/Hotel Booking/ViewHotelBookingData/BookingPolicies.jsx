import React from "react";

const BookingPolicies = ({ data }) => {
  const policies = data?.hotelBookings?.[0]?.modificationPolicies || {};
  const cancellationPolicies =
    data?.hotelBookings?.[0]?.hotel?.rates?.[0]?.cancellationPolicies || [];

  return (
    <div className="col-12">
      <div className="card p-24 radius-12">
        <h5 className="text-md fw-semibold mb-24">Booking Policies</h5>
        <div className="row gy-3">
          <div className="col-md-6">
            <label className="form-label">Cancellation Allowed</label>
            <p className="text-secondary-light">
              {policies.cancellation ? "Yes" : "No"}
            </p>
          </div>
          <div className="col-md-6">
            <label className="form-label">Modification Allowed</label>
            <p className="text-secondary-light">
              {policies.modification ? "Yes" : "No"}
            </p>
          </div>
          {cancellationPolicies.length > 0 ? (
            <div className="col-12">
              <h6 className="text-sm fw-medium">Cancellation Policies</h6>
              {cancellationPolicies.map((policy, index) => (
                <div key={index} className="mb-3">
                  <p className="text-secondary-light">
                    Penalty: {policy.amount}{" "}
                    {data?.hotelBookings?.[0]?.currency} if cancelled after{" "}
                    {policy.from
                      ? new Date(policy.from).toLocaleString("en-IN", {
                          timeZone: "Asia/Kolkata",
                          dateStyle: "short",
                          timeStyle: "short",
                        })
                      : "N/A"}
                  </p>
                </div>
              ))}
            </div>
          ) : (
            <div className="col-12">
              <p className="text-secondary-light">
                No cancellation policies available.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BookingPolicies;
