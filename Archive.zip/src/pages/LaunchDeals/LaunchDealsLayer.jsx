import { Icon } from "@iconify/react";
import { useEffect, useState } from "react";

import { toast } from "react-toastify";
import useApi from "../../hook/useApi";
import Loader from "../../components/Loader/Loader";
import Paggination from "../../components/Paggination";
import SearchHotelModal from "./CreateModal/SearchHotelModal";
import { TbRestore } from "react-icons/tb";
import { FiEye } from "react-icons/fi";
import EditLaunchDealModal from "./CreateModal/EditLaunchDealModal";

const LaunchDealsLayer = () => {
  const { AsyncGetApiCall, AsyncDeleteApiCall } = useApi();

  const [loading, setLoading] = useState(false);
  const [query, setQuery] = useState({ pageNo: 1, limitVal: 20, search: "" });
  const [data, setData] = useState({
    data: [],
    pagination: {
      total: 0,
      totalPages: 0,
      currentPage: 1,
      hasNextPage: false,
      hasPrevPage: false,
      limit: 20,
    },
  });
  const [showModal, setShowModal] = useState(false);

  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedDeal, setSelectedDeal] = useState(null);

  // Fetch all promotional items
  const getAllPromotionalList = async () => {
    setLoading(true);
    const result = await AsyncGetApiCall("/hotels/get-launch-deals", query);
    console.log("result of searcH", result);
    if (result?.success) {
      setData({
        data: result?.data || [],
        pagination: result?.pagination || {
          total: 0,
          totalPages: 0,
          currentPage: 1,
          hasNextPage: false,
          hasPrevPage: false,
          limit: query?.limitVal,
        },
      });
    } else {
      toast.error(result.errors?.[0] || "Failed to fetch promotional items");
    }
    setLoading(false);
  };

  // Delete
  const handleUserStatusChange = async (id) => {
    setLoading(true);
    const result = await AsyncDeleteApiCall(
      `/hotels/delete-launch-deals?dealId=${id}`
    );

    if (result.errors) {
      toast.error(result.errors[0]);
    } else if (result.success) {
      toast.success(`Deal deleted successfully`);
      getAllPromotionalList();
    }
    setLoading(false);
  };

  const handleViewHotel = async (hotelCode) => {
    window.open(
      `${process.env.REACT_APP_TRAVEL_URL}/hotel-details/${hotelCode}`,
      "_blank",
      "noopener,noreferrer"
    );
  };

  // Fetch promotional items on query change
  useEffect(() => {
    getAllPromotionalList();
    // eslint-disable-next-line
  }, [query]);

  const { data: promoData, pagination } = data;

  console.log("promoData000", promoData);

  return (
    <div className="card h-100 p-0 radius-12">
      {loading && <Loader />}
      <div className="card-header border-bottom bg-base py-16 px-24 d-flex align-items-center flex-wrap gap-3 justify-content-between">
        <div className="d-flex align-items-center flex-wrap gap-3">
          <span className="text-md fw-medium text-secondary-light mb-0">
            Show
          </span>
          <select
            className="form-select form-select-sm w-auto ps-12 py-6 radius-12 h-40-px"
            value={query.limitVal}
            onChange={(e) =>
              setQuery((prev) => ({
                ...prev,
                limitVal: parseInt(e.target.value, 10),
                pageNo: 1,
              }))
            }>
            {[5, 10, 15, 20, 25, 30].map((v) => (
              <option key={v} value={v}>
                {v}
              </option>
            ))}
          </select>
          {/* <div className="navbar-search">
            <input
              type="text"
              className="bg-base h-40-px w-auto"
              name="search"
              placeholder="Search"
              value={query.search}
              onChange={(e) =>
                setQuery((prev) => ({
                  ...prev,
                  search: e.target.value,
                  pageNo: 1,
                }))
              }
            />
            <Icon icon="ion:search-outline" className="icon" />
          </div> */}
        </div>
        <button
          type="button"
          className="btn btn-primary-600 radius-8 px-20 py-11 d-flex align-items-center gap-2"
          onClick={() => setShowModal(true)}
          disabled={loading}
          aria-label="Add new FAQ">
          <Icon
            icon="ic:baseline-plus"
            className="icon text-xl line-height-1"
          />
          Add
        </button>
      </div>
      <div className="card-body p-24">
        <div className="table-responsive scroll-sm">
          <table className="table bordered-table sm-table mb-0">
            <thead>
              <tr>
                <th>S.No</th>
                <th>Hotel Name</th>
                <th>Hotel Code</th>
                <th>Discount</th>
                <th>Created Date</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {promoData.length > 0 ? (
                promoData.map((item, index) => (
                  <tr key={item?._id}>
                    <td>
                      {(pagination.currentPage - 1) * pagination.limit +
                        index +
                        1}
                    </td>

                    <td className="d-flex align-items-center gap-2">
                      <img
                        src={
                          "https://photos.hotelbeds.com/giata/" +
                          item?.genImage?.url
                        }
                        alt={item?.hotelName || "Hotel"}
                        style={{
                          width: "40px",
                          height: "40px",
                          borderRadius: "8px",
                          objectFit: "cover",
                        }}
                        onError={(e) =>
                          (e.target.src = "/assets/images/no-image.jpg")
                        }
                      />
                      <span>{item?.hotelName || "N/A"}</span>
                    </td>

                    <td>{item?.hotelCode || "N/A"}</td>
                    <td>{item?.discount || "N/A"}</td>

                    <td>{new Date(item?.createdAt).toLocaleDateString()}</td>

                    <td className="text-center">
                      <div className="d-flex align-items-center gap-10 justify-content-center">
                        <button
                          type="button"
                          className="bg-success-focus text-success-600 bg-hover-success-200 fw-medium w-40-px h-40-px d-flex justify-content-center align-items-center rounded-circle"
                          onClick={() => {
                            setSelectedDeal(item);
                            setShowEditModal(true);
                          }}>
                          <Icon icon="lucide:edit" className="menu-icon" />
                          <span className="tooltip-text">Edit</span>
                        </button>
                        <button
                          type="button"
                          className="remove-item-btn bg-danger-focus bg-hover-danger-200 text-danger-600 fw-medium w-40-px h-40-px d-flex justify-content-center align-items-center rounded-circle"
                          onClick={() => handleUserStatusChange(item?._id)}>
                          {item?.isDeleted ? (
                            <TbRestore />
                          ) : (
                            <Icon
                              icon="fluent:delete-24-regular"
                              className="menu-icon"
                            />
                          )}
                          <span className="tooltip-text">Delete</span>
                        </button>

                        <button
                          type="button"
                          className="view-item-btn bg-primary-100 hover:bg-primary-200 text-primary-600 fw-medium w-40-px h-40-px d-flex justify-content-center align-items-center rounded-circle"
                          onClick={() => handleViewHotel(item?.hotelCode)}>
                          <FiEye />
                          <span className="tooltip-text">View</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="8" className="text-center">
                    No data found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <Paggination
          total={pagination?.total}
          totalPages={pagination?.totalPages}
          currentPage={pagination?.currentPage}
          setPageNo={(pageNo) => setQuery((prev) => ({ ...prev, pageNo }))}
          startFrom={(pagination.currentPage - 1) * pagination.limit + 1}
          endTo={
            (pagination.currentPage - 1) * pagination.limit + promoData.length
          }
        />
      </div>
      <SearchHotelModal
        show={showModal}
        onClose={() => setShowModal(false)}
        onSuccess={getAllPromotionalList}
      />
      <EditLaunchDealModal
        show={showEditModal}
        onClose={() => setShowEditModal(false)}
        deal={selectedDeal}
        onSuccess={getAllPromotionalList}
      />
    </div>
  );
};

export default LaunchDealsLayer;
