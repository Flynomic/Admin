import React, { useState } from "react";
import { Modal, Button, Form } from "react-bootstrap";
import { Icon } from "@iconify/react";
import useApi from "../../../hook/useApi";
import Loader from "../../../components/Loader/Loader";
import { toast } from "react-toastify";

const SearchHotelModal = ({ show, onClose, onSuccess }) => {
  const { AsyncGetApiCall, AsyncPostApiCall } = useApi();
  const [loading, setLoading] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [hotelList, setHotelList] = useState([]);
  const [selectedHotel, setSelectedHotel] = useState(null);
  const [discount, setDiscount] = useState("");
  const [discountError, setDiscountError] = useState("");

  // Search hotels
  const handleSearch = async () => {
    if (!searchText.trim()) {
      toast.warning("Please enter a hotel name to search");
      return;
    }
    setLoading(true);
    try {
      const result = await AsyncGetApiCall(
        `/hotels/search-location-name?searchData=${encodeURIComponent(
          searchText
        )}`
      );
      if (result.success) {
        const filtered = (result?.data || []).filter(
          (h) => h.source === "hotel-db"
        );
        setHotelList(filtered);
      } else {
        toast.error(result.message || "No results found");
        setHotelList([]);
      }
    } catch (error) {
      toast.error("Error while fetching hotels");
      setHotelList([]);
    }
    setLoading(false);
  };

  const handleSelectHotel = (hotel) => {
    setSelectedHotel(hotel);
  };

  // Validate discount value
  const validateDiscount = (value) => {
    if (value === "" || isNaN(value)) {
      setDiscountError("Please enter a discount value");
      return false;
    }
    if (value < 1) {
      setDiscountError("Discount must be at least 1%");
      return false;
    }
    if (value > 80) {
      setDiscountError("Maximum discount allowed is 80%");
      return false;
    }
    setDiscountError("");
    return true;
  };

  // Save selected hotel + discount
  const handleSave = async () => {
    if (!selectedHotel) {
      toast.error("Please select a hotel first");
      return;
    }

    const discountValue = Number(discount);
    if (!validateDiscount(discountValue)) {
      toast.error("Please enter a valid discount before saving");
      return;
    }

    const payload = {
      hotelCode: selectedHotel.hotelCode,
      discount: discountValue,
    };

    setLoading(true);
    try {
      const result = await AsyncPostApiCall(
        "/hotels/save-launch-deal",
        payload
      );
      if (result?.success) {
        toast.success("Launch deal saved successfully");
        onSuccess && onSuccess(payload);

        // Reset modal
        setSearchText("");
        setHotelList([]);
        setSelectedHotel(null);
        setDiscount("");
        setDiscountError("");
        onClose();
      } else {
        toast.error(result.errors?.[0] || "Failed to save launch deal");
      }
    } catch (error) {
      toast.error("Error while saving launch deal");
    }
    setLoading(false);
  };

  return (
    <Modal show={show} onHide={onClose} centered size="lg">
      {loading && <Loader />}
      <Modal.Header closeButton>
        <Modal.Title>Search Hotel</Modal.Title>
      </Modal.Header>

      <Modal.Body>
        {/* Search Input */}
        <div className="d-flex align-items-center gap-2 mb-3">
          <input
            type="text"
            className="form-control"
            placeholder="Search hotel name..."
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSearch()}
          />
          <Button variant="primary" onClick={handleSearch}>
            <Icon icon="ion:search-outline" className="me-1" />
            Search
          </Button>
        </div>

        {/* Hotel List */}
        {hotelList.length > 0 ? (
          <div
            className="border rounded p-2 mb-3"
            style={{ maxHeight: "200px", overflowY: "auto" }}>
            {hotelList.map((hotel) => (
              <div
                key={hotel?.hotelCode}
                className={`p-2 rounded mb-2 cursor-pointer ${
                  selectedHotel?.hotelCode === hotel.hotelCode
                    ? "bg-primary text-white"
                    : "bg-light"
                }`}
                onClick={() => handleSelectHotel(hotel)}>
                <div className="fw-bold">{hotel?.name}</div>
                <div className="small text-muted">Code: {hotel?.hotelCode}</div>
              </div>
            ))}
          </div>
        ) : (
          <p>No hotels found</p>
        )}

        {/* Selected Hotel Details */}
        {selectedHotel && (
          <div className="border rounded p-3 mb-3">
            <h6>Selected Hotel Details</h6>
            <p>
              <strong>Name:</strong> {selectedHotel?.name}
            </p>
            <p>
              <strong>Hotel Code:</strong> {selectedHotel?.hotelCode}
            </p>
          </div>
        )}

        {/* Discount Input */}
        <Form.Group className="mb-3">
          <Form.Label>Discount (%)</Form.Label>
          <Form.Control
            type="number"
            placeholder="Enter discount"
            min={1}
            max={80}
            step="0.1"
            value={discount}
            onChange={(e) => {
              const value = e.target.value;
              setDiscount(value);
              validateDiscount(Number(value));
            }}
            onBlur={(e) => validateDiscount(Number(e.target.value))}
          />
          {discountError && (
            <p className="text-danger small mt-1">{discountError}</p>
          )}
        </Form.Group>
      </Modal.Body>

      <Modal.Footer>
        <Button variant="secondary" onClick={onClose}>
          Cancel
        </Button>
        <Button variant="success" onClick={handleSave}>
          Save
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default SearchHotelModal;
