import React, { useState, useEffect } from "react";
import { Modal, Button, Form } from "react-bootstrap";
import { toast } from "react-toastify";
import useApi from "../../../hook/useApi";

const EditLaunchDealModal = ({ show, onClose, deal, onSuccess }) => {
  const { AsyncPutApiCall } = useApi();
  const [formData, setFormData] = useState({
    hotelCode: "",
    discount: "",
  });
  const [loading, setLoading] = useState(false);
  const [discountError, setDiscountError] = useState("");

  useEffect(() => {
    if (deal) {
      setFormData({
        hotelCode: deal?.hotelCode || "",
        discount: deal?.discount || "",
      });
      setDiscountError("");
    }
  }, [deal]);

  const validateDiscount = (value) => {
    if (value === "" || isNaN(value)) {
      setDiscountError("Please enter a discount value");
      return false;
    }
    if (value < 1) {
      setDiscountError("Discount must be at least 1%");
      return false;
    }
    if (value > 80) {
      setDiscountError("Maximum discount allowed is 80%");
      return false;
    }
    setDiscountError("");
    return true;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));

    if (name === "discount") {
      validateDiscount(Number(value));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const discountValue = Number(formData.discount);
    if (!validateDiscount(discountValue)) {
      toast.error("Please enter a valid discount before updating");
      return;
    }

    setLoading(true);

    const bodyData = {
      ...formData,
      dealId: deal?._id,
    };

    try {
      const result = await AsyncPutApiCall(
        `/hotels/update-launch-deals`,
        bodyData
      );
      if (result.success) {
        toast.success("Deal updated successfully");
        onSuccess && onSuccess();
        onClose();
      } else {
        toast.error(result.errors?.[0] || "Failed to update deal");
      }
    } catch (error) {
      toast.error("Error while updating deal");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal show={show} onHide={onClose} centered>
      <Modal.Header closeButton>
        <Modal.Title>Edit Launch Deal</Modal.Title>
      </Modal.Header>

      <Form onSubmit={handleSubmit}>
        <Modal.Body>
          {/* Hotel Code */}
          <Form.Group className="mb-3">
            <Form.Label>Hotel Code</Form.Label>
            <Form.Control
              type="text"
              name="hotelCode"
              value={formData?.hotelCode}
              disabled
              readOnly
            />
          </Form.Group>

          {/* Discount */}
          <Form.Group className="mb-3">
            <Form.Label>Discount (max 80%)</Form.Label>
            <Form.Control
              type="number"
              name="discount"
              placeholder="Enter discount"
              min={1}
              max={80}
              step="0.1"
              value={formData?.discount}
              onChange={handleChange}
              onBlur={(e) => validateDiscount(Number(e.target.value))}
              className={discountError ? "is-invalid" : ""}
              required
            />
            {discountError && (
              <Form.Text className="text-danger small">
                {discountError}
              </Form.Text>
            )}
          </Form.Group>
        </Modal.Body>

        <Modal.Footer>
          <Button variant="secondary" onClick={onClose} disabled={loading}>
            Cancel
          </Button>
          <Button type="submit" variant="primary" disabled={loading}>
            {loading ? "Updating..." : "Update"}
          </Button>
        </Modal.Footer>
      </Form>
    </Modal>
  );
};

export default EditLaunchDealModal;
