import React from "react";
import LaunchDealsLayer from "./LaunchDealsLayer";
import MasterLayout from "../../masterLayout/MasterLayout";
import Breadcrumb from "../../components/Breadcrumb";

const LaunchDealsPage = () => {
  return (
    <>
      {/* MasterLayout */}
      <MasterLayout>
        {/* Breadcrumb */}
        <Breadcrumb title="Launch Deals" />

        <LaunchDealsLayer />
      </MasterLayout>
    </>
  );
};

export default LaunchDealsPage;
