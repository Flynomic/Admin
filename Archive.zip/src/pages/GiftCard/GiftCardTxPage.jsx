import React from "react";
import MasterLayout from "../../masterLayout/MasterLayout";
import Breadcrumb from "../../components/Breadcrumb";
import GiftCardTxLayer from "../../components/GiftCard/GiftCardTxLayer";

const GiftCardTxPage = () => {
  return (
    <>
      {/* MasterLayout */}
      <MasterLayout>
        {/* Breadcrumb */}
        <Breadcrumb title="Gift Card Transactions" />

        <GiftCardTxLayer />
      </MasterLayout>
    </>
  );
};

export default GiftCardTxPage;
