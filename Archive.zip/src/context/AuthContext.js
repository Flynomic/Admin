// src/context/AuthContext.js
import { createContext, useContext, useState, useEffect } from "react";
import { toast } from "react-toastify";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [profile, setProfile] = useState(null); // for admin profile
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = sessionStorage.getItem("token");
    const storedProfile = localStorage.getItem("profile");
    setIsAuthenticated(!!token);
    if (storedProfile) {
      setProfile(JSON.parse(storedProfile));
    }
    setLoading(false);
  }, []);

  const login = (token, profileData) => {
    console.log("token and profileData : ", token, profileData);
    sessionStorage.setItem("token", token);
    localStorage.setItem("profile", JSON.stringify(profileData));
    setIsAuthenticated(true);
    setProfile(profileData);
  };

  const logout = () => {
    sessionStorage.removeItem("token");
    localStorage.removeItem("profile");
    setIsAuthenticated(false);
    setProfile(null);
    toast.success("Admin logged out successfully.");
  };

  return (
    <AuthContext.Provider
      value={{ isAuthenticated, login, logout, profile, setProfile, loading }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
