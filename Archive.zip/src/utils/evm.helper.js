import { isAddress } from "ethers/lib/utils";

export const isValidEVMAddress = (address) => {
  return isAddress(address);
};
