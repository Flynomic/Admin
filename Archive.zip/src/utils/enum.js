export const ROLES = Object.freeze({
  USER: "user",
  DRIVER: "driver",
  ADMIN: "admin",
  BUSINESS: "business",
  SUPER_ADMIN: "super_admin",
});

export const FAQTAG = Object.freeze({
  ABOUT_US: "about_us",
  DESIGN: "design",
  DEVELOPMENT: "development",
  FLYNOMIC_USE: "flynomic_use",
  AGENCY: "agency",
  OTHER: "other",
});

export const PageType = Object.freeze({
  ABOUT_US: "about-us",
  TERMS_AND_CONDITIONS: "terms-and-conditions",
  PRIVACY_POLICY: "privacy-policy",
});

export const userPageType = Object.freeze({
  VIEW: "VIEW",
  UPDATE: "UPDATE",
});

export const USER_TYPE = Object.freeze({
  ACTIVE: "Active",
  INACTIVE: "Inactive",
  SELECTSTATUS: "Select Status",
});

export const percentMode = Object.freeze({
  PERCENTAGE: "percentage",
  FIXED: "fixed",
});

export const activeStatus = Object.freeze({
  ACTIVE: true,
  INACTIVE: false,
});

export const blogCategories = Object.freeze({
  TECHNICAL: "technical",
  LIFESTYLE: "lifestyle",
  FINANCE: "finance",
});

export const CATEGORY = Object.freeze({
  TECHNICAL: "technical",
  LIFESTYLE: "lifestyle",
  FINANCE: "finance",
});

export const CURRENCY = Object.freeze({
  DOLLAR: "dollar",
  INR: "inr",
});

export const PLATFORM_TYPE = Object.freeze({
  ICO: "ico",
  TRAVEL: "travel",
});

export const PAGE_TYPE = Object.freeze({
  ABOUT_US: "about-us",
  TERMS_AND_CONDITIONS: "terms-and-conditions",
  PRIVACY_POLICY: "privacy-policy",
  HOME_PAGE_STATICS: "home-page-statics",
});

export const CMS_WEBSITE_TYPE = Object.freeze({
  ICO: "ico",
  TRAVEL: "travel",
});


export const HOTEL_PAX = Object.freeze({
  AD: "ADULT",
  CH: "CHILD",
});