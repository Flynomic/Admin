export const BASE_URL = process.env.REACT_APP_API_URL;
export const API_KEY = process.env.X_API_KEY;

export const AIRLINE_CODE = Object.freeze({
     VF: "Air France",
     VY: "Vueling Airlines",
     W6: "Wizz Air",
     "6E": "IndiGo",
     AI: "Air India",
     G8: "GoAir",
     I5: "InterGlobe Aviation",
     SG: "SpiceJet",
     UK: "Air UK",
     ZE: "Air Arabia",
     ZY: "Air Zermatt",
     WN: "Southwest Airlines",
     Y8: "Air Arabia Egypt",
     Y9: "Air Arabia Jordan",
     YT: "Air Tahiti Nui",
     YZ: "Air Zermatt",
     ZH: "Air China",
     ZX: "Air China Express",
     ZZ: "Air Zermatt",
     IX: "Air India Express",
     MH: "Malaysia Airlines",
     TG: "Thai Airways International",
     QR: "Qatar Airways",
     TR: "Tiger Airways",
     HU: "Hainan Airlines",
     BS: "US-Bangla Airlines",
     CX: "Cathay Pacific",
     EK: "Emirates",
     EY: "Etihad Airways",
     H1: "Hahnair Systems",
     GP: "APG Airlines",
     G9: "Air Arabia",
});

export const CURRENCY_CODE = Object.freeze({
     EUR: "€",
     GBP: "£",
     AED: "د.إ",
     INR: "₹",
     USD: "$",
     JPY: "¥",
     CNY: "¥",
     BRL: "R$",
     VND: "₫"
});

export const CABIN_PREFERENCE = Object.freeze({
     Y: "Economy",
     C: "Business",
     F: "First",
     S: "Premium Economy",
});

export const REFUND_STATUS = Object.freeze({
     not_applicable: 'N/A',
     pending: 'PENDING',
     completed: 'COMPLETED',
     failed: 'FAILED',
     rejected: 'REJECTED',
});

export const BOOKING_PAGE_TYPE = Object.freeze({
     VIEW: 'view',
     EDIT: 'edit',
     REFUND: 'refund',
});

export const HOTEL_BOOKING_STATUS = Object.freeze({
     PENDING: 'PENDING',
     CONFIRMED: 'CONFIRMED',
     CANCELLED: 'CANCELLED',
});

export const FLIGHT_BOOKING_STATUS = Object.freeze({
     BOOKED: 'Booked',
     PENDING: 'Pending',
     CANCELLED: 'Cancelled'
});
