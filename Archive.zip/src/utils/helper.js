import { toast } from "react-toastify";
import { percentMode } from "./enum";
import { ethers } from 'ethers';
import { isAddress } from 'ethers/lib/utils';

export const isValidEVMAddress = (address) => {
  return isAddress(address);
};

export function getErrorsList(error) {
  return Array.isArray(error) ? error : [error || "Internal server error"];
}

export const getHeaders = () => {
  const token = sessionStorage.getItem("token");

  let headers = {
    "x-api-key": process.env.REACT_APP_X_API_KEY, // ✅ Add API Key if required
    "Content-Type": "application/json", // ✅ Set content type for better handling
  };

  if (token) {
    headers.Authorization = `Bearer ${token}`; // ✅ Only include if token exists
  }

  return headers;
};

export const trimAddress = (address, firstChar, lastChar) => {
  if (!address || typeof address !== "string") {
    return "";
  }

  if (address.length <= firstChar + lastChar) {
    return address;
  } else {
    return address.slice(0, firstChar) + "..." + address.slice(-lastChar);
  }
};

export const formatDate = (isoString, isTime) => {
  const date = new Date(isoString);
  if (isTime) {
    return date.toLocaleString("en-US", {
      month: "numeric",
      day: "numeric",
      year: "numeric",
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    });
  } else {
    return date.toLocaleString("en-US", {
      month: "numeric",
      day: "numeric",
      year: "numeric",
    });
  }
};

export const ValidateInputs = (name, value, errors, formData) => {
  const newErrors = { ...errors };

  switch (name) {
    case "firstName":
      if (!value.trim()) {
        newErrors.firstName = "First name is required";
      } else if (value.trim().length > 50) {
        newErrors.firstName = "First name cannot exceed 50 characters";
      } else {
        newErrors.firstName = "";
      }
      break;

    case "lastName":
      if (!value.trim()) {
        newErrors.lastName = "Last name is required";
      } else if (value.trim().length > 50) {
        newErrors.lastName = "Last name cannot exceed 50 characters";
      } else {
        newErrors.lastName = "";
      }
      break;

    case "name":
      if (!value.trim()) {
        newErrors.name = "Name is required";
      } else if (value.trim().length > 50) {
        newErrors.name = "Name cannot exceed 50 characters";
      } else {
        newErrors.name = "";
      }
      break;

    case "email":
      if (!value.trim()) {
        newErrors.email = "Email is required";
      } else if (value.trim().length > 100) {
        newErrors.email = "Email cannot exceed 100 characters";
      } else if (
        !/^[a-zA-Z0-9]+(?:\.[a-zA-Z0-9]+)*@[a-zA-Z0-9]+(?:-[a-zA-Z0-9]+)*\.[a-zA-Z]{2,}$/.test(
          value
        )
      ) {
        newErrors.email = "Email is invalid";
      } else {
        newErrors.email = "";
      }
      break;

    case "phoneNumber":
      if (value) {
        if (!/^\d{8,14}$/.test(value)) {
          newErrors.phoneNumber = "Phone number must be 8 to 14 digits";
        } else {
          newErrors.phoneNumber = "";
        }
      } else {
        newErrors.phoneNumber = "";
      }
      break;

    case "contactNumber":
      if (!value) {
        newErrors.contactNumber = "Phone number is required";
      } else if (value.length > 14) {
        newErrors.contactNumber = "Phone number cannot exceed 14 digits";
      } else if (!/^\d{8,14}$/.test(value)) {
        newErrors.contactNumber = "Phone number must be 8–14 digits";
      } else {
        newErrors.contactNumber = "";
      }
      break;

    case "address":
      if (!value.trim()) {
        newErrors.address = "Address is required";
      } else if (value.trim().length > 200) {
        newErrors.address = "Address cannot exceed 200 characters";
      } else {
        newErrors.address = "";
      }
      break;

    case "walletAddress":
      if (!value.trim()) {
        newErrors.walletAddress = "Wallet address is required";
      } else if (value.trim().length > 100) {
        newErrors.walletAddress = "Wallet address cannot exceed 100 characters";
      } else if (!isValidEVMAddress(value)) {
        newErrors.walletAddress = "Wallet address is invalid";
      }
      else {
        newErrors.walletAddress = "";
      }
      break;

    case "newPassword":
      if (!value.trim()) {
        newErrors.newPassword = "Password is required";
      } else if (value.length < 8) {
        newErrors.newPassword = "Password must be at least 8 characters long";
      } else if (value.length > 128) {
        newErrors.newPassword = "Password cannot exceed 128 characters";
      } else if (!/[A-Z]/.test(value)) {
        newErrors.newPassword =
          "Password must contain at least one uppercase letter";
      } else if (!/[a-z]/.test(value)) {
        newErrors.newPassword =
          "Password must contain at least one lowercase letter";
      } else if (!/[0-9]/.test(value)) {
        newErrors.newPassword = "Password must contain at least one number";
      } else if (!/[!@#$%^&*(),.?":{}|<>]/.test(value)) {
        newErrors.newPassword =
          "Password must contain at least one special character";
      } else {
        newErrors.newPassword = "";
      }
      break;

    case "oldPassword":
      if (!value.trim()) {
        newErrors.oldPassword = "Old Password is required";
      } else if (value.trim().length > 128) {
        newErrors.oldPassword = "Old Password cannot exceed 128 characters";
      } else {
        newErrors.oldPassword = "";
      }
      break;

    case "confirmPassword":
      if (!value.trim()) {
        newErrors.confirmPassword = "Confirm Password is required";
      } else if (value.trim().length > 128) {
        newErrors.confirmPassword =
          "Confirm Password cannot exceed 128 characters";
      } else {
        newErrors.confirmPassword = "";
      }
      break;

    case "password":
      if (!value.trim()) {
        newErrors.password = "Password is required";
      } else if (value.length < 8) {
        newErrors.password = "Password must be at least 8 characters long";
      } else if (value.length > 128) {
        newErrors.password = "Password cannot exceed 128 characters";
      } else if (!/[A-Z]/.test(value)) {
        newErrors.password =
          "Password must contain at least one uppercase letter";
      } else if (!/[a-z]/.test(value)) {
        newErrors.password =
          "Password must contain at least one lowercase letter";
      } else if (!/[0-9]/.test(value)) {
        newErrors.password = "Password must contain at least one number";
      } else if (!/[!@#$%^&*(),.?":{}|<>]/.test(value)) {
        newErrors.password =
          "Password must contain at least one special character";
      } else {
        newErrors.password = "";
      }
      break;

    case "value":
      if (!value) {
        newErrors.value = "Value is required";
      } else if (String(value).length > 10) {
        newErrors.value = "Value cannot exceed 10 digits";
      } else if (isNaN(value) || Number(value) <= 0) {
        newErrors.value = "Value must be a positive number";
      } else {
        newErrors.value = "";
      }
      break;

    case "mode":
      if (!value.trim()) {
        newErrors.mode = "Mode is required";
      } else if (value !== percentMode.PERCENTAGE && value !== percentMode.FIXED) {
        newErrors.mode = "Invalid mode selected";
      } else {
        newErrors.mode = "";
      }
      break;

    case "isActive":
      if (value === "" || value === null || value === undefined) {
        newErrors.isActive = "Activation status is required";
      } else {
        newErrors.isActive = "";
      }
      break;

    case "title":
      if (!value.trim()) {
        newErrors.title = "Title is required";
      } else if (value.trim().length > 100) {
        newErrors.title = "Title cannot exceed 100 characters";
      } else {
        newErrors.title = "";
      }
      break;

    case "content":
      if (!value.trim()) {
        newErrors.content = "Content is required";
      } else if (value.trim().length > 1000) {
        newErrors.content = "Content cannot exceed 1000 characters";
      } else {
        newErrors.content = "";
      }
      break;

    case "category":
      if (!value.trim()) {
        newErrors.category = "Category is required";
      } else if (value.trim().length > 50) {
        newErrors.category = "Category cannot exceed 50 characters";
      } else {
        newErrors.category = "";
      }
      break;

    case "amount":
      if (!value) {
        newErrors.amount = "Amount is required";
      } else if (!value || isNaN(Number(value))) {
        newErrors.amount = "Amount must be a number";
      } else if (Number(value) <= 0) {
        newErrors.amount = "Amount must be greater than 0";
      } else if (Number(value) < 10) {
        newErrors.amount = "Amount must be at least 10";
      } else if (Number(value) > 2000) {
        newErrors.amount = "Amount cannot be more than 2000";
      } else if (String(value).length > 10) {
        newErrors.amount = "Amount cannot exceed 10 digits";
      } else {
        newErrors.amount = "";
      }
      break;

    case "currency":
      if (!value.trim()) {
        newErrors.currency = "Currency is required";
      } else {
        newErrors.currency = "";
      }
      break;

    case "question":
      if (!value.trim()) {
        newErrors.question = "Question is required";
      } else if (value.trim().length > 100) {
        newErrors.question = "Question cannot exceed 100 characters";
      } else {
        newErrors.question = "";
      }
      break;

    case "answer":
      if (!value.trim()) {
        newErrors.answer = "Answer is required";
      } else if (value.trim().length > 300) {
        newErrors.answer = "Answer cannot exceed 300 characters";
      } else {
        newErrors.answer = "";
      }
      break;

    case "review":
      if (!value.trim()) {
        newErrors.review = "Review is required";
      } else if (value.trim().length > 200) {
        newErrors.review = "Review cannot exceed 200 characters";
      } else {
        newErrors.review = "";
      }
      break;

    case "webType":
      if (!value) {
        newErrors.webType = "Platform type is required";
      } else {
        newErrors.webType = "";
      }
      break;

    case "couponCode":
      if (!value.trim()) {
        newErrors.couponCode = "Coupon code is required";
      } else if (!/^[a-zA-Z0-9]{12}$/.test(value)) {
        newErrors.couponCode = "Coupon code must 12 alphanumeric characters";
      } else {
        newErrors.couponCode = "";
      }
      break;

    case "amount":
      if (!value || isNaN(Number(value))) {
        newErrors.amount = "Amount must be a number";
      } else if (Number(value) <= 0) {
        newErrors.amount = "Amount must be greater than 0";
      } else if (Number(value) < 10) {
        newErrors.amount = "Amount must be at least 10";
      } else if (Number(value) > 2000) {
        newErrors.amount = "Amount cannot be more than 2000";
      } else {
        newErrors.amount = "";
      }
      break;

    case "startDate":
      if (!value) {
        newErrors.startDate = "Start date is required";
      } else {
        const minDate = new Date();
        minDate.setHours(0, 0, 0, 0); // Start of today
        const selectedDate = new Date(value);
        if (selectedDate < minDate) {
          newErrors.startDate = "Start date cannot be before today";
        } else {
          newErrors.startDate = "";
        }
      }
      break;

    case "endDate":
      if (!value) {
        newErrors.endDate = "End date is required";
      } else if (formData.startDate) {
        const startDate = new Date(formData.startDate);
        const endDate = new Date(value);
        const minEndDate = new Date(startDate);
        minEndDate.setDate(startDate.getDate() + 1);
        minEndDate.setHours(0, 0, 0, 0); // Start of next day
        const maxDate = new Date(startDate);
        maxDate.setFullYear(startDate.getFullYear() + 5); // 5 years max

        if (endDate < minEndDate) {
          newErrors.endDate = "End date must be at least one day after start date";
        } else if (endDate > maxDate) {
          newErrors.endDate = "End date cannot be more than 5 years from start date";
        } else {
          newErrors.endDate = "";
        }
      } else {
        // If startDate is not set, endDate is invalid until startDate is provided
        newErrors.endDate = "Please set a start date first";
      }
      break;

    case "couponType":
      if (!value) {
        newErrors.couponType = "Coupon type is required";
      } else if (!["HOTEL", "FLIGHT"].includes(value)) {
        newErrors.couponType = "Coupon type must be either HOTEL or FLIGHT";
      } else {
        newErrors.couponType = "";
      }
      break;

    case "description":
      if (!value || typeof value !== "string") {
        newErrors.description = "Description is required";
      } else if (value.length > 100) {
        newErrors.description = "Description cannot exceed 100 characters";
      } else {
        newErrors.description = "";
      }
      break;

    case "maxUsageByUser":
      if (value === "" || isNaN(Number(value)) || value === 0) {
        newErrors.maxUsageByUser = "Max usage must not be empty and should be between 1 and 1000";
      } else {
        newErrors.maxUsageByUser = "";
      }
      break;

    case "maxUsageOfCoupon":
      if (value === "" || isNaN(Number(value)) || value === 0) {
        newErrors.maxUsageOfCoupon = "Max usage must not be empty and should be between 1 and 100 million";
      } else {
        newErrors.maxUsageOfCoupon = "";
      }
      break;

    default:
      break;
  }

  return newErrors;
};

export const copyToClipboard = (address) => {
  if (address) {
    navigator?.clipboard
      ?.writeText(address)
      .then(() => {
        toast.success("Copied to clipboard!");
      })
      .catch((error) => {
        toast.error("Failed to copy address.");
        console.error("Error copying to clipboard:", error);
      });
  } else {
    toast.warning("No address available to copy.");
  }
};

export const getContentSnippet = (content) => {
  const words = content.split(" ");
  return words.slice(0, 10).join(" ") + (words.length > 10 ? "..." : "");
};

export const stripHtml = (html) => {
  const div = document.createElement("div");
  div.innerHTML = html;
  return div.textContent || div.innerText || "";
};


// Get minimum date (today)
export const getMinDate = () => {
  const date = new Date();
  return formatDate(date);
};

// Get maximum date (5 years from provided start date)
export const getMaxDate = (startDate) => {
  const date = new Date(startDate);
  if (isNaN(date.getTime())) {
    // Fallback to current date if startDate is invalid
    return formatDate(new Date());
  }
  date.setFullYear(date.getFullYear() + 5);
  return formatDate(date);
};
