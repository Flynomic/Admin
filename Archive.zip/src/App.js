// src/App.js
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import SignInPage from "./pages/SignInPage";
import ForgotPasswordPage from "./pages/ForgotPasswordPage";
import ErrorPage from "./pages/ErrorPage";
import AppRoutes from "./AppRoutes"; // ✅ Make sure this import is present
import ForgotPasswordToken from "./components/auth/ForgotPasswordEmail";
import PrivateRoute from "./components/auth/PrivateRoute";

// Rahul

function App() {
  return (
    <AuthProvider>
      <BrowserRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<SignInPage />} />
          <Route path="/forgot-password" element={<ForgotPasswordPage />} />
          <Route
            path="/forgot-password-token/:token"
            element={<ForgotPasswordToken />}
          />

          {/* Private Routes */}
          <Route
            path="/*"
            element={
              <PrivateRoute>
                <AppRoutes />
              </PrivateRoute>
            }
          />

          {/* Fallback */}
          <Route path="*" element={<ErrorPage />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App; // ✅ Ensure this line exists
