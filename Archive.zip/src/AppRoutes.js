// src/AppRoutes.js
import { Route, Routes } from "react-router-dom";
import HomePageOne from "./pages/HomePageOne";
import ViewProfilePageAdmin from "./pages/Admin Profile/ViewProfilePageAdmin";
import FaqPage from "./pages/FaqPage";
import TermsConditionPage from "./pages/TermsConditionPage";
import PrivacyPolicyPage from "./pages/PrivacyPolicyPage";
import AboutUsPage from "./pages/AboutUsPage";
import UsersListPage from "./pages/User/UsersListPage";
import HotelsListPage from "./pages/Hotel Booking/HotelsListPage";
import WhiteListRequestPage from "./pages/Whitelist Request/WhiteListRequestPage";
import ViewProfilePage from "./pages/User/ViewProfilePage";
import FlightListPage from "./pages/Flight Booking/FlightListPage";
import ViewHotelBookingPage from "./pages/Hotel Booking/ViewHotelBookingPage";
import ViewFlightBookingPage from "./pages/Flight Booking/ViewFlightBookingPage";
import ReviewPage from "./pages/Review & Rating/ReviewPage";
import MarkupListPage from "./pages/Markup/MarkupListPage";
import BlogPage from "./pages/Blog/BlogPage";
import EditBlogPage from "./pages/Blog/EditBlogPage";
import EditMarkupPage from "./pages/Markup/EditMarkupPage";
import PromotionalUpdatePage from "./pages/PromotionalCampaigns/Update/PromotionalUpdatePage";
import GiftCardTxPage from "./pages/GiftCard/GiftCardTxPage";
import GiftCardPage from "./pages/GiftCard/GiftCardPage";
import ContentManagementPage from "./pages/ContentManagementPage";
import CouponPage from "./pages/Coupon/CouponPage";
import NotificationPage from "./pages/Notifications/NotificationPage";
import CustomerSupportPage from "./pages/Customer Support/CustomerSupportPage";
import FiatCryptoTxPage from "./pages/FiatCryptoTransactions/FiatCryptoTxPage";
import PromotionalPage from "./pages/PromotionalCampaigns/List/PromotionalPage";
import HomePageStatics from "./pages/HomePageStatics";
import LaunchDealsPage from "./pages/LaunchDeals/LaunchDealsPage";


function AppRoutes() {
  return (
    <Routes>
      <Route path="/dashboard" element={<HomePageOne />} />
      <Route path="/view-admin-profile" element={<ViewProfilePageAdmin />} />
      <Route path="/view-user-profile/:id" element={<ViewProfilePage />} />
      <Route path="/edit-user-profile/:id" element={<ViewProfilePage />} />
      <Route path="/faq" element={<FaqPage />} />
      <Route path="/terms-condition" element={<TermsConditionPage />} />

      <Route path="/home-page-statics" element={<HomePageStatics />} />


      <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />
      <Route path="/about-us" element={<AboutUsPage />} />
      <Route path="/users-list" element={<UsersListPage />} />

      <Route path="/hotel-booking" element={<HotelsListPage />} />
      <Route path="/markups" element={<MarkupListPage />} />
      <Route path="/blog" element={<BlogPage />} />
      <Route path="/gift-cards" element={<GiftCardPage />} />
      <Route path="/gift-cards-tx" element={<GiftCardTxPage />} />
      <Route
        path="/hotel-booking/view-booking/:id"
        element={<ViewHotelBookingPage />}
      />

      <Route path="/flight-booking" element={<FlightListPage />} />
      <Route

        path="/flight-booking/view-booking/:id"
        element={<ViewFlightBookingPage />}
      />

      <Route path="/fiat-crypto-transactions" element={<FiatCryptoTxPage />} />


      <Route path="/blog/edit-blog/:id" element={<EditBlogPage />} />
      <Route path="/coupon-code" element={<CouponPage />} />
      <Route path="/notifications" element={<NotificationPage />} />
      <Route

        path="/markups/edit-markup/:id"
        element={<EditMarkupPage />}
      />
      <Route

        path="/whitelist-request"
        element={<WhiteListRequestPage />}
      />
      <Route path="/content" element={<ContentManagementPage />} />

      <Route path="/review-and-rating" element={<ReviewPage />} />
      <Route path="/customer-support" element={<CustomerSupportPage />} />
      <Route
        path="/promotional-campaigns"
        element={<PromotionalPage />}
      />

      <Route
        path="/launch-deals"
        element={<LaunchDealsPage />}
      />

      <Route
        path="/promotional-campaigns/details/:id"
        element={<PromotionalUpdatePage />}
      />

    </Routes>
  );
}

export default AppRoutes;
