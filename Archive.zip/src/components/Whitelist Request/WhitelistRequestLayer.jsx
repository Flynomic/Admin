import { Icon } from "@iconify/react/dist/iconify.js";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import useApi from "../../hook/useApi";
import Paggination from "../Paggination";
import { toast } from "react-toastify";
import Loader from "../Loader/Loader";
import AddWhitelistModal from "../model/AddWhitelistModal";

const WhitelistRequestLayer = () => {
  const { AsyncGetApiCall, AsyncPostApiCall, AsyncDeleteApiCall } = useApi();

  const [showModal, setShowModal] = useState(false);
  const [currentTask, setCurrentTask] = useState(null);

  const [query, setQuery] = useState({
    pageNo: 1,
    limitVal: 50,
    search: "",
    isWhitelisted: null,
  });
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState(null);

  const handleSaveTask = async (data) => {
    setLoading(true);

    const result = await AsyncPostApiCall(
      "/whitelisteduser/request-whitelist",
      data
    );

    if (result.success) {
      toast.success("Whitelist request created successfully");
      setQuery((prev) => ({
        ...prev,
        search: "",
      }));
    } else {
      toast.error(result.errors?.[0]);
    }

    setLoading(false);
    setShowModal(false);
  };

  const getAllUsersList = async () => {
    setLoading(true);
    const result = await AsyncGetApiCall(
      "/whitelisteduser/get-whitelisted-users",
      query
    );
    console.log("Reslult : ", result);

    if (result.success) {
      setData(result);
    }
    setLoading(false);
  };

  const approveWhitelist = async (id, whitelist) => {
    setLoading(true);
    const payload = {
      id,
      isWhitelisted: whitelist,
    };
    console.log("payload : ", payload);

    const result = await AsyncPostApiCall(
      "/whitelisteduser/approve-whitelistuser",
      payload
    );
    console.log("Reslult : ", result);

    if (result.success) {
      toast.success(
        `Whitelist ${whitelist ? "approved" : "rejected"} successfully`
      );
      setQuery((prev) => ({
        ...prev,
        search: "",
      }));
    } else {
      toast.error(result.errors[0]);
    }
    setLoading(false);
  };

  const removeWhitelist = async (id) => {
    setLoading(true);
    const result = await AsyncDeleteApiCall(`/whitelisteduser/delete/${id}`);
    console.log("Reslult : ", result);

    if (result.success) {
      toast.success(`Whitelist request deleted successfully`);
      setQuery((prev) => ({
        ...prev,
        search: "",
      }));
    } else {
      toast.error(result.errors[0]);
    }
    setLoading(false);
  };

  const setPageNo = (pageNo) => {
    setQuery((prev) => ({
      ...prev,
      pageNo: pageNo,
    }));
  };

  useEffect(() => {
    getAllUsersList();
  }, [query]);

  console.log("data : ", data);

  return (
    <div className="card h-100 p-0 radius-12">
      {loading && <Loader />}
      <div className="card-header border-bottom bg-base py-16 px-24 d-flex align-items-center flex-wrap gap-3 justify-content-between">
        <div className="d-flex align-items-center flex-wrap gap-3">
          <span className="text-md fw-medium text-secondary-light mb-0">
            Show
          </span>
          <select
            className="form-select form-select-sm w-auto ps-12 py-6 radius-12 h-40-px"
            defaultValue="Select Number"
            onChange={(e) => {
              const value = parseInt(e.target.value, 10);
              setQuery((prev) => ({
                ...prev,
                limitVal: value,
              }));
            }}
          >
            <option value="Select Number" disabled>
              Select Number
            </option>
            {Array.from({ length: 20 }, (_, i) => {
              const value = (i + 1) * 5;
              return (
                <option key={value} value={value}>
                  {value}
                </option>
              );
            })}
          </select>
          <form className="navbar-search">
            <input
              type="text"
              className="bg-base h-40-px w-auto"
              name="search"
              placeholder="Search"
              value={query.search}
              onChange={(e) => {
                setQuery((prev) => ({
                  ...prev,
                  search: e.target.value,
                }));
              }}
            />
            <Icon icon="ion:search-outline" className="icon" />
          </form>
          <select
            className="form-select form-select-sm w-auto ps-12 py-6 radius-12 h-40-px"
            value={
              query.isWhitelisted === null
                ? "Select Status"
                : query.isWhitelisted.toString()
            }
            onChange={(e) => {
              const value = e.target.value;
              setQuery((prev) => ({
                ...prev,
                isWhitelisted: value === "all" ? null : value === "true",
              }));
            }}
          >
            <option value="all">All</option>
            <option value="true">Approved</option>
            <option value="false">Pending</option>
          </select>
        </div>
        <button
          type="button"
          className="btn btn-primary-600 radius-8 px-20 py-11 d-flex align-items-center gap-2"
          onClick={() => {
            setCurrentTask(null);
            setShowModal(true);
          }}
          disabled={loading}
          aria-label="Add new FAQ"
        >
          <Icon
            icon="ic:baseline-plus"
            className="icon text-xl line-height-1"
          />
          Add Whitelist User
        </button>
      </div>
      <div className="card-body p-24">
        <div className="table-responsive scroll-sm">
          <table className="table bordered-table sm-table mb-0">
            <thead>
              <tr>
                <th scope="col">
                  <div className="d-flex align-items-center gap-10">S.No</div>
                </th>
                <th scope="col">Requested Date</th>
                <th scope="col">Email</th>
                <th scope="col">Wallet Address</th>
                <th scope="col" className="text-center">
                  Status
                </th>
                <th scope="col" className="text-center">
                  Action
                </th>
              </tr>
            </thead>
            <tbody>
              {data && data.data.length > 0 ? (
                data.data.map((item, index) => (
                  <tr key={item._id}>
                    <td>
                      <div className="d-flex align-items-center gap-10">
                        {(data?.currentPage - 1) * query.limitVal + index + 1}
                      </div>
                    </td>
                    <td>{new Date(item.createdAt).toLocaleDateString()}</td>
                    <td>
                      <span className="text-md mb-0 fw-normal text-secondary-light">
                        {item.email}
                      </span>
                    </td>
                    <td>{item.walletAddress}</td>
                    <td className="text-center">
                      {item.isWhitelisted ? (
                        <span
                          className="cursor-pointer bg-success-focus text-success-600 border border-success-main px-24 py-4 radius-4 fw-medium text-sm"
                          onClick={async () => {
                            await approveWhitelist(
                              item?._id,
                              !item?.isWhitelisted
                            );
                          }}
                        >
                          Approved
                        </span>
                      ) : (
                        <span
                          className="cursor-pointer bg-neutral-200 text-neutral-600 border border-neutral-400 px-24 py-4 radius-4 fw-medium text-sm"
                          onClick={async () => {
                            await approveWhitelist(
                              item?._id,
                              !item?.isWhitelisted
                            );
                          }}
                        >
                          Pending
                        </span>
                      )}
                    </td>
                    <td className="text-center">
                      <div className="d-flex align-items-center gap-10 justify-content-center">
                        <button
                          type="button"
                          className="remove-item-btn bg-danger-focus bg-hover-danger-200 text-danger-600 fw-medium w-40-px h-40-px d-flex justify-content-center align-items-center rounded-circle"
                          onClick={async () => {
                            const confirmDelete = window.confirm(
                              "Do you want to delete this whitelist request?"
                            );
                            if (confirmDelete) {
                              await removeWhitelist(item?._id);
                            }
                          }}
                        >
                          <Icon
                            icon="fluent:delete-24-regular"
                            className="menu-icon"
                          />
                          <span className="tooltip-text">Delete</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="6" className="text-center">
                    No data found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <Paggination
          total={data?.total || 0}
          totalPages={data?.totalPages || 0}
          currentPage={data?.currentPage || 0}
          setPageNo={setPageNo}
          startFrom={(data?.currentPage - 1) * query.limitVal + 1}
          endTo={(data?.currentPage - 1) * query.limitVal + data?.data?.length}
        />
      </div>
      {
        <AddWhitelistModal
          show={showModal}
          handleClose={() => setShowModal(false)}
          handleSave={handleSaveTask}
          task={currentTask}
          loading={loading}
        />
      }
    </div>
  );
};

export default WhitelistRequestLayer;
