import React, { useEffect, useState } from "react";
import useApi from "../hook/useApi";
import { toast } from "react-toastify";
import Loader from "./Loader/Loader";
import { CMS_WEBSITE_TYPE, PAGE_TYPE, PLATFORM_TYPE } from "../utils/enum";

const HomePageData = () => {
  const { AsyncGetApiCall, AsyncPatchAPICall } = useApi();
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState({ title: "", content: {} });
  const [platformType, setPlatformType] = useState(PLATFORM_TYPE.ICO);
  const [errors, setErrors] = useState({});

  // 🔹 Fetch Page Data
  const getData = async () => {
    setLoading(true);
    const url = "/cmspage/get-page";
    const query = {
      pageType: PAGE_TYPE.HOME_PAGE_STATICS,
      webType:
        platformType === PLATFORM_TYPE.ICO
          ? CMS_WEBSITE_TYPE.ICO
          : CMS_WEBSITE_TYPE.TRAVEL,
    };

    const result = await AsyncGetApiCall(url, query);
    console.log("API result:", result);

    if (result.success) {
      setData({
        _id: result.data._id,
        title: result.data.title,
        content: result.data.content || {},
      });
    } else {
      toast.error(result.errors?.[0] || "Failed to fetch data");
    }
    setLoading(false);
  };

  useEffect(() => {
    getData();
  }, [platformType]);

  // 🔹 Handle content field change
  const handleContentChange = (key, value) => {
    setData((prev) => ({
      ...prev,
      content: {
        ...prev.content,
        [key]: value,
      },
    }));
  };

  // 🔹 Save Updated Content via new API
  const handleSave = async () => {
    // Validation
    const newErrors = {};
    Object.entries(data.content).forEach(([key, val]) => {
      if (!val || val.trim() === "") {
        newErrors[key] = `${key} is required`;
      }
    });
    setErrors(newErrors);

    if (Object.keys(newErrors).length > 0) {
      toast.error("Please fill in all required fields");
      return;
    }

    setLoading(true);

    const webType =
      platformType === PLATFORM_TYPE.ICO
        ? CMS_WEBSITE_TYPE.ICO
        : CMS_WEBSITE_TYPE.TRAVEL;

    // ✅ New API Call
    const result = await AsyncPatchAPICall(
      `/cmspage/update-home-statics?webType=${webType}`,
      {
        content: data.content,
      }
    );

    if (result.success) {
      setData(result.data);
      toast.success("Home Page Statics updated successfully");
    } else {
      toast.error(result.errors?.[0] || "Failed to update content");
    }

    setLoading(false);
  };

  // 🔹 Platform Change
  const handlePlatformChange = (e) => {
    setPlatformType(e.target.value);
  };

  return (
    <>
      {loading && <Loader />}

      <div className="card basic-data-table radius-12 overflow-hidden">
        <div className="card-body p-24">
          <h5 className="mb-3">{data.title}</h5>

          {data.content &&
            Object.entries(data.content).map(([key, value]) => (
              <div key={key} className="mb-3">
                <label className="form-label fw-bold">{key}</label>
                <input
                  type="text"
                  className={`form-control ${
                    errors[key] ? "is-invalid" : ""
                  }`}
                  value={value}
                  onChange={(e) => handleContentChange(key, e.target.value)}
                />
                {errors[key] && (
                  <div className="invalid-feedback">{errors[key]}</div>
                )}
              </div>
            ))}
        </div>

        <div className="card-footer p-24 bg-base border border-bottom-0 border-end-0 border-start-0">
          <div className="d-flex align-items-center justify-content-center gap-3">
            <button
              type="button"
              className="border border-danger-600 bg-hover-danger-200 text-danger-600 text-md px-50 py-11 radius-8"
              onClick={getData}
            >
              Cancel
            </button>
            <button
              type="button"
              className="btn btn-primary border border-primary-600 text-md px-28 py-12 radius-8"
              onClick={handleSave}
            >
              Save Changes
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default HomePageData;
