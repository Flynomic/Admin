import { Icon } from "@iconify/react";
import React, { useCallback, useEffect, useState } from "react";
import { toast } from "react-toastify";
import { debounce } from "lodash";
import { TbCoinRupee } from "react-icons/tb";
import { BiDollarCircle } from "react-icons/bi";
import useApi from "../../hook/useApi";
import Loader from "../Loader/Loader";
import Paggination from "../Paggination";
import { copyToClipboard, trimAddress } from "../../utils/helper";
import { IoCopyOutline } from "react-icons/io5";

const GiftCardTxLayer = () => {
  const [data, setData] = useState([]);
  const [pagination, setPagination] = useState({
    total: 0,
    totalPages: 1,
    currentPage: 1,
    limit: 20,
  });
  const [loading, setLoading] = useState(false);
  const [query, setQuery] = useState({
    pageNo: 1,
    limitVal: 30,
    search: "",
  });
  const { AsyncGetApiCall } = useApi();

  const fetchGiftCardTxs = async () => {
    setLoading(true);
    const result = await AsyncGetApiCall(`/giftcard/order/list`, query);

    if (result?.errors) {
      toast.error(result.errors[0]);
    } else if (result?.data) {
      setData(result.data || []);
      setPagination({
        ...(result.pagination || {}),
        total: result.pagination?.total || 0,
        totalPages: result.pagination?.totalPages || 1,
        currentPage: result.pagination?.currentPage || 1,
        limit: result.pagination?.limit || 10,
      });
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchGiftCardTxs();
    // eslint-disable-next-line
  }, [query]);

  const debouncedSearch = useCallback(
    debounce((value) => {
      setQuery((prev) => ({ ...prev, search: value, pageNo: 1 }));
    }, 500),
    []
  );

  const handleSearchChange = (e) => {
    debouncedSearch(e.target.value);
  };

  return (
    <>
      {loading && <Loader />}
      <div className="card h-100 p-0 radius-12">
        <div className="card-header border-bottom bg-base py-16 px-24 d-flex align-items-center flex-wrap gap-3 justify-content-between">
          <div className="d-flex align-items-center justify-content-between gap-3 w-100">
            <div className="d-flex align-items-center gap-3">
              <span className="text-md fw-medium text-secondary-light mb-0">
                Show
              </span>
              <select
                className="form-select form-select-sm w-auto ps-12 py-6 radius-12 h-40-px"
                value={query.limitVal}
                onChange={(e) => {
                  const value = parseInt(e.target.value, 10);
                  setQuery((prev) => ({
                    ...prev,
                    limitVal: value,
                  }));
                }}
              >
                <option value="10">Select Number</option>
                {Array.from({ length: 20 }, (_, i) => {
                  const value = (i + 1) * 5;
                  return (
                    <option key={value} value={value}>
                      {value}
                    </option>
                  );
                })}
              </select>

              <form className="navbar-search">
                <input
                  type="text"
                  className="bg-base h-40-px w-auto"
                  placeholder="Search by gift card"
                  onChange={handleSearchChange}
                  name="search"
                />
                <Icon icon="ion:search-outline" className="icon" />
              </form>
            </div>
          </div>
        </div>

        <div className="card-body p-24">
          <div className="table-responsive scroll-sm">
            <table className="table bordered-table sm-table mb-0">
              <thead>
                <tr>
                  <th>S.No</th>
                  <th>Creator</th>
                  <th>Amount</th>
                  <th>Currency</th>
                  <th>Gift Card Status</th>
                  <th>Quantity</th>
                  <th>Redeemed?</th>
                  <th>Gift Card Code</th>
                </tr>
              </thead>
              <tbody>
                {data && data.length > 0 ? (
                  data.map((value, index) => (
                    <tr key={value._id}>
                      <td>{(pagination.currentPage - 1) * pagination.limit + index + 1}</td>
                      <td>
                        {value?.creatorUserId
                          ? trimAddress(value?.creatorUserId, 4, 4)
                          : ""}
                        {value?.creatorUserId && (
                          <button
                            onClick={() => copyToClipboard(value?.creatorUserId)}
                            className="ms-3 p-0 border-0 bg-transparent "
                            style={{ lineHeight: 1 }}
                          >
                            <IoCopyOutline />
                          </button>
                        )}
                      </td>
                      <td>{value?.amount || ""}</td>
                      <td>
                        {value?.currency === "USD" ? (
                          <BiDollarCircle style={{ fontSize: "1.5rem" }} />
                        ) : (
                          <TbCoinRupee style={{ fontSize: "1.5rem" }} />
                        )}
                      </td>
                      <td>
                        <span
                          className={`${value.isActive
                            ? "bg-success-focus text-success-600"
                            : "bg-danger-focus text-danger-600"
                            } border px-24 py-4 radius-4 fw-medium text-sm`}
                        >
                          {value?.isActive ? "Active" : "Inactive"}
                        </span>
                      </td>
                      <td>{value?.quantity || ""}</td>

                      <td>
                        <span
                          className={`${value.isRedeemed
                            ? "bg-success-focus text-success-600"
                            : "bg-danger-focus text-danger-600"
                            } border px-24 py-4 radius-4 fw-medium text-sm`}
                        >
                          {value?.isRedeemed
                            ? "Redeemed"
                            : "Not Redeemed"}
                        </span>
                      </td>
                      <td>
                        {value?.giftCardUniqueCode}
                        {value?.giftCardUniqueCode && (
                          <button
                            onClick={() => copyToClipboard(value?.giftCardUniqueCode)}
                            className="ms-3 p-0 border-0 bg-transparent "
                            style={{ lineHeight: 1 }}
                          >
                            <IoCopyOutline />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="9" className="text-center">
                      No Gift Cards found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <Paggination
            total={pagination.total}
            totalPages={pagination.totalPages}
            currentPage={pagination.currentPage}
            setPageNo={(page) => setQuery((prev) => ({ ...prev, pageNo: page }))}
            startFrom={
              (pagination.currentPage - 1) * pagination.limit + 1
            }
            endTo={
              (pagination.currentPage - 1) * pagination.limit + (data?.length || 0)
            }
          />
        </div>
      </div>
    </>
  );
};

export default GiftCardTxLayer;
