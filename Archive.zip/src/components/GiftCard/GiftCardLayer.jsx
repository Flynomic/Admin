import { Icon } from "@iconify/react";
import React, { useCallback, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { debounce } from "lodash";
import { TbCoinRupee } from "react-icons/tb";
import { BiDollarCircle } from "react-icons/bi";
import { CURRENCY } from "../../utils/enum";
import AddGiftCardModel from "../model/AddGiftCardModel";
import useApi from "../../hook/useApi";
import Loader from "../Loader/Loader";
import Paggination from "../Paggination";

const GiftCardLayer = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [limitVal, setLimitVal] = useState("10");
  const [pageNo, setPageNo] = useState(1);
  const [query, setQuery] = useState({
    pageNo: 1,
    limitVal: 30,
    search: "",
  });
  const [showModal, setShowModal] = useState(false);
  const { AsyncGetApiCall, AsyncDeleteApiCall } = useApi();

  const fetchGiftCards = async () => {
    setLoading(true);

    const result = await AsyncGetApiCall(`/giftcard/list/`, query);

    if (result?.errors) {
      toast.error(result.errors[0]);
    } else if (result?.data) {
      setData(result);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchGiftCards();
  }, [query, showModal]);

  const debouncedSearch = useCallback(
    debounce((value) => {
      setQuery((prev) => ({ ...prev, search: value, pageNo: 1 }));
    }, 500),
    []
  );

  const handleSearchChange = (e) => {
    debouncedSearch(e.target.value);
  };

  const deleteGiftCard = async (id) => {
    setLoading(true);
    const result = await AsyncDeleteApiCall(`/giftcard/delete/${id}`);

    if (result.errors) {
      toast.error(result.errors[0]);
    } else if (result.success) {
      toast.success(`Gift card deleted successfully`);
      fetchGiftCards();
    }
    setLoading(false);
  };

  return (
    <>
      {loading && <Loader />}
      <div className="card h-100 p-0 radius-12">
        <div className="card-header border-bottom bg-base py-16 px-24 d-flex align-items-center flex-wrap gap-3 justify-content-between">
          <div className="d-flex align-items-center justify-content-between gap-3 w-100">
            <div className="d-flex align-items-center gap-3">
              <span className="text-md fw-medium text-secondary-light mb-0">
                Show
              </span>
              <select
                className="form-select form-select-sm w-auto ps-12 py-6 radius-12 h-40-px"
                defaultValue="Select Number"
                onChange={(e) => {
                  const value = parseInt(e.target.value, 10);
                  setQuery((prev) => ({
                    ...prev,
                    limitVal: value,
                  }));
                }}
              >
                <option value="5">Select Number</option>
                {Array.from({ length: 20 }, (_, i) => {
                  const value = (i + 1) * 5;
                  return (
                    <option key={value} value={value}>
                      {value}
                    </option>
                  );
                })}
              </select>

              <form className="navbar-search">
                <input
                  type="text"
                  className="bg-base h-40-px w-auto"
                  placeholder="Search"
                  // value={search}
                  onChange={handleSearchChange}
                  name="search"
                />
                <Icon icon="ion:search-outline" className="icon" />
              </form>
            </div>
            <div>
              <button
                type="button"
                className="btn btn-primary-600 radius-8 px-17 py-9 d-flex align-items-center gap-2"
                onClick={() => {
                  setShowModal(true);
                }}
                disabled={loading}
                aria-label="Add new Gift Card"
              >
                <Icon
                  icon="mdi:gift-outline"
                  className="menu-icon"
                  style={{ fontSize: "20px", marginLeft: "4px" }}
                />
                Create Gift Card
              </button>
            </div>
          </div>
        </div>

        <div className="card-body p-24">
          <div className="table-responsive scroll-sm">
            <table className="table bordered-table sm-table mb-0">
              <thead>
                <tr>
                  <th>S.No</th>
                  <th>Amount</th>
                  <th>Currency</th>
                  <th>Status</th>
                  <th style={{ textAlign: "center" }}>Action</th>
                </tr>
              </thead>
              <tbody>
                {data?.data && data?.data.length > 0 ? (
                  data?.data.map((value, index) => (
                    <tr key={value._id}>
                      <td>{(pageNo - 1) * limitVal + index + 1}</td>
                      <td>{value?.amount || ""}</td>
                      <td>
                        {(value?.currency === CURRENCY.DOLLAR ? (
                          <BiDollarCircle style={{ fontSize: "1.5rem" }} />
                        ) : (
                          <TbCoinRupee style={{ fontSize: "1.5rem" }} />
                        )) || ""}
                      </td>
                      <td>
                        {/* {changeStatus && editId === value._id ? (
                           <div
                             className={`icon-field d-flex align-items-center gap-10 justify-content-center`}
                             style={{ width: "25%" }}
                           >
                             <select
                               className={`form-select text-sm ${
                                 updatedValues[value._id]?.isActive ===
                                 activeStatus.ACTIVE
                                   ? "bg-success-focus text-success-600"
                                   : updatedValues[value._id]?.isActive ===
                                     activeStatus.INACTIVE
                                   ? "bg-danger-focus text-danger-600"
                                   : ""
                               } ${
                                 errors[value._id]?.isActive ? "is-invalid" : ""
                               }`}
                               name="isActive"
                               value={
                                 updatedValues[value._id]?.isActive ??
                                 value.isActive // use updated if exists, else original
                               }
                               onChange={(e) => handleValues(e, value._id)}
                             >
                               <option value="">Select Status</option>
                               <option value={activeStatus.ACTIVE}>
                                 Active
                               </option>
                               <option value={activeStatus.INACTIVE}>
                                 Inactive
                               </option>
                             </select>
 
                             {errors[value._id]?.isActive && (
                               <div className="invalid-feedback ">
                                 {errors[value._id]?.isActive}
                               </div>
                             )}
                           </div>
                         ) : ( */}
                        <span
                          className={`${value.isActive
                            ? "bg-success-focus text-success-600"
                            : "bg-danger-focus text-danger-600"
                            } border px-24 py-4 radius-4 fw-medium text-sm`}
                        >
                          {value.isActive ? "Active" : "Inactive"}
                        </span>
                        {/* )} */}
                      </td>
                      <td className="text-center">
                        <div className="d-flex align-items-center gap-10 justify-content-center">
                          <button
                            type="button"
                            className="bg-success-focus text-success-600 bg-hover-success-200 fw-medium w-40-px h-40-px d-flex justify-content-center align-items-center rounded-circle"
                            onClick={() => alert("this will be added later.")}
                          >
                            <Icon icon="lucide:edit" className="menu-icon" />
                          </button>
                          {/* {changeStatus && editId === value?._id && (
                             <button
                               type="button"
                               className="bg-info-focus bg-hover-info-200 text-info-600 fw-medium w-40-px h-40-px d-flex justify-content-center align-items-center rounded-circle"
                               onClick={() => handleUpdate(value?._id)}
                             >
                               <Icon
                                 icon="mdi:check"
                                 className="menu-icon"
                                 fontSize={20}
                               />
                             </button>
                           )} */}
                          <button
                            type="button"
                            className="remove-item-btn bg-danger-focus bg-hover-danger-200 text-danger-600 fw-medium w-40-px h-40-px d-flex justify-content-center align-items-center rounded-circle"
                            onClick={() => deleteGiftCard(value._id)}
                          >
                            <Icon
                              icon="fluent:delete-24-regular"
                              className="menu-icon"
                            />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="5" className="text-center">
                      No Gift Cards found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <Paggination
            total={data?.total || 0}
            totalPages={data?.totalPages || 0}
            currentPage={data?.currentPage || 0}
            setPageNo={setPageNo}
            startFrom={(data?.currentPage - 1) * query.limitVal + 1}
            endTo={
              (data?.currentPage - 1) * query.limitVal + data?.data?.length
            }
          />

          <AddGiftCardModel
            show={showModal}
            handleClose={() => setShowModal(false)}
            loading={loading}
          />
        </div>
      </div>
    </>
  );
};

export default GiftCardLayer;
