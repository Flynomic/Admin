import React, { useEffect, useState } from "react";
import { Modal, Button, Form } from "react-bootstrap";
import Loader from "../Loader/Loader";
import useApi from "../../hook/useApi";
import { toast } from "react-toastify";
import dayjs from "dayjs";
import { ValidateInputs } from "../../utils/helper";

const defaultCoupon = {
     couponCode: "",
     amount: "",
     startDate: "",
     endDate: "",
     description: "",
     couponType: "",
};

const COUPON_TYPES = ["HOTEL", "FLIGHT"];

const CouponModal = ({ show, handleClose, mode = "create", data = {} }) => {
     const isView = mode === "view";
     const isUpdate = mode === "update";
     const isCreate = mode === "create";

     const [formData, setFormData] = useState(defaultCoupon);
     const [errors, setErrors] = useState({});
     const [loading, setLoading] = useState(false);
     const { AsyncPostApiCall, AsyncPatchAPICall } = useApi();

     const validate = () => {
          const newErrors = {};
          const fields = [
               { key: "couponCode", value: formData.couponCode },
               { key: "amount", value: formData.amount },
               { key: "startDate", value: formData.startDate },
               { key: "endDate", value: formData.endDate },
               { key: "couponType", value: formData.couponType },
               { key: "description", value: formData.description },
          ];

          fields.forEach(({ key, value }) => {
               const errors = ValidateInputs(key, value, {}, formData);
               if (errors[key]) {
                    newErrors[key] = errors[key];
               }
          });

          setErrors(newErrors);
          return Object.keys(newErrors).length === 0;
     };

     useEffect(() => {
          if (show && (isUpdate || isView)) {
               setFormData({
                    ...defaultCoupon,
                    ...data,
                    startDate: dayjs(data.startDate).format("YYYY-MM-DD"),
                    endDate: dayjs(data.endDate).format("YYYY-MM-DD"),
                    couponType: data.couponType || "",
                    amount: data.amount || "",
               });
          } else if (isCreate) {
               setFormData(defaultCoupon);
          }
     }, [show, data, mode]);

     const handleChange = (e) => {
          const { name, value } = e.target;

          setFormData((prev) => {
               const newFormData = { ...prev };
               let newValue = value;

               // Handle different field types
               if (name === "amount") {
                    newValue = value === "" ? "" : Number(Math.max(1, Math.min(2000, Number(value)).toFixed(2) || 0));
               } else if (name === "couponCode") {
                    newValue = value.toUpperCase();
               } else if (name === "startDate") {
                    if (value) {
                         const [year, month, day] = value.split("-").map(Number);
                         const isCompleteDate = year && month && day && year.toString().length === 4;
                         if (isCompleteDate) {
                              const isValidDate =
                                   month <= 12 &&
                                   day <= 31 &&
                                   !isNaN(new Date(year, month - 1, day).getTime());
                              if (isValidDate) {
                                   const today = new Date();
                                   const maxDate = new Date(today);
                                   maxDate.setFullYear(today.getFullYear() + 5);
                                   const inputDate = new Date(year, month - 1, day);
                                   if (inputDate > maxDate) {
                                        // newValue = "";
                                        setErrors((prevErrors) => ({
                                             ...prevErrors,
                                             [name]: "Start date cannot be more than 5 years from today."
                                        }));
                                   } else {
                                        newValue = `${year}-${month.toString().padStart(2, "0")}-${day.toString().padStart(2, "0")}`;
                                   }
                              } else {
                                   newValue = "";
                                   setErrors((prevErrors) => ({
                                        ...prevErrors,
                                        [name]: "Invalid date format. Please use YYYY-MM-DD."
                                   }));
                              }
                         } else {
                              newValue = value; // Allow partial date input without validation
                         }
                    }
               } else if (name === "endDate") {
                    if (value) {
                         const [year, month, day] = value.split("-").map(Number);
                         const isCompleteDate = year && month && day && year.toString().length === 4;
                         if (isCompleteDate) {
                              const isValidDate =
                                   month <= 12 &&
                                   day <= 31 &&
                                   !isNaN(new Date(year, month - 1, day).getTime());
                              if (isValidDate) {
                                   newValue = `${year}-${month.toString().padStart(2, "0")}-${day.toString().padStart(2, "0")}`;
                              } else {
                                   newValue = "";
                                   setErrors((prevErrors) => ({
                                        ...prevErrors,
                                        [name]: "Invalid date format. Please use YYYY-MM-DD."
                                   }));
                              }
                         } else {
                              newValue = value; // Allow partial date input without validation
                         }
                    }
               }

               newFormData[name] = newValue;

               // If startDate changes, validate and possibly clear endDate
               if (name === "startDate" && value && prev.endDate) {
                    const startDate = new Date(value);
                    const endDate = new Date(prev.endDate);
                    const minEndDate = new Date(startDate);
                    minEndDate.setDate(startDate.getDate() + 1);
                    if (endDate < minEndDate) {
                         newFormData.endDate = "";
                    }
               }

               // Perform validation with the new value
               setErrors((prevErrors) => {
                    let newErrors = { ...prevErrors };
                    if (name === "amount") {
                         if (!newValue || isNaN(Number(newValue))) {
                              newErrors.amount = "Amount must not be empty and should be between 1 and 2000";
                         } else if (Number(newValue) < 1 || Number(newValue) > 2000) {
                              newErrors.amount = "Amount must be between 1 and 2000";
                         } else {
                              newErrors.amount = "";
                         }
                    } else {
                         const validationErrors = ValidateInputs(name, newValue, prevErrors, newFormData);
                         newErrors[name] = validationErrors[name] || "";
                    }
                    return newErrors;
               });

               return newFormData;
          });
     };

     const handleSubmit = async () => {
          if (!validate()) {
               return;
          }

          setLoading(true);

          const payload = {
               ...formData,
               couponCode: formData.couponCode.toUpperCase(),
               amount: Number(formData.amount),
               couponType: formData.couponType,
          };

          const endpoint = isCreate ? "/coupon/create" : `/coupon/update/${data._id}`;
          const apiCall = isCreate ? AsyncPostApiCall : AsyncPatchAPICall;

          const result = await apiCall(endpoint, payload);

          if (result.errors) {
               toast.error(result.errors[0]);
          } else if (result.success) {
               toast.success(`Coupon ${isCreate ? "created" : "updated"} successfully`);
               handleClose(true);
          }

          setLoading(false);
          setErrors({});
     };

     const renderField = (label, name, type = "text", as = "input") => {
          const today = new Date();
          const minDate = today.toISOString().split("T")[0];
          let minDateEnd = null;

          if (formData.startDate) {
               const startDate = new Date(formData.startDate);
               const nextDay = new Date(startDate);
               nextDay.setDate(startDate.getDate() + 1);
               minDateEnd = nextDay.toISOString().split("T")[0];
          } else {
               const tomorrow = new Date(today);
               tomorrow.setDate(today.getDate() + 1);
               minDateEnd = tomorrow.toISOString().split("T")[0];
          }

          const maxDate = new Date(today);
          maxDate.setFullYear(today.getFullYear() + 5);
          const maxDateFormatted = maxDate.toISOString().split("T")[0];

          return (
               <Form.Group className="mb-3">
                    <Form.Label>{label}</Form.Label>
                    <Form.Control
                         type={type}
                         as={as}
                         name={name}
                         value={formData[name] || ""}
                         onChange={handleChange}
                         readOnly={isView}
                         className={errors[name] ? "is-invalid" : ""}
                         placeholder={`Enter ${label.toLowerCase()}`}
                         min={type === "date" ? (name === "endDate" ? minDateEnd : minDate) : undefined}
                         max={type === "date" ? maxDateFormatted : undefined}
                         maxLength={name === "description" ? 100 : name === "couponCode" ? 12 : undefined}
                    />
                    {errors[name] && <div className="invalid-feedback">{errors[name]}</div>}
               </Form.Group>
          );
     };

     const renderSelectField = (label, name, options) => (
          <Form.Group className="mb-3">
               <Form.Label>{label}</Form.Label>
               <Form.Select
                    name={name}
                    value={formData[name]}
                    onChange={handleChange}
                    disabled={isView}
                    className={errors[name] ? "is-invalid" : ""}
               >
                    <option value="">Select {label.toLowerCase()}</option>
                    {options.map((option) => (
                         <option key={option} value={option}>
                              {option}
                         </option>
                    ))}
               </Form.Select>
               {errors[name] && <div className="invalid-feedback">{errors[name]}</div>}
          </Form.Group>
     );

     return (
          <>
               {loading && <Loader />}
               <Modal
                    show={show}
                    onHide={() => {
                         handleClose();
                         setFormData(defaultCoupon);
                         setErrors({});
                    }}
               >
                    <Modal.Header closeButton>
                         <Modal.Title>
                              {isCreate && "Create Coupon"}
                              {isUpdate && "Update Coupon"}
                              {isView && "View Coupon"}
                         </Modal.Title>
                    </Modal.Header>

                    <Modal.Body>
                         <Form>
                              {renderField("Coupon Code", "couponCode")}
                              {renderSelectField("Coupon Type", "couponType", COUPON_TYPES)}
                              <Form.Group className="mb-3">
                                   <Form.Label>Amount</Form.Label>
                                   <Form.Control
                                        type="number"
                                        name="amount"
                                        value={formData.amount}
                                        onChange={handleChange}
                                        readOnly={isView}
                                        min="1"
                                        max="2000"
                                        step="1"
                                        onKeyDown={(e) => ["e", "E", "+", "-"].includes(e.key) && e.preventDefault()}
                                        className={errors.amount ? "is-invalid" : ""}
                                        placeholder="Enter amount"
                                   />
                                   {errors.amount && <div className="invalid-feedback">{errors.amount}</div>}
                              </Form.Group>

                              {renderField("Start Date", "startDate", "date")}
                              {renderField("End Date", "endDate", "date")}
                              {renderField("Description", "description", "text", "textarea")}
                         </Form>
                    </Modal.Body>

                    <Modal.Footer>
                         <Button
                              variant="secondary"
                              onClick={() => {
                                   handleClose();
                                   setFormData(defaultCoupon);
                                   setErrors({});
                              }}
                         >
                              Close
                         </Button>
                         {!isView && (
                              <Button variant="primary" onClick={handleSubmit} disabled={loading}>
                                   {loading ? "Saving..." : isCreate ? "Create" : "Update"}
                              </Button>
                         )}
                    </Modal.Footer>
               </Modal>
          </>
     );
};

export default CouponModal;