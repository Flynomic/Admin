// src/components/AddBlogModal.js
import React, { useRef, useState } from "react";
import { Modal, Button, Form } from "react-bootstrap";
import axios from "axios"; // assuming axios for API calls
import ReactQuill from "react-quill-new";
import hljs from "highlight.js";
import { stripHtml, ValidateInputs } from "../../utils/helper";
import Loader from "../Loader/Loader";
import { blogCategories } from "../../utils/enum";
import { error } from "jquery";
import useApi from "../../hook/useApi";
import { toast } from "react-toastify";

const AddBlogModal = ({ show, handleClose }) => {
  const [data, setData] = useState({
    title: "",
    content: "",
    category: "",
  });
  const [loading, setLoading] = useState(false);
  const quillRef = useRef(null);
  const [isHighlightReady, setIsHighlightReady] = useState(false);
  const [errors, setErrors] = useState({});
  const { AsyncPostApiCall } = useApi();

  const modules = isHighlightReady
    ? {
        syntax: {
          highlight: (text) => hljs?.highlightAuto(text).value, // Enable highlight.js in Quill
        },
        toolbar: {
          container: "#toolbar-container", // Custom toolbar container
        },
      }
    : {
        toolbar: {
          container: "#toolbar-container", // Custom toolbar container
        },
      };

  const formats = [
    "font",
    "size",
    "bold",
    "italic",
    "underline",
    "strike",
    "color",
    "background",
    "script",
    "header",
    "blockquote",
    "code-block",
    "list",
    "indent",
    "direction",
    "align",
    "link",
    "image",
    "video",
    "formula",
  ];

  const handleValues = (e) => {
    const { name, value } = e.target;

    setData((prev) => ({
      ...prev,
      [name]: value,
    }));

    // Update error for category immediately
    if (name === "category" && value === "") {
      setErrors((prev) => ({
        ...prev,
        category: "Category is required",
      }));
    } else {
      // clear error if selected valid category
      setErrors((prev) => ({
        ...prev,
        [name]: "",
      }));
    }

    const updatedInputs = ValidateInputs(name, value, errors);
    setErrors((prev) => ({
      ...prev,
      ...updatedInputs,
    }));
  };

  const validateBlogForm = () => {
    const newErrors = {};

    const plainTextContent = stripHtml(data?.content).trim();

    // Title: required
    if (!data?.title.trim()) {
      newErrors.title = "Title is required";
    }

    // Content: required
    if (!plainTextContent) {
      newErrors.content = "Content is required";
    }

    // Category: required
    if (!data?.category.trim()) {
      newErrors.category = "Category is required";
    }

    // No need to validate isActive (user can only pick from dropdown)

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const addBlog = async (e) => {
    e.preventDefault();

    if (!validateBlogForm()) {
      return;
    }
    setLoading(true);
    const cleanedContent = stripHtml(data?.content).trim();

    const result = await AsyncPostApiCall(`/blogs/create`, {
      ...data,
      content: cleanedContent,
    });

    if (result.errors) {
      toast.error(result.errors[0]);
    } else if (result.success && result.blog) {
      toast.success("Blog Data Updated Successfully.");
      setData({
        title: "",
        content: "",
        category: "",
      });
      await handleClose();
    }
    setLoading(false);
  };

  return (
    <>
      {loading && <Loader />}
      <Modal
        show={show}
        onHide={() => {
          handleClose();
          setData({
            title: "",
            content: "",
            category: "",
          });
          setErrors({
            title: "",
            content: "",
            category: "",
          });
        }}
        size="xl"
        scrollable
      >
        <Modal.Header closeButton>
          <Modal.Title>Create New Blog</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={addBlog}>
            {/* Title */}
            <Form.Group className="mb-3">
              <Form.Label>Title</Form.Label>
              <Form.Control
                type="text"
                name="title"
                placeholder="Enter blog title"
                value={data?.title}
                onChange={handleValues}
                // required
                className={`${errors?.title ? "is-invalid" : ""}`}
              />
              {errors?.title && (
                <div className="invalid-feedback">{errors?.title}</div>
              )}
            </Form.Group>

            {/* Category */}
            <Form.Group className="mb-3">
              <Form.Label>Category</Form.Label>
              <Form.Select
                name="category"
                value={data.category}
                onChange={handleValues}
                className={`${errors?.category ? "is-invalid" : ""}`}
                // required
              >
                <option value="">Select category</option>
                {Object.entries(blogCategories).map(([key, value]) => (
                  <option key={key} value={value}>
                    {value.charAt(0).toUpperCase() + value.slice(1)}
                  </option>
                ))}
              </Form.Select>
              {errors?.category && (
                <div className="invalid-feedback">{errors?.category}</div>
              )}
            </Form.Group>

            {/* Content */}
            <Form.Group className="mb-3">
              <Form.Label>Content</Form.Label>
              <div id="toolbar-container">
                <span className="ql-formats">
                  <select className="ql-font"></select>
                  <select className="ql-size"></select>
                </span>
                <span className="ql-formats">
                  <button className="ql-bold"></button>
                  {/* <button className="ql-italic"></button>
                  <button className="ql-underline"></button>
                  <button className="ql-strike"></button> */}
                </span>
                <span className="ql-formats">
                  <select className="ql-color"></select>
                  <select className="ql-background"></select>
                </span>
                <span className="ql-formats">
                  <button className="ql-script" value="sub"></button>
                  <button className="ql-script" value="super"></button>
                </span>
                <span className="ql-formats">
                  <button className="ql-header" value="1"></button>
                  <button className="ql-header" value="2"></button>
                  <button className="ql-blockquote"></button>
                  <button className="ql-code-block"></button>
                </span>
                <span className="ql-formats">
                  {/* <button className="ql-list" value="ordered"></button>
                  <button className="ql-list" value="bullet"></button> */}
                  <button className="ql-indent" value="-1"></button>
                  <button className="ql-indent" value="+1"></button>
                </span>
                <span className="ql-formats">
                  <button className="ql-direction" value="rtl"></button>
                  <select className="ql-align"></select>
                </span>
                <span className="ql-formats">
                  <button className="ql-link"></button>
                  <button className="ql-image"></button>
                  <button className="ql-video"></button>
                  <button className="ql-formula"></button>
                </span>
                <span className="ql-formats">
                  <button className="ql-clean"></button>
                </span>
              </div>

              {/* Quill Editor */}
              <ReactQuill
                ref={quillRef}
                theme="snow"
                value={data?.content}
                onChange={(content) =>
                  handleValues({
                    target: { name: "content", value: content },
                  })
                }
                modules={modules}
                formats={formats}
                placeholder="Start Your Blog here..."
                name="content"
                className={`${errors?.content ? "is-invalid" : ""}`}
              />
              {errors.content && (
                <div className="invalid-feedback">{errors.content}</div>
              )}
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button
            variant="danger"
            onClick={() => {
              handleClose();
              setData({
                title: "",
                content: "",
                category: "",
              });
            }}
            disabled={loading}
          >
            Cancel
          </Button>
          <Button variant="primary" onClick={addBlog} disabled={loading}>
            {loading ? "Saving..." : "Save Blog"}
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default AddBlogModal;
