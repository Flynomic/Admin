// src/components/NotificationModal.js
import React, { useEffect, useState } from "react";
import { Modal, Button, Form } from "react-bootstrap";
import Loader from "../Loader/Loader";
import useApi from "../../hook/useApi";
import { toast } from "react-toastify";

const defaultNotification = {
     title: "",
     body: "",
};

const NotificationModal = ({ show, handleClose, mode = "create", data = {} }) => {
     const isView = mode === "view";
     const isCreate = mode === "create";

     const [formData, setFormData] = useState(defaultNotification);
     const [errors, setErrors] = useState({});
     const [loading, setLoading] = useState(false);
     const { AsyncPostApiCall, AsyncPatchAPICall } = useApi();

     useEffect(() => {
          if (isCreate) {
               setFormData(defaultNotification);
          }
     }, [show, data, mode]);

     const validate = () => {
          const newErrors = {};
          if (!formData.title.trim()) {
               newErrors.title = "Title is required";
          }
          if (!formData.body.trim()) {
               newErrors.body = "Body is required";
          }
          setErrors(newErrors);
          return Object.keys(newErrors).length === 0;
     };

     const handleChange = (e) => {
          const { name, value } = e.target;
          setFormData((prev) => ({
               ...prev,
               [name]: value,
          }));
          setErrors((prev) => ({ ...prev, [name]: "" }));
     };

     const handleSubmit = async () => {
          if (!validate()) return;
          setLoading(true);

          let endpoint = "";
          let apiCall = null;

          if (isCreate) {
               endpoint = "/notifications/admin/create-all";
               apiCall = AsyncPostApiCall;
          }

          const result = await apiCall(endpoint, formData);

          if (result?.errors) {
               toast.error(result.errors[0]);
          } else if (result?.success) {
               toast.success(
                    `${result?.message || "Notifications successfully created for all users."}`
               );
               handleClose(true); // trigger refetch
          }

          setLoading(false);
     };


     return (
          <>
               {loading && <Loader />}
               <Modal
                    show={show}
                    onHide={() => {
                         handleClose();
                         setFormData(defaultNotification);
                         setErrors({});
                    }}
               >
                    <Modal.Header closeButton>
                         <Modal.Title>
                              {isCreate && "Notification for all users"}
                              {isView && "View Notification"}
                         </Modal.Title>
                    </Modal.Header>

                    <Modal.Body>
                         <Form>
                              {/* Title */}
                              <Form.Group className="mb-3">
                                   <Form.Label>Title</Form.Label>
                                   <Form.Control
                                        type="text"
                                        name="title"
                                        value={formData.title}
                                        onChange={handleChange}
                                        readOnly={isView}
                                        className={errors.title ? "is-invalid" : ""}
                                        placeholder="Enter Title"
                                   />
                                   {errors.title && (
                                        <div className="invalid-feedback">{errors.title}</div>
                                   )}
                              </Form.Group>

                              {/* Body */}
                              <Form.Group className="mb-3">
                                   <Form.Label>Body</Form.Label>
                                   <Form.Control
                                        as="textarea"
                                        name="body"
                                        rows={4}
                                        value={formData.body}
                                        onChange={handleChange}
                                        readOnly={isView}
                                        className={errors.body ? "is-invalid" : ""}
                                        placeholder="Enter Text"
                                   />
                                   {errors.body && (
                                        <div className="invalid-feedback">{errors.body}</div>
                                   )}
                              </Form.Group>
                         </Form>
                    </Modal.Body>

                    <Modal.Footer>
                         <Button
                              variant="secondary"
                              onClick={() => {
                                   handleClose();
                                   setFormData(defaultNotification);
                              }}
                         >
                              Close
                         </Button>
                         {!isView && (
                              <Button variant="primary" onClick={handleSubmit} disabled={loading}>
                                   {loading ? "Saving..." : "Create"}
                              </Button>
                         )}
                    </Modal.Footer>
               </Modal>
          </>
     );
};

export default NotificationModal;
