// src/components/AddEditTaskModal.js
import { useState, useEffect } from "react";
import { Modal, Button, Form } from "react-bootstrap";
import { CMS_WEBSITE_TYPE } from "../../utils/enum";
import { toast } from "react-toastify";
import useApi from "../../hook/useApi";
import { ValidateInputs } from "../../utils/helper";

const initialData = {
  question: "",
  answer: "",
  webType: "",
};

const AddFaqModal = ({ show, handleClose, handleSave, task, faqs }) => {
  const isEdit = Boolean(task);
  const [data, setData] = useState(initialData);
  const [errors, setErrors] = useState({});

  const getFaq = () => {
    if (isEdit && task) {
      const currentFaq = faqs.find(
        (faq) => faq._id === task.id || faq._id === task._id
      );
      if (currentFaq) {
        const { question, answer, webType } = currentFaq;
        setData({ question, answer, webType });
      }
    } else {
      setData(initialData);
    }
  };

  useEffect(() => {
    getFaq();
  }, [isEdit, task, faqs, show]);

  useEffect(() => {
    if (!show) setData(initialData);
    if (!show) setErrors({});
  }, [handleClose, show]);

  // Validation function for FAQ fields
  const validateFaq = () => {
    let newErrors = {};
    // Question validation
    if (!data.question.trim()) {
      newErrors.question = "Question is required";
    } else if (data.question.trim().length > 100) {
      newErrors.question = "Question cannot exceed 100 characters";
    }
    // Answer validation
    if (!data.answer.trim()) {
      newErrors.answer = "Answer is required";
    } else if (data.answer.trim().length > 300) {
      newErrors.answer = "Answer cannot exceed 300 characters";
    }
    // webType validation
    if (!data.webType) {
      newErrors.webType = "Platform type is required";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const onSave = () => {
    if (!validateFaq()) {
      return;
    }
    const taskData = {
      id: isEdit ? task.id : null,
      question: data.question,
      answer: data.answer,
      webType: data.webType,
    };

    handleSave(taskData, isEdit);
    setData(initialData);
    setErrors({});
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setData((prev) => ({ ...prev, [name]: value }));
    // Live validation on change
    setErrors((prevErrors) => ValidateInputs(name, value, prevErrors));
  };

  return (
    <Modal show={show} onHide={handleClose}>
      <Modal.Header closeButton>
        <Modal.Title>{isEdit ? "Edit Faq" : "Add New Faq"}</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form>
          {/* Question */}
          <Form.Group className="mb-3" controlId="taskQuestion">
            <Form.Label>Question</Form.Label>
            <Form.Control
              type="text"
              name="question"
              placeholder="Enter Question"
              value={data.question}
              onChange={handleChange}
              isInvalid={!!errors.question}
              required
            />
            {errors.question && (
              <Form.Control.Feedback type="invalid">
                {errors.question}
              </Form.Control.Feedback>
            )}
          </Form.Group>

          {/* Platform Type Dropdown */}
          <Form.Group className="mb-3" controlId="taskTag">
            <Form.Label>Platform Type</Form.Label>
            <Form.Select
              name="webType"
              value={data.webType}
              onChange={handleChange}
              isInvalid={!!errors.webType}
              required
            >
              <option value="">Select Platform Type</option>
              {Object.entries(CMS_WEBSITE_TYPE).map(([key, value]) => (
                <option key={key} value={value}>
                  {value
                    .replace(/_/g, " ")
                    .replace(/\b\w/g, (l) => l.toUpperCase())}
                </option>
              ))}
            </Form.Select>
            {errors.webType && (
              <Form.Control.Feedback type="invalid">
                {errors.webType}
              </Form.Control.Feedback>
            )}
          </Form.Group>

          {/* Answer */}
          <Form.Group className="mb-3" controlId="taskDescription">
            <Form.Label>Answer</Form.Label>
            <Form.Control
              as="textarea"
              name="answer"
              rows={3}
              placeholder="Enter Answer"
              value={data.answer}
              onChange={handleChange}
              isInvalid={!!errors.answer}
              required
            />
            {errors.answer && (
              <Form.Control.Feedback type="invalid">
                {errors.answer}
              </Form.Control.Feedback>
            )}
          </Form.Group>
        </Form>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="danger" onClick={handleClose}>
          Cancel
        </Button>
        <Button variant="primary" onClick={onSave}>
          Save
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default AddFaqModal;
