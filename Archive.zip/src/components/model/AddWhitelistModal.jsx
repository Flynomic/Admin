import React, { useState } from "react";
import { Modal, Button, Form } from "react-bootstrap";
import { ValidateInputs } from "../../utils/helper";

const initialData = {
  email: "",
  walletAddress: "",
};

const AddWhitelistModal = ({ show, handleClose, handleSave }) => {
  const [data, setData] = useState(initialData);
  const [errors, setErrors] = useState({});

  const validate = () => {
    const newErrors = {};
    const fields = [
      { key: "email", value: data.email },
      { key: "walletAddress", value: data.walletAddress },
    ];

    fields.forEach(({ key, value }) => {
      const errors = ValidateInputs(key, value, {}, data);
      if (errors[key]) {
        newErrors[key] = errors[key];
      }
    });

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const onSave = () => {
    if (!validate()) {
      return;
    }

    handleSave(data);
    setData(initialData);
    setErrors({})
  };

  const handleChange = async (e) => {
    const { name, value } = e.target
    setData((prev) => ({
      ...prev,
      [name]: value,
    }));

    const updatedInputs = ValidateInputs(name, value, errors);
    setErrors(updatedInputs);
  };

  return (
    <Modal show={show} onHide={() => {
      handleClose()
      setErrors({})
      setData(initialData);
    }}>
      <Modal.Header closeButton>
        <Modal.Title>{"Add  Whitelist Request"}</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form>
          {/* Email */}
          <Form.Group className="mb-3" controlId="taskQuestion">
            <Form.Label>Email</Form.Label>
            <Form.Control
              type="email"
              name="email"
              placeholder="Enter Your Email"
              value={data.email}
              onChange={handleChange}
              className={`${errors.email ? "is-invalid" : ""}`}
              required
            />
            {errors.email && (
              <div className="invalid-feedback">{errors.email}</div>
            )}
          </Form.Group>

          {/* Wallet Address */}
          <Form.Group className="mb-3" controlId="taskQuestion">
            <Form.Label>Wallet Address</Form.Label>
            <Form.Control
              type="text"
              name="walletAddress"
              placeholder="Enter Your Wallet Address"
              value={data.walletAddress}
              className={`${errors.walletAddress ? "is-invalid" : ""}`}
              onChange={handleChange}
              required
            />
            {errors.walletAddress && (
              <div className="invalid-feedback">{errors.walletAddress}</div>
            )}
          </Form.Group>
        </Form>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="danger" onClick={() => {
          handleClose()
          setErrors({})
          setData(initialData);
        }}>
          Cancel
        </Button>
        <Button variant="primary" onClick={onSave}>
          Save Changes
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default AddWhitelistModal;
