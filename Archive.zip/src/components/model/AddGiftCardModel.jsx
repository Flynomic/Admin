// src/components/AddGiftCardModal.js
import React, { useState } from "react";
import { Modal, Button, Form } from "react-bootstrap";
import { ValidateInputs } from "../../utils/helper";
import Loader from "../Loader/Loader";
import useApi from "../../hook/useApi";
import { toast } from "react-toastify";
import { CURRENCY } from "../../utils/enum";

const AddGiftCardModal = ({ show, handleClose }) => {
  const [data, setData] = useState({
    amount: "",
    currency: "",
  });
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const { AsyncPostApiCall } = useApi();

  const handleValues = (e) => {
    const { name, value } = e.target;

    setData((prev) => ({
      ...prev,
      [name]: value,
    }));

    const updatedInputs = ValidateInputs(name, value, errors);
    setErrors((prev) => ({
      ...prev,
      ...updatedInputs,
    }));
  };

  const validateGiftCardForm = () => {
    const newErrors = {};

    // Amount: required and must be positive number
    if (!data.amount) {
      newErrors.amount = "Amount is required";
    } else if (Number(data.amount) <= 0) {
      newErrors.amount = "Amount must be greater than 0";
    }

    // Currency: required
    if (!data.currency.trim()) {
      newErrors.currency = "Currency is required";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const addGiftCard = async (e) => {
    e.preventDefault();

    if (!validateGiftCardForm()) {
      return;
    }

    setLoading(true);

    const result = await AsyncPostApiCall(`/giftcard/create`, {
      ...data,
      amount: Number(data?.amount),
    });

    if (result.errors) {
      toast.error(result.errors[0]);
    } else if (result.success && result.giftCard) {
      toast.success("Gift Card created successfully.");
      setData({
        amount: "",
        currency: "",
      });
      await handleClose();
    }

    setLoading(false);
  };

  //   const changeStatus = () =>

  return (
    <>
      {loading && <Loader />}
      <Modal
        show={show}
        onHide={() => {
          handleClose();
          setData({
            amount: "",
            currency: "",
          });
          setErrors({
            amount: "",
            currency: "",
          });
        }}
      >
        <Modal.Header closeButton>
          <Modal.Title>Create Gift Card</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={addGiftCard}>
            {/* Amount */}
            <Form.Group className="mb-3">
              <Form.Label>Amount</Form.Label>
              <Form.Control
                type="number"
                name="amount"
                placeholder="Enter gift card amount"
                value={data.amount}
                onChange={handleValues}
                className={`${errors?.amount ? "is-invalid" : ""}`}
              />
              {errors?.amount && (
                <div className="invalid-feedback">{errors.amount}</div>
              )}
            </Form.Group>

            {/* Currency */}
            <Form.Group className="mb-3">
              <Form.Label>Currency</Form.Label>
              <Form.Select
                name="currency"
                value={data.currency}
                onChange={handleValues}
                className={`${errors?.currency ? "is-invalid" : ""}`}
              >
                <option value="">Select currency</option>
                <option value={CURRENCY.DOLLAR}>
                  {CURRENCY.DOLLAR.toUpperCase()}
                </option>
                <option value={CURRENCY.INR}>
                  {CURRENCY.INR.toUpperCase()}
                </option>
              </Form.Select>
              {errors?.currency && (
                <div className="invalid-feedback">{errors.currency}</div>
              )}
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button
            variant="secondary"
            onClick={() => {
              handleClose();
              setData({
                amount: "",
                currency: "",
              });
            }}
            disabled={loading}
          >
            Cancel
          </Button>
          <Button variant="primary" onClick={addGiftCard} disabled={loading}>
            {loading ? "Saving..." : "Save Gift Card"}
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default AddGiftCardModal;
