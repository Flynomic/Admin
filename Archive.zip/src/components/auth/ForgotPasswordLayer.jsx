import { Icon } from "@iconify/react/dist/iconify.js";
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import useApi from "../../hook/useApi";
import Loader from "../Loader/Loader";
import { ValidateInputs } from "../../utils/helper";

const ForgotPasswordLayer = () => {
  const { AsyncPostApiCall } = useApi();
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [formData, setFormData] = useState({
    email: "",
  });

  const validate = () => {
    const newErrors = {};

    if (!formData?.email.trim()) {
      newErrors.email = "Email is required";
    } else if (
      !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(formData?.email)
    ) {
      newErrors.email = "Email is invalid";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleValues = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    const updatedInputs = ValidateInputs(name, value, errors);
    setErrors(updatedInputs);
  };

  const resetApiCall = async (e) => {
    e.preventDefault();
    if (!validate()) {
      return;
    }
    const payload = { email: formData?.email };
    setLoading(true);
    const result = await AsyncPostApiCall("/admin/verify-mail", payload);

    if (result.errors) {
      toast.error(result.errors[0]);
    } else if (result.success) {
      toast.success("Reset password link sent");
      setFormData({ email: "" });
      setErrors({});
    }
    setLoading(false);
  };

  return (
    <>
      {loading && <Loader />}
      <section className="auth forgot-password-page bg-base d-flex flex-wrap">
        <div className="auth-left d-lg-block d-none">
          <div className="d-flex align-items-center flex-column h-100 justify-content-center">
            <img src="assets/images/auth/forgot-pass-img.jpg" alt="" />
          </div>
        </div>
        <div className="auth-right py-32 px-24 d-flex flex-column justify-content-center">
          <div className="max-w-464-px mx-auto w-100">
            <div>
              <h4 className="mb-12">Forgot Password</h4>
              <p className="mb-32 text-secondary-light text-lg">
                Enter the email address associated with your account and we will
                send you a link to reset your password.
              </p>
            </div>
            <form onSubmit={resetApiCall}>
              <div className="icon-field">
                <span className="icon top-50 translate-middle-y">
                  <Icon icon="mage:email" />
                </span>
                <input
                  name="email"
                  type="email"
                  value={formData?.email}
                  onChange={handleValues}
                  className={`form-control h-56-px bg-neutral-50 radius-12 ${
                    errors.email ? "is-invalid" : ""
                  }`}
                  placeholder="Enter Email"
                  // required={true}
                />
                {errors.email && (
                  <div className="invalid-feedback">{errors.email}</div>
                )}
              </div>
              <button
                type="submit"
                className="btn btn-primary text-sm btn-sm px-12 py-16 w-100 radius-12 mt-32"
                // data-bs-toggle="modal"
                // data-bs-target="#exampleModal"
              >
                Continue
              </button>
              <div className="text-center">
                <Link to="/sign-in" className="text-primary-600 fw-bold mt-24">
                  Back to Sign In
                </Link>
              </div>
              {/* <div className="mt-120 text-center text-sm">
                <p className="mb-0">
                  Already have an account?{" "}
                  <Link to="/sign-in" className="text-primary-600 fw-semibold">
                    Sign In
                  </Link>
                </p>
              </div> */}
            </form>
          </div>
        </div>
      </section>
      {/* Modal */}
      {/* <div
        className="modal fade"
        id="exampleModal"
        tabIndex={-1}
        aria-hidden="true"
      >
        <div className="modal-dialog modal-dialog modal-dialog-centered">
          <div className="modal-content radius-16 bg-base">
            <div className="modal-body p-40 text-center">
              <div className="mb-32">
                <img src="assets/images/auth/envelop-icon.png" alt="" />
              </div>
              <h6 className="mb-12">Verify your Email</h6>
              <p className="text-secondary-light text-sm mb-0">
                Thank you, check your email for instructions to reset your
                password
              </p>
              <button
                type="button"
                className="btn btn-primary text-sm btn-sm px-12 py-16 w-100 radius-12 mt-32"
              >
                Skip
              </button>
              <div className="mt-32 text-sm">
                <p className="mb-0">
                  Don’t receive an email?{" "}
                  <Link to="/resend" className="text-primary-600 fw-semibold">
                    Resend
                  </Link>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div> */}
    </>
  );
};

export default ForgotPasswordLayer;
