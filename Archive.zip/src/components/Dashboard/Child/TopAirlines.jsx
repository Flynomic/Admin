import React, { useEffect, useState } from "react";
import Loader from "../../Loader/Loader";
import useApi from "../../../hook/useApi";
import { toast } from "react-toastify";
import { AIRLINE_CODE } from "../../../utils/constant";

const TopAirlines = () => {
  const [airlines, setAirlines] = useState([]);
  const [loading, setLoading] = useState(false);
  const { AsyncGetApiCall } = useApi();

  useEffect(() => {
    const fetchTopAirlines = async () => {
      // setLoading(true);
      const url = `/analytics/most-booked-airlines`;
      const result = await AsyncGetApiCall(url);
      if (result?.success) {
        setAirlines(result?.data);
      } else {
        toast.error(result[0]?.message);
      }
      // setLoading(false);
    };

    fetchTopAirlines();
  }, []);

  return (
    <>
      {loading && <Loader />}
      <div className="col-xxl-3 col-xl-12">
        <div className="card h-100">
          <div className="card-body">
            <div className="d-flex align-items-center flex-wrap gap-2 justify-content-between">
              <h6 className="mb-2 fw-bold text-lg mb-0">Top Airlines</h6>
            </div>
            <span className="text-sm">(By Bookings)</span>
            <div className="mt-32">
              {airlines.slice(0, 6).map((airline, index) => (
                <div
                  key={index}
                  className="d-flex align-items-center justify-content-between gap-3 mb-20">
                  <div className="d-flex align-items-center gap-3">
                    <span
                      className={`Airline-Image airline-${airline.airline}`}></span>
                    <div className="flex-grow-1 mr-2">
                      <h6 className="text-md mb-0 fw-medium">
                        {AIRLINE_CODE[airline.airline] || airline.airline}
                      </h6>
                      <span className="text-sm text-secondary-light fw-medium">
                        Code: {airline.airline}
                      </span>
                    </div>
                  </div>
                  <span className="text-primary-light text-md fw-medium">
                    {airline.count}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default TopAirlines;
