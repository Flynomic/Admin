import React, { useEffect, useState } from "react";
import ReactApexChart from "react-apexcharts";
import { toast } from "react-toastify";
import useApi from "../../../hook/useApi";
import Loader from "../../Loader/Loader";

const TopDestinations = () => {
  const [destinations, setDestinations] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const { AsyncGetApiCall } = useApi();

  useEffect(() => {
    const fetchTopDestinations = async () => {
      // setLoading(true);
      const url = `/analytics/top-hotel-destinations`;
      const result = await AsyncGetApiCall(url);
      if (result?.success) {
        console.log("response", result?.data?.hotels)
        setDestinations(result?.data?.hotels);
        setTotal(result?.data?.total);
      } else {
        toast.error(result[0]?.message);
      }
      // setLoading(false);
    };

    fetchTopDestinations();
  }, []);

  // Chart series and options
  const barChartSeries = [
    {
      name: "Bookings",
      data: destinations.map((dest) => dest.count),
    },
  ];

  const barChartOptions = {
    chart: {
      type: "bar",
      height: 264,
      toolbar: {
        show: false,
      },
    },
    plotOptions: {
      bar: {
        horizontal: false,
        columnWidth: "55%",
        endingShape: "rounded",
      },
    },
    dataLabels: {
      enabled: false,
    },
    stroke: {
      show: true,
      width: 2,
      colors: ["transparent"],
    },
    xaxis: {
      categories: destinations.map((dest) => dest.destinationCode),
      labels: {
        style: {
          colors: ["#ffffff"],
          fontSize: "12px",
        },
        rotate: -45,
      },
    },
    yaxis: {
      title: {
        text: "Number of Bookings",
      },
    },
    tooltip: {
      y: {
        formatter: (val, opts) => {
          const destinationCode = destinations[opts.dataPointIndex]?.destinationCode;
          const destinationName = destinations[opts.dataPointIndex]?.destinationName;
          return `${destinationName} (${destinationCode}): ${val} Bookings`;
        },
      },
    },
  };

  return (
    <>
      {loading && <Loader />}
      <div className="col-xxl-3 col-xl-6">
        <div className="card h-100 radius-8 border">
          <div className="card-body p-24">
            <h6 className="mb-12 fw-semibold text-lg mb-16">Top Hotel Destinations</h6>
            <div className="d-flex align-items-center gap-2 mb-20">
              <h6 className="fw-semibold mb-0">{total} Bookings</h6>
            </div>
            <ReactApexChart
              options={barChartOptions}
              series={barChartSeries}
              type="bar"
              height={264}
            />
          </div>
        </div>
      </div>
    </>
  );
};

export default TopDestinations;