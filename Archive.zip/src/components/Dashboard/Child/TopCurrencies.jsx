import React, { useState, useEffect } from "react";
import ReactApexChart from "react-apexcharts";
import { toast } from "react-toastify"; // Assuming you're using react-toastify for toast notifications
import useReactApexChart from "../../../hook/useReactApexChart";
import useApi from "../../../hook/useApi";
import Loader from "../../Loader/Loader";

const typeOptions = [
  { label: "All", value: "ALL" },
  { label: "Hotel", value: "HOTEL" },
  { label: "Flight", value: "FLIGHT" },
];

const TopCurrencies = () => {
  const { donutChartSeries, donutChartOptions, setDonutChartSeries, setDonutChartOptions } = useReactApexChart();
  const [type, setType] = useState("ALL");
  const [chartData, setChartData] = useState({});
  const [loading, setLoading] = useState(false);
  const { AsyncGetApiCall } = useApi();

  useEffect(() => {
    const getData = async () => {
      // setLoading(true);
      const url = `/analytics/booking-currency-count?type=${type}`;
      const result = await AsyncGetApiCall(url);
      console.log("API result:", result);
      if (result?.success) {
        const data = result?.data;
        const currencyCounts = data.all || data.hotel || data.flight || {};
        setChartData(currencyCounts);

        // Update chart series and options
        const currencies = Object.keys(currencyCounts);
        const counts = Object.values(currencyCounts);

        console.log("count", counts)

        setDonutChartSeries(counts);
        setDonutChartOptions((prevOptions) => ({
          ...prevOptions,
          labels: currencies,
          colors: currencies.map((_, index) => `hsl(${(index * 360) / Math.max(currencies.length, 1)}, 70%, 50%)`), // Dynamic colors
          legend: {
            show: true,
            position: "bottom",
          },
        }));
      } else {
        toast.error(result[0]?.message || "Failed to fetch currency data");
      }
      // setLoading(false);
    };

    getData();
  }, [type, setDonutChartSeries, setDonutChartOptions]);

  const handleTypeChange = (e) => {
    setType(e.target.value);
  };

  return (
    <>
      {loading && <Loader />}
      <div className="col-xxl-3 col-xl-6">
        <div className="card h-100 radius-8 border-0 overflow-hidden">
          <div className="card-body p-24">
            <div className="d-flex align-items-center flex-wrap gap-2 justify-content-between">
              <h6 className="mb-2 fw-bold text-lg">Top Currencies</h6>
              <div>
                <select
                  className="form-select form-select-sm w-auto bg-base border text-secondary-light"
                  value={type}
                  onChange={handleTypeChange}
                  disabled={loading}
                >
                  {typeOptions.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <ReactApexChart
              options={donutChartOptions}
              series={donutChartSeries}
              type="donut"
              height={264}
            />
            <ul className="d-flex flex-wrap align-items-center justify-content-between mt-3 gap-3">
              {Object.entries(chartData).map(([currency, count], index) => (
                <li key={currency} className="d-flex align-items-center gap-2">
                  <span
                    className="w-12-px h-12-px radius-2"
                    style={{
                      backgroundColor: `hsl(${(index * 120 + 35) % 360}, 80%, 55%)`,
                    }}
                  />
                  <span className="text-secondary-light text-sm fw-normal">
                    {currency}: <span className="text-primary-light fw-semibold">{count}</span>
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </>
  );
};

export default TopCurrencies;