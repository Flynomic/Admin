import React, { useEffect, useState } from "react";
import ReactApexChart from "react-apexcharts";
import { toast } from "react-toastify";
import useApi from "../../../hook/useApi";
import Loader from "../../Loader/Loader";

const typeOptions = [
  { label: "All", value: "ALL" },
  { label: "Hotel", value: "HOTEL" },
  { label: "Flight", value: "FLIGHT" },
];

const monthShortNames = [
  "", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
];

const BookingStatistic = () => {
  const [type, setType] = useState("ALL");
  const [chartData, setChartData] = useState({ monthlyCounts: [], totalBookings: 0 });
  // const [loading, setLoading] = useState(false);
  const { AsyncGetApiCall } = useApi();

  useEffect(() => {
    const getData = async () => {
      // setLoading(true);
      const url = `/analytics/booking-chart-count?type=${type}`
      const result = await AsyncGetApiCall(url);
      console.log("API result:", result);
      if (result?.success) {
        setChartData(result?.data);
        console.log("chartData", result.data)
      } else {
        toast.error(result[0]?.message);
      }
      // setLoading(false);
    }

    getData()

  }, [type]);

  // Prepare chart data
  const categories = chartData.monthlyCounts.map(
    (item) => `${monthShortNames[item.month]}-${String(item.year).slice(-2)}`
  );
  const seriesData = chartData.monthlyCounts.map((item) => item.count);

  const chartOptions = {
    chart: { type: "area" },
    xaxis: { categories },
    // ...other options
  };

  return (
    <>
      {/* {loading && <Loader />} */}
      <div className="col-xxl-6 col-xl-12">
        <div className="card h-100">
          <div className="card-body">
            <div className="d-flex flex-wrap align-items-center justify-content-between">
              <h6 className="text-lg mb-0">Booking Statistics</h6>
              <select
                className="form-select bg-base form-select-sm w-auto"
                value={type}
                onChange={(e) => setType(e.target.value)}
              >
                {typeOptions.map((opt) => (
                  <option key={opt.value} value={opt.value}>{opt.label}</option>
                ))}
              </select>
            </div>
            <div className="d-flex flex-wrap align-items-center gap-2 mt-8">
              <h6 className="mb-0">{chartData?.totalBookings}</h6>
              {/* You can update the rest of the stats as needed */}
            </div>
            <br />
            <ReactApexChart
              options={chartOptions}
              series={[{ name: "Bookings", data: seriesData }]}
              type="area"
              height={264}
            />
          </div>
        </div>
      </div>
    </>
  );
};

export default BookingStatistic;