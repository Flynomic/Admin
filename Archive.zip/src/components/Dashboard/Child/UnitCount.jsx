import React, { useEffect, useState } from "react";
import { Icon } from "@iconify/react";
import useApi from "../../../hook/useApi";

const UnitCount = () => {
  const { AsyncGetApiCall } = useApi();
  const [data, setData] = useState(null);

  const getData = async () => {
    const response = await AsyncGetApiCall("/analytics/dashboard-main-cards");
    if (response?.success) {
      setData(response?.data);
    }
    console.log("responseData", response?.data)
  };

  useEffect(() => {
    getData();
  }, []);

  // Helper function to render arrow and change value
  const renderTrend = (change) => {
    const isPositive = change > 0;
    return (
      <span
        className={`d-inline-flex align-items-center gap-1 ${isPositive ? "text-success-main" : "text-danger-main"
          }`}
      >
        <Icon
          icon={isPositive ? "bxs:up-arrow" : "bxs:down-arrow"}
          className="text-xs"
        />
        {isPositive ? `+${Math.trunc(change)}` : Math.trunc(change)}%
      </span>
    );
  };

  // Define card-specific configurations (icons and background colors)
  const cardConfigs = {
    users: {
      icon: "gridicons:multiple-users",
      bgColor: "bg-cyan",
      gradient: "bg-gradient-start-1",
    },
    hotel_bookings: {
      icon: "fa-solid:award",
      bgColor: "bg-purple",
      gradient: "bg-gradient-start-2",
    },
    flight_bookings: {
      icon: "fluent:people-20-filled",
      bgColor: "bg-info",
      gradient: "bg-gradient-start-3",
    },
    income: {
      icon: "solar:wallet-bold",
      bgColor: "bg-success-main",
      gradient: "bg-gradient-start-4",
    },
    expense: {
      icon: "fa6-solid:file-invoice-dollar",
      bgColor: "bg-red",
      gradient: "bg-gradient-start-5",
    },
  };

  return (
    <div className="row row-cols-xxxl-5 row-cols-lg-3 row-cols-sm-2 row-cols-1 gy-4">
      {data &&
        Object.entries(data).map(([key, metric]) => (
          <div className="col" key={key}>
            <div
              className={`card shadow-none border ${cardConfigs[key]?.gradient || "bg-gradient-start-1"
                } h-100`}
            >
              <div className="card-body p-20">
                <div className="d-flex flex-wrap align-items-center justify-content-between gap-3">
                  <div>
                    <p className="fw-medium text-primary-light mb-1">
                      {metric.title}
                    </p>
                    <h6 className="mb-0">{metric.value ?? 0}</h6>
                  </div>
                  <div
                    className={`w-50-px h-50-px ${cardConfigs[key]?.bgColor || "bg-cyan"
                      } rounded-circle d-flex justify-content-center align-items-center`}
                  >
                    <Icon
                      icon={
                        cardConfigs[key]?.icon || "gridicons:multiple-users"
                      }
                      className="text-white text-2xl mb-0"
                    />
                  </div>
                </div>

                {
                  (metric.title !== "Total Income" && metric.title !== "Total Expenses") && (
                    <p className="fw-medium text-sm text-primary-light mt-12 mb-0 d-flex align-items-center gap-2">
                      {renderTrend(metric?.change ?? 0)}
                      <span>{metric.label}</span>
                    </p>
                  )
                }
              </div>
            </div>
          </div>
        ))}
    </div>
  );
};

export default UnitCount;
