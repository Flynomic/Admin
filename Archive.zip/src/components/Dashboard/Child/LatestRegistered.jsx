// import { Icon } from "@iconify/react/dist/iconify.js";
// import React, { useEffect, useState } from "react";
// import { Link } from "react-router-dom";
// import useApi from "../../../hook/useApi";
// import { formatDate } from "../../../utils/helper";

// const LatestRegistered = () => {
//   const { AsyncGetApiCall } = useApi();
//   const [data, setData] = useState([]);
//   const [hotelsData, setHotelsData] = useState([]);
//   const [currentTab, setCurrentTab] = useState("USERS");
//   const query = {
//     pageNo: 1,
//     limitVal: 5,
//     search: "",
//     status: "",
//   };

//   const tab = {
//     USERS: "USERS",
//     HOTEL: "HOTEL",
//     FLIGHT: "FLIGHT",
//   };

//   const getData = async () => {
//     let url = currentTab === tab.USERS ? "/users/list" : currentTab === tab.HOTEL ? "/hotel-booking/admin/list" : "/flight/bookings";

//     const response = await AsyncGetApiCall(url, query);
//     console.log("url", url)
//     if (response?.success) {
//       console.log("data is: ", response?.data)
//       setData(response?.data);
//     }
//   }

//   useEffect(() => {
//     getData();
//   }, [currentTab]);

//   return (
//     <div className="col-xxl-9 col-xl-12">
//       <div className="card h-100">
//         <div className="card-body p-24">
//           <div className="d-flex flex-wrap align-items-center gap-1 justify-content-between mb-16">
//             <ul
//               className="nav border-gradient-tab nav-pills mb-0"
//               id="pills-tab"
//               role="tablist"
//             >
//               <li className="nav-item" role="presentation">
//                 <button
//                   className={`nav-link d-flex align-items-center${currentTab === tab.USERS ? " active" : ""
//                     }`}
//                   id="pills-to-do-list-tab"
//                   data-bs-toggle="pill"
//                   data-bs-target="#pills-to-do-list"
//                   type="button"
//                   role="tab"
//                   aria-controls="pills-to-do-list"
//                   aria-selected={currentTab === tab.USERS}
//                   onClick={() => setCurrentTab(tab.USERS)}
//                 >
//                   Latest Registered
//                 </button>
//               </li>
//               <li className="nav-item" role="presentation">
//                 <button
//                   className={`nav-link d-flex align-items-center${currentTab === tab.HOTEL ? " active" : ""
//                     }`}
//                   id="pills-recent-leads-tab-hotel"
//                   data-bs-toggle="pill"
//                   data-bs-target="#pills-recent-leads-hotel"
//                   type="button"
//                   role="tab"
//                   aria-controls="pills-recent-leads-hotel"
//                   aria-selected={currentTab === tab.HOTEL}
//                   tabIndex={-1}
//                   onClick={() => setCurrentTab(tab.HOTEL)}
//                 >
//                   Latest Hotel Booking
//                 </button>
//               </li>
//               <li className="nav-item" role="presentation">
//                 <button
//                   className={`nav-link d-flex align-items-center${currentTab === tab.FLIGHT ? " active" : ""
//                     }`}
//                   id="pills-recent-leads-tab-flight"
//                   data-bs-toggle="pill"
//                   data-bs-target="#pills-recent-leads-flight"
//                   type="button"
//                   role="tab"
//                   aria-controls="pills-recent-leads-flight"
//                   aria-selected={currentTab === tab.FLIGHT}
//                   tabIndex={-1}
//                   onClick={() => setCurrentTab(tab.FLIGHT)}
//                 >
//                   Latest Flight Booking
//                 </button>
//               </li>
//             </ul>
//             <Link
//               to={
//                 currentTab === tab.USERS
//                   ? "/users-list"
//                   : currentTab === tab.HOTEL
//                     ? "/hotel-booking"
//                     : "/flight-booking"
//               }
//               className="text-primary-600 hover-text-primary d-flex align-items-center gap-1"
//             >
//               View All
//               <Icon icon="solar:alt-arrow-right-linear" className="icon" />
//             </Link>
//           </div>
//           <div className="tab-content" id="pills-tabContent">
//             {currentTab === tab.USERS && (
//               <div
//                 className="tab-pane fade show active"
//                 id="pills-to-do-list"
//                 role="tabpanel"
//                 aria-labelledby="pills-to-do-list-tab"
//                 tabIndex={0}
//               >
//                 <div className="table-responsive scroll-sm">
//                   <table className="table bordered-table sm-table mb-0">
//                     <thead>
//                       <tr>
//                         <th scope="col">Users </th>
//                         <th scope="col">Registered On</th>
//                         <th scope="col">Phone Number</th>
//                         <th scope="col" className="text-center">
//                           Status
//                         </th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {data && data.length > 0 ? (
//                         data.map((item) => (
//                           <tr key={item.id}>
//                             <td>
//                               <div className="d-flex align-items-center">
//                                 <img
//                                   src="https://wow-dash.com/demo/assets/images/users/user1.png"
//                                   alt=""
//                                   className="w-40-px h-40-px rounded-circle flex-shrink-0 me-12 overflow-hidden"
//                                 />
//                                 <div className="flex-grow-1">
//                                   <h6 className="text-md mb-0 fw-medium">
//                                     {item.firstName || item.lastName
//                                       ? `${item.firstName || ""} ${item.lastName || ""
//                                         }`.trim()
//                                       : "N/A"}
//                                   </h6>
//                                   <span className="text-sm text-secondary-light fw-medium">
//                                     {item?.email || "N/A"}
//                                   </span>
//                                 </div>
//                               </div>
//                             </td>
//                             <td>{formatDate(item?.createdAt, false)}</td>
//                             <td>{item?.phoneNumber || "N/A"}</td>
//                             <td className="text-center">
//                               <span
//                                 className={`px-24 py-4 rounded-pill fw-medium text-sm ${item.isVerified
//                                   ? "bg-success-focus text-success-main"
//                                   : "bg-danger-focus text-danger-main"
//                                   }`}
//                               >
//                                 {item.isVerified ? "Active" : "Inactive"}
//                               </span>
//                             </td>
//                           </tr>
//                         ))
//                       ) : (
//                         <tr>
//                           <td colSpan="4" className="text-center">
//                             Data not found
//                           </td>
//                         </tr>
//                       )}
//                     </tbody>
//                   </table>
//                 </div>
//               </div>
//             )}
//             {currentTab === tab.HOTEL && (
//               <div
//                 className="tab-pane fade show active"
//                 id="pills-recent-leads-hotel"
//                 role="tabpanel"
//                 aria-labelledby="pills-recent-leads-tab-hotel"
//                 tabIndex={0}
//               >
//                 {/* Replace with actual hotel booking table */}
//                 <div className="table-responsive scroll-sm">
//                   <table className="table bordered-table sm-table mb-0">
//                     <thead>
//                       <tr>
//                         <th scope="col">Booking Ref</th>
//                         <th scope="col">Name</th>
//                         <th scope="col">Hotel Name</th>
//                         <th scope="col" className="text-center">
//                           Check-In
//                         </th>
//                         <th scope="col" className="text-center">
//                           Check-Out
//                         </th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {data && data.length > 0 ? (
//                         data.map((item) => (
//                           <tr key={item.id}>
//                             <td>
//                               <div className="d-flex align-items-center">
//                                 <Icon
//                                   icon="flowbite:building-solid"
//                                   className="w-40-px h-40-px rounded-circle flex-shrink-0 me-12 overflow-hidden"
//                                 />
//                                 <div className="flex-grow-1">
//                                   <h6 className="text-md mb-0 fw-medium">{"item?.hotelBookings[0]?.reference" || "N/A"}</h6>
//                                   <span className="text-sm text-secondary-light fw-medium">
//                                     {"item.email" || "N/A"}
//                                   </span>
//                                 </div>
//                               </div>
//                             </td>
//                             <td>{formatDate(item.bookingDate, false)}</td>
//                             <td>{"item.plan" || "N/A"}</td>
//                             <td className="text-center">
//                               <span
//                                 className={`px-24 py-4 rounded-pill fw-medium text-sm ${item.status === "Active"
//                                   ? "bg-success-focus text-success-main"
//                                   : "bg-danger-focus text-danger-main"
//                                   }`}
//                               >
//                                 {"item.status" || "N/A"}
//                               </span>
//                             </td>
//                           </tr>
//                         ))
//                       ) : (
//                         <tr>
//                           <td colSpan={4} className="text-center">
//                             No hotel bookings found
//                           </td>
//                         </tr>
//                       )}
//                     </tbody>
//                   </table>
//                 </div>
//               </div>
//             )}
//             {currentTab === tab.FLIGHT && (
//               <div
//                 className="tab-pane fade show active"
//                 id="pills-recent-leads-flight"
//                 role="tabpanel"
//                 aria-labelledby="pills-recent-leads-tab-flight"
//                 tabIndex={0}
//               >
//                 {/* Replace with actual flight booking table */}
//                 <div className="table-responsive scroll-sm">
//                   <table className="table bordered-table sm-table mb-0">
//                     <thead>
//                       <tr>
//                         <th scope="col">Users </th>
//                         <th scope="col">Registered On</th>
//                         <th scope="col">Plan</th>
//                         <th scope="col" className="text-center">
//                           Status
//                         </th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {/* Example static rows, replace with dynamic data */}
//                       <tr>
//                         <td>
//                           <div className="d-flex align-items-center">
//                             <img
//                               src="assets/images/users/user1.png"
//                               alt=""
//                               className="w-40-px h-40-px rounded-circle flex-shrink-0 me-12 overflow-hidden"
//                             />
//                             <div className="flex-grow-1">
//                               <h6 className="text-md mb-0 fw-medium">
//                                 Dianne Russell
//                               </h6>
//                               <span className="text-sm text-secondary-light fw-medium">
//                                 redaniel@gmail.com
//                               </span>
//                             </div>
//                           </div>
//                         </td>
//                         <td>27 Mar 2024</td>
//                         <td>Free</td>
//                         <td className="text-center">
//                           <span className="bg-success-focus text-success-main px-24 py-4 rounded-pill fw-medium text-sm">
//                             Active
//                           </span>
//                         </td>
//                       </tr>
//                       {/* ...other static rows... */}
//                     </tbody>
//                   </table>
//                 </div>
//               </div>
//             )}
//           </div>
//         </div>
//       </div>
//     </div >
//   );
// };

// export default LatestRegistered;


import { Icon } from "@iconify/react/dist/iconify.js";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import useApi from "../../../hook/useApi";
import { formatDate } from "../../../utils/helper";
import Loader from "../../Loader/Loader";

const LatestRegistered = () => {
  const { AsyncGetApiCall } = useApi();
  const [data, setData] = useState({
    users: [],
    hotel: [],
    flight: [],
    loading: false,
    error: null,
  });
  const [currentTab, setCurrentTab] = useState("USERS");
  const query = {
    pageNo: 1,
    limitVal: 5,
    search: "",
    status: "",
  };

  const tab = {
    USERS: "USERS",
    HOTEL: "HOTEL",
    FLIGHT: "FLIGHT",
  };

  const getData = async () => {
    setData((prev) => ({ ...prev, loading: true, error: null }));
    let url = "";
    switch (currentTab) {
      case tab.USERS:
        url = "/users/list";
        break;
      case tab.HOTEL:
        url = "/hotel-booking/admin/list";
        break;
      case tab.FLIGHT:
        url = "/flight/bookings";
        break;
    }

    try {
      console.log("Fetching from:", url);
      const response = await AsyncGetApiCall(url, query);
      console.log("Response data:", response?.data);
      if (response?.success) {
        setData((prev) => ({
          ...prev,
          [currentTab.toLowerCase()]: response.data,
          loading: false,
        }));
      } else {
        throw new Error("No data received from API");
      }
    } catch (error) {
      setData((prev) => ({
        ...prev,
        error: error.message || "An error occurred",
        loading: false,
      }));
    }
  };

  useEffect(() => {
    getData();
  }, [currentTab]);

  return (
    <div className="col-xxl-9 col-xl-12">
      <div className="card h-100">
        <div className="card-body p-24">
          <div className="d-flex flex-wrap align-items-center gap-1 justify-content-between mb-16">
            <ul className="nav border-gradient-tab nav-pills mb-0" id="pills-tab" role="tablist">
              <li className="nav-item" role="presentation">
                <button
                  className={`nav-link d-flex align-items-center${currentTab === tab.USERS ? " active" : ""}`}
                  id="pills-to-do-list-tab"
                  data-bs-toggle="pill"
                  data-bs-target="#pills-to-do-list"
                  type="button"
                  role="tab"
                  aria-controls="pills-to-do-list"
                  aria-selected={currentTab === tab.USERS}
                  onClick={() => setCurrentTab(tab.USERS)}
                >
                  Latest Registered
                </button>
              </li>
              <li className="nav-item" role="presentation">
                <button
                  className={`nav-link d-flex align-items-center${currentTab === tab.HOTEL ? " active" : ""}`}
                  id="pills-recent-leads-tab-hotel"
                  data-bs-toggle="pill"
                  data-bs-target="#pills-recent-leads-hotel"
                  type="button"
                  role="tab"
                  aria-controls="pills-recent-leads-hotel"
                  aria-selected={currentTab === tab.HOTEL}
                  onClick={() => setCurrentTab(tab.HOTEL)}
                >
                  Latest Hotel Booking
                </button>
              </li>
              <li className="nav-item" role="presentation">
                <button
                  className={`nav-link d-flex align-items-center${currentTab === tab.FLIGHT ? " active" : ""}`}
                  id="pills-recent-leads-tab-flight"
                  data-bs-toggle="pill"
                  data-bs-target="#pills-recent-leads-flight"
                  type="button"
                  role="tab"
                  aria-controls="pills-recent-leads-flight"
                  aria-selected={currentTab === tab.FLIGHT}
                  onClick={() => setCurrentTab(tab.FLIGHT)}
                >
                  Latest Flight Booking
                </button>
              </li>
            </ul>
            <Link
              to={
                currentTab === tab.USERS
                  ? "/users-list"
                  : currentTab === tab.HOTEL
                    ? "/hotel-booking"
                    : "/flight-booking"
              }
              className="text-primary-600 hover-text-primary d-flex align-items-center gap-1"
            >
              View All
              <Icon icon="solar:alt-arrow-right-linear" className="icon" />
            </Link>
          </div>
          <div className="tab-content" id="pills-tabContent">
            {data.loading && <Loader />}
            {data.error && <p>Error: {data.error}</p>}
            {currentTab === tab.USERS && (
              <div
                className="tab-pane fade show active"
                id="pills-to-do-list"
                role="tabpanel"
                aria-labelledby="pills-to-do-list-tab"
                tabIndex={0}
              >
                <div className="table-responsive scroll-sm">
                  <table className="table bordered-table sm-table mb-0">
                    <thead>
                      <tr>
                        <th scope="col">Users</th>
                        <th scope="col">Registered On</th>
                        <th scope="col">Phone Number</th>
                        <th scope="col" className="text-center">
                          Status
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.users && data.users.length > 0 ? (
                        data.users.map((item) => (
                          <tr key={item._id}>
                            <td>
                              <div className="d-flex align-items-center">
                                <img
                                  src="https://wow-dash.com/demo/assets/images/users/user1.png"
                                  alt=""
                                  className="w-40-px h-40-px rounded-circle flex-shrink-0 me-12 overflow-hidden"
                                />
                                <div className="flex-grow-1">
                                  <h6 className="text-md mb-0 fw-medium">{item.firstName || "N/A"}</h6>
                                  <span className="text-sm text-secondary-light fw-medium">
                                    {item.email || "N/A"}
                                  </span>
                                </div>
                              </div>
                            </td>
                            <td>{item.createdAt ? formatDate(item.createdAt, false) : "N/A"}</td>
                            <td>{item?.phoneNumber ? item?.countryCode : ""} {item.phoneNumber || "N/A"}</td>
                            <td className="text-center">
                              <span
                                className={`px-24 py-4 rounded-pill fw-medium text-sm ${item.isVerified
                                  ? "bg-success-focus text-success-main"
                                  : "bg-danger-focus text-danger-main"
                                  }`}
                              >
                                {item.isVerified ? "Active" : "Inactive"}
                              </span>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={4} className="text-center">
                            No users found
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
            {currentTab === tab.HOTEL && (
              <div
                className="tab-pane fade show active"
                id="pills-recent-leads-hotel"
                role="tabpanel"
                aria-labelledby="pills-recent-leads-tab-hotel"
                tabIndex={0}
              >
                <div className="table-responsive scroll-sm">
                  <table className="table bordered-table sm-table mb-0">
                    <thead>
                      <tr>
                        <th scope="col">Booking Ref</th>
                        <th scope="col">Name</th>
                        <th scope="col">Hotel Name</th>
                        <th scope="col" className="text-center">
                          Check-In
                        </th>
                        <th scope="col" className="text-center">
                          Check-Out
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.hotel && data.hotel.length > 0 ? (
                        data.hotel.map((item) => (
                          <tr key={item._id}>
                            <td>
                              <div className="d-flex align-items-center">
                                <Icon
                                  icon="flowbite:building-solid"
                                  className="w-40-px h-40-px rounded-circle flex-shrink-0 me-12 overflow-hidden"
                                />
                                <div className="flex-grow-1">
                                  <h6 className="text-md mb-0 fw-medium">
                                    {item.hotelBookings && item.hotelBookings[0]?.reference
                                      ? item.hotelBookings[0].reference
                                      : "N/A"}
                                  </h6>
                                </div>
                              </div>
                            </td>
                            <td>
                              {item.hotelBookings && item.hotelBookings[0]?.holder
                                ? `${item.hotelBookings[0].holder.name} ${item.hotelBookings[0].holder.surname}`.trim()
                                : "N/A"}
                            </td>
                            <td>
                              {item.hotelBookings && item.hotelBookings[0]?.hotel?.name || "N/A"}
                            </td>
                            <td className="text-center">
                              {item.hotelBookings && item.hotelBookings[0]?.hotel?.checkIn
                                ? formatDate(item.hotelBookings[0].hotel.checkIn, false)
                                : "N/A"}
                            </td>
                            <td className="text-center">
                              {item.hotelBookings && item.hotelBookings[0]?.hotel?.checkOut
                                ? formatDate(item.hotelBookings[0].hotel.checkOut, false)
                                : "N/A"}
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={6} className="text-center">
                            No hotel bookings found
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
            {currentTab === tab.FLIGHT && (
              <div
                className="tab-pane fade show active"
                id="pills-recent-leads-flight"
                role="tabpanel"
                aria-labelledby="pills-recent-leads-tab-flight"
                tabIndex={0}
              >
                <div className="table-responsive scroll-sm">
                  <table className="table bordered-table sm-table mb-0">
                    <thead>
                      <tr>
                        <th scope="col">Mystifly Reference</th>
                        <th scope="col">Name</th>
                        <th scope="col">Origin</th>
                        <th scope="col">Destination</th>
                        <th scope="col" className="text-center">
                          Departure Date
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.flight && data.flight.length > 0 ? (
                        data.flight.map((item) => (
                          <tr key={item._id}>
                            <td>
                              <div className="d-flex align-items-center">
                                <i className="ri-flight-takeoff-fill menu-icon rounded-circle flex-shrink-0 me-12 overflow-hidden" style={{ fontSize: "30px" }}></i>
                                <div className="flex-grow-1">
                                  <h6 className="text-md mb-0 fw-medium">
                                    {item.tripDetails?.TravelItinerary?.MFRef || "N/A"}
                                  </h6>
                                </div>
                              </div>
                            </td>
                            <td>
                              {item.tripDetails?.TravelItinerary?.PassengerInfos &&
                                item.tripDetails.TravelItinerary.PassengerInfos[0]?.Passenger?.PaxName
                                ? `${item.tripDetails.TravelItinerary.PassengerInfos[0].Passenger.PaxName.PassengerFirstName} ${item.tripDetails.TravelItinerary.PassengerInfos[0].Passenger.PaxName.PassengerLastName}`.trim()
                                : "N/A"}
                            </td>
                            <td>{item.tripDetails?.TravelItinerary?.Origin || "N/A"}</td>
                            <td>{item.tripDetails?.TravelItinerary?.Destination || "N/A"}</td>
                            <td className="text-center">
                              {item.tripDetails?.TravelItinerary?.Itineraries &&
                                item.tripDetails.TravelItinerary.Itineraries[0]?.ItineraryInfo?.ReservationItems &&
                                item.tripDetails.TravelItinerary.Itineraries[0].ItineraryInfo.ReservationItems[0]?.DepartureDateTime
                                ? formatDate(
                                  item.tripDetails.TravelItinerary.Itineraries[0].ItineraryInfo.ReservationItems[0].DepartureDateTime,
                                  false
                                )
                                : "N/A"}
                            </td>

                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={6} className="text-center">
                            No flight bookings found
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default LatestRegistered;