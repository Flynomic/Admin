import React from "react";
import UnitCount from "./Child/UnitCount";
import BookingStatistic from "./Child/BookingStatistic";
import TopDestinations from "./Child/TopDestinations";
import LatestRegistered from "./Child/LatestRegistered";
import TopAirlines from "./Child/TopAirlines";
import TopCountries from "./Child/TopCountries";
import GeneratedContent from "./Child/GeneratedContent";
import TopCurrencies from "./Child/TopCurrencies";

const DashBoardLayerOne = () => {
  return (
    <>
      {/* UnitCountOne */}
      <UnitCount />

      <section className="row gy-4 mt-1">
        {/* SalesStatisticOne */}
        <BookingStatistic />

        {/* TopDestinationsOne */}
        <TopDestinations />

        {/* TopCurrencies */}
        <TopCurrencies />

        {/* LatestRegisteredOne */}
        <LatestRegistered />

        {/* TopAirlinesOne*/}
        <TopAirlines />

        {/* TopCountries */}
        {/* <TopCountries /> */}

        {/* GeneratedContent */}
        {/* <GeneratedContent /> */}
      </section>
    </>
  );
};

export default DashBoardLayerOne;
