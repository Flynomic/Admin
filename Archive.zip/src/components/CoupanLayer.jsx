import React, { useCallback, useEffect, useState } from "react";
import { Icon } from "@iconify/react";
import { toast } from "react-toastify";
import { debounce } from "lodash";
import dayjs from "dayjs";
import { TbCurrencyDollar } from "react-icons/tb";
import useApi from "../hook/useApi";
import Loader from "./Loader/Loader";
import Paggination from "./Paggination";
import CouponModal from "./model/CouponModal";

const CouponLayer = () => {
  const [response, setResponse] = useState(null); // full API payload
  const [loading, setLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [modalMode, setModalMode] = useState("create");
  const [modalData, setModalData] = useState(null);

  const [query, setQuery] = useState({
    pageNo: 1,
    limitVal: 50,
    search: "",
    couponType: "", // Add couponType to query state (empty string for "All")
  });

  const { AsyncGetApiCall, AsyncDeleteApiCall, AsyncPatchAPICall } = useApi();

  const handleModalClose = (shouldRefresh = false) => {
    setShowModal(false);
    setModalData(null);
    if (shouldRefresh) fetchCoupons();
  };

  const restoreCoupon = async (id) => {
    setLoading(true);
    const result = await AsyncPatchAPICall(`/coupon/update/${id}`, {
      isDeleted: false,
    });

    if (result?.errors) {
      toast.error(result.errors[0]);
    } else if (result?.success) {
      toast.success("Coupon restored successfully");
      fetchCoupons();
    }

    setLoading(false);
  };

  const fetchCoupons = async () => {
    setLoading(true);
    const queryParams = {
      pageNo: query.pageNo,
      limitVal: query.limitVal,
      search: query.search,
      ...(query.couponType && { couponType: query.couponType }), // Only include couponType if not empty
    };
    const result = await AsyncGetApiCall("/coupon/list", queryParams);

    if (result?.errors) {
      toast.error(result.errors[0]);
    } else {
      setResponse(result);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchCoupons();
  }, [query]);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const debouncedSearch = useCallback(
    debounce((value) => {
      setQuery((prev) => ({ ...prev, search: value, pageNo: 1 }));
    }, 500),
    []
  );

  const handleSearchChange = (e) => debouncedSearch(e.target.value);

  const handleCouponTypeChange = (e) => {
    const couponType = e.target.value;
    setQuery((prev) => ({
      ...prev,
      couponType,
      pageNo: 1, // Reset to first page on coupon type change
    }));
  };

  const deleteCoupon = async (id) => {
    setLoading(true);
    const result = await AsyncDeleteApiCall(`/coupon/delete/${id}`);
    if (result?.errors) {
      toast.error(result.errors[0]);
    } else if (result?.success) {
      toast.success("Coupon deleted successfully");
      fetchCoupons();
    }
    setLoading(false);
  };

  const coupons = response?.data ?? [];
  const pagination = response?.pagination ?? {};
  const { total = 0, totalPages = 0, currentPage = 1 } = pagination;

  return (
    <>
      {loading && <Loader />}
      <div className="card h-100 p-0 radius-12">
        {/* ─────────────────── Header ─────────────────── */}
        <div className="card-header border-bottom bg-base py-16 px-24 d-flex flex-wrap gap-3 justify-content-between">
          <div className="d-flex align-items-center gap-3 flex-wrap w-100">
            {/* Limit selector */}
            <span className="text-md fw-medium text-secondary-light">Show</span>
            <select
              className="form-select form-select-sm w-auto ps-12 py-6 radius-12 h-40-px"
              value={query.limitVal}
              onChange={(e) =>
                setQuery((prev) => ({
                  ...prev,
                  limitVal: Number(e.target.value),
                  pageNo: 1,
                }))
              }
            >
              {Array.from({ length: 20 }, (_, i) => (i + 1) * 5).map((v) => (
                <option key={v} value={v}>
                  {v}
                </option>
              ))}
            </select>

            {/* Coupon Type selector */}
            <span className="text-md fw-medium text-secondary-light">Coupon Type</span>
            <select
              className="form-select form-select-sm w-auto ps-12 py-6 radius-12 h-40-px"
              value={query.couponType}
              onChange={handleCouponTypeChange}
              aria-label="Filter by coupon type"
            >
              <option value="">All</option>
              <option value="HOTEL">Hotel</option>
              <option value="FLIGHT">Flight</option>
            </select>

            {/* Search */}
            <form className="navbar-search">
              <input
                type="text"
                className="bg-base h-40-px w-auto"
                placeholder="Search by coupon code"
                onChange={handleSearchChange}
              />
              <Icon icon="ion:search-outline" className="icon" />
            </form>

            {/* Add button */}
            <button
              type="button"
              className="btn btn-primary-600 radius-8 px-17 py-9 d-flex align-items-center gap-2 ms-auto"
              onClick={() => {
                setModalMode("create");
                setModalData(null);
                setShowModal(true);
              }}
              disabled={loading}
            >
              <Icon icon="mdi:gift-outline" style={{ fontSize: 20 }} />
              Create Coupon
            </button>
          </div>
        </div>

        {/* ─────────────────── Table ─────────────────── */}
        <div className="card-body p-24">
          <div className="table-responsive scroll-sm">
            <table className="table bordered-table sm-table mb-0">
              <thead>
                <tr>
                  <th>S.No</th>
                  <th>Amount</th>
                  <th>Coupon Code</th>
                  <th>Coupon Type</th>
                  <th>Start Date</th>
                  <th>End Date</th>
                  <th>Description</th>
                  <th>Status</th>
                  <th style={{ textAlign: "center" }}>Action</th>
                </tr>
              </thead>

              <tbody>
                {coupons.length ? (
                  coupons.map((c, i) => {
                    const rowNo = (currentPage - 1) * query.limitVal + i + 1;
                    const isActive =
                      !c.isDeleted &&
                      dayjs().isAfter(c.startDate) &&
                      dayjs().isBefore(c.endDate);

                    return (
                      <tr key={c._id}>
                        <td>{rowNo}</td>

                        {/* Amount with currency icon */}
                        <td className="flex items-center justify-center gap-2">
                          ${" "}{c.amount}
                        </td>

                        <td>{c.couponCode}</td>
                        <td>{c.couponType}</td>
                        <td>{dayjs(c.startDate).format("DD-MMM-YYYY")}</td>
                        <td>{dayjs(c.endDate).format("DD-MMM-YYYY")}</td>
                        <td>
                          {c.description.length > 15
                            ? c.description.slice(0, 15) + "..."
                            : c.description || "—"}
                        </td>

                        {/* Simple active / inactive badge */}
                        <td>
                          <span
                            className={`px-24 py-4 radius-4 fw-medium text-sm ${isActive
                              ? "bg-success-focus text-success-600"
                              : "bg-danger-focus text-danger-600"
                              }`}
                          >
                            {isActive ? "Active" : "Inactive"}
                          </span>
                        </td>

                        {/* Actions */}
                        <td className="text-center">
                          <div className="d-flex gap-10 justify-content-center">
                            {c.isDeleted ? (
                              <button
                                className="bg-info-focus bg-hover-info-200 text-info-600 w-40-px h-40-px rounded-circle d-flex justify-content-center align-items-center"
                                title="Retrieve Coupon"
                                onClick={() => restoreCoupon(c._id)}
                                disabled={loading}
                              >
                                <Icon icon="mdi:backup-restore" />
                              </button>
                            ) : (
                              <>
                                <button
                                  className="bg-success-focus text-success-600 bg-hover-success-200 fw-medium w-40-px h-40-px d-flex justify-content-center align-items-center rounded-circle"
                                  title="Edit Coupon"
                                  onClick={() => {
                                    setModalMode("update");
                                    setModalData(c);
                                    setShowModal(true);
                                  }}
                                  disabled={loading}
                                >
                                  <Icon icon="lucide:edit" />
                                  <span className="tooltip-text">Edit</span>
                                </button>

                                <button
                                  className="bg-danger-focus bg-hover-danger-200 text-danger-600 w-40-px h-40-px rounded-circle d-flex justify-content-center align-items-center"
                                  title="Delete Coupon"
                                  onClick={() => {
                                    if (
                                      window.confirm(
                                        "Do you want to delete this coupon?"
                                      )
                                    ) {
                                      deleteCoupon(c._id)
                                    }
                                  }}
                                  disabled={loading}
                                >
                                  <Icon icon="fluent:delete-24-regular" />
                                  <span className="tooltip-text">Delete</span>
                                </button>
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan="9" className="text-center">
                      No coupons found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* ─────────────────── Pagination ─────────────────── */}
          <Paggination
            total={total}
            totalPages={totalPages}
            currentPage={currentPage}
            startFrom={(currentPage - 1) * query.limitVal + 1}
            endTo={(currentPage - 1) * query.limitVal + coupons.length}
            setPageNo={(page) =>
              setQuery((prev) => ({ ...prev, pageNo: page }))
            }
          />
        </div>
      </div>

      <CouponModal
        show={showModal}
        handleClose={handleModalClose}
        mode={modalMode}
        data={modalData}
      />
    </>
  );
};

export default CouponLayer;