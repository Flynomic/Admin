import { Icon } from "@iconify/react/dist/iconify.js";
import React, { useCallback, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { userPageType, USER_TYPE } from "../utils/enum";
import { TbRestore } from "react-icons/tb";
import debounce from "lodash/debounce";
import useApi from "../hook/useApi";
import Paggination from "./Paggination";
import Loader from "./Loader/Loader";
import { copyToClipboard, trimAddress } from "../utils/helper";
import { IoCopyOutline } from "react-icons/io5";

const UsersListLayer = () => {
  const { AsyncGetApiCall, AsyncDeleteApiCall } = useApi();
  const navigate = useNavigate();
  const [query, setQuery] = useState({
    pageNo: 1,
    limitVal: 50,
    search: "",
    isVerified: null,
  });
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState(null);

  console.log("dataofuser...", data?.data)

  const setPageNo = (pageNo) => {
    setQuery((prev) => ({
      ...prev,
      pageNo: pageNo,
    }));
  };

  const getAllUsersList = async () => {
    setLoading(true);
    const result = await AsyncGetApiCall("/users/list", query);
    console.log("Result:", result);

    if (result.success) {
      setData(result);
    }
    setLoading(false);
  };

  const handleViewUser = (id) => {
    navigate(`/view-user-profile/${id}`, {
      state: { from: userPageType.VIEW },
    });
  };

  const handleEditUser = (id) => {
    navigate(`/edit-user-profile/${id}`, {
      state: { from: userPageType.UPDATE },
    });
  };

  const handleUserStatusChange = async (id) => {
    setLoading(true);
    const result = await AsyncDeleteApiCall(`/users/delete?id=${id}`);

    if (result.errors) {
      toast.error(result.errors[0]);
    } else if (result.success) {
      toast.success(
        `User ${result?.user?.isDeleted ? "deleted" : "restored"} successfully`
      );
      getAllUsersList();
    }
    setLoading(false);
  };

  // Debounced search handler
  const debouncedSearch = useCallback(
    debounce((value) => {
      setQuery((prev) => ({ ...prev, search: value, pageNo: 1 }));
    }, 500),
    []
  );

  const handleSearchUser = (e) => {
    debouncedSearch(e.target.value);
  };

  // Prevent form submission
  const handleFormSubmit = (e) => {
    e.preventDefault(); // Prevent default form submission
  };

  useEffect(() => {
    getAllUsersList();
  }, [query]);

  return (
    <>
      {loading && <Loader />}
      <div className="card h-100 p-0 radius-12">
        <div className="card-header border-bottom bg-base py-16 px-24 d-flex align-items-center flex-wrap gap-3 justify-content-between">
          <div className="d-flex align-items-center flex-wrap gap-3">
            <span className="text-md fw-medium text-secondary-light mb-0">
              Show
            </span>
            <select
              className="form-select form-select-sm w-auto ps-12 py-6 radius-12 h-40-px"
              value={query.limitVal} // Changed from defaultValue to value
              onChange={(e) => {
                const value = parseInt(e.target.value, 10);
                setQuery((prev) => ({
                  ...prev,
                  limitVal: value,
                  pageNo: 1, // Reset to first page on limit change
                }));
              }}
            >
              <option value="5">5</option>
              {Array.from({ length: 20 }, (_, i) => {
                const value = (i + 1) * 5;
                return (
                  <option key={value} value={value}>
                    {value}
                  </option>
                );
              })}
            </select>
            <form className="navbar-search" onSubmit={handleFormSubmit}>
              <input
                type="text"
                className="bg-base h-40-px w-auto"
                name="search"
                placeholder="Search"
                onChange={handleSearchUser}
              />
              <Icon icon="ion:search-outline" className="icon" />
            </form>
            <select
              className="form-select form-select-sm w-auto ps-12 py-6 radius-12 h-40-px"
              value={
                query.isVerified === null
                  ? USER_TYPE.SELECTSTATUS
                  : query.isVerified
                    ? USER_TYPE.ACTIVE
                    : USER_TYPE.INACTIVE
              }
              onChange={(e) => {
                const value = e.target.value;
                setQuery((prev) => ({
                  ...prev,
                  isVerified:
                    value === USER_TYPE.ACTIVE
                      ? true
                      : value === USER_TYPE.INACTIVE
                        ? false
                        : null,
                  pageNo: 1, // Reset to first page on status change
                }));
              }}
            >
              <option value={USER_TYPE.SELECTSTATUS}>
                {USER_TYPE.SELECTSTATUS}
              </option>
              <option value={USER_TYPE.ACTIVE}>{USER_TYPE.ACTIVE}</option>
              <option value={USER_TYPE.INACTIVE}>{USER_TYPE.INACTIVE}</option>
            </select>
          </div>
        </div>

        <div className="card-body p-24">
          <div className="table-responsive scroll-sm">
            <table className="table bordered-table sm-table mb-0">
              <thead>
                <tr>
                  <th scope="col">
                    <div className="d-flex align-items-center gap-10">
                      <div className="form-check style-check d-flex align-items-center"></div>
                      S.No
                    </div>
                  </th>
                  <th scope="col">Name</th>
                  <th scope="col">Email</th>
                  <th scope="col">Contact No.</th>
                  <th scope="col">Wallet Address</th>
                  <th scope="col">Created At</th>
                  <th scope="col" className="text-center">
                    Status
                  </th>
                  <th scope="col" className="text-center">
                    Action
                  </th>
                </tr>
              </thead>
              <tbody>
                {data && data.data?.length > 0 ? (
                  data.data.map((user, index) => (
                    <tr key={user._id}>
                      <td>
                        <div className="d-flex justify-content-center align-items-center gap-10">
                          {(data?.currentPage - 1) * query.limitVal + index + 1}
                        </div>
                      </td>
                      <td>
                        <div className="d-flex align-items-center">
                          <img
                            src="https://wow-dash.com/demo/assets/images/user.png"
                            alt="Wowdash"
                            className="w-40-px h-40-px rounded-circle flex-shrink-0 me-12 overflow-hidden"
                          />
                          <div className="flex-grow-1">
                            <span className="text-md mb-0 fw-normal text-secondary-light">
                              {user.firstName || user.lastName
                                ? `${user.firstName || ""} ${user.lastName || ""
                                  }`.trim()
                                : "N/A"}
                            </span>
                          </div>
                        </div>
                      </td>
                      <td>
                        <span className="text-md mb-0 fw-normal text-secondary-light">
                          {user.email || "N/A"}
                        </span>
                      </td>
                      <td>{user?.phoneNumber ? `${user?.countryCode} ${user?.phoneNumber}` : "N/A"}</td>
                      <td>
                        {trimAddress(user.walletAddress, 6, 6) || "N/A"}
                        {user.walletAddress && (
                          <button
                            onClick={() => copyToClipboard(user.walletAddress)}
                            className="ms-3 p-0 border-0 bg-transparent"
                            style={{ lineHeight: 1 }}
                          >
                            <IoCopyOutline />
                          </button>
                        )}
                      </td>
                      <td>
                        {new Date(user.createdAt).toLocaleString("en-GB", {
                          day: "2-digit",
                          month: "2-digit",
                          year: "numeric",
                          hour: "2-digit",
                          minute: "2-digit",
                          second: "2-digit",
                          hour12: true,
                        })}
                      </td>
                      <td className="text-center">
                        <span
                          className={`${user.isVerified
                            ? "bg-success-focus text-success-600"
                            : "bg-danger-focus text-danger-600"
                            } border px-24 py-4 radius-4 fw-medium text-sm`}
                        >
                          {user.isVerified ? "Active" : "Inactive"}
                        </span>
                      </td>
                      <td className="text-center">
                        <div className="d-flex align-items-center gap-10 justify-content-center">
                          <button
                            type="button"
                            className="bg-info-focus bg-hover-info-200 text-info-600 fw-medium w-40-px h-40-px d-flex justify-content-center align-items-center rounded-circle"
                            onClick={() => handleViewUser(user?._id)}
                          >
                            <Icon
                              icon="majesticons:eye-line"
                              className="icon text-xl"
                            />
                            <span className="tooltip-text">View</span>
                          </button>
                          <button
                            type="button"
                            className="bg-success-focus text-success-600 bg-hover-success-200 fw-medium w-40-px h-40-px d-flex justify-content-center align-items-center rounded-circle"
                            onClick={() => handleEditUser(user?._id)}
                          >
                            <Icon icon="lucide:edit" className="menu-icon" />
                            <span className="tooltip-text">Edit</span>
                          </button>
                          <button
                            type="button"
                            className="remove-item-btn bg-danger-focus bg-hover-danger-200 text-danger-600 fw-medium w-40-px h-40-px d-flex justify-content-center align-items-center rounded-circle"
                            onClick={() => handleUserStatusChange(user?._id)}
                          >
                            {user?.isDeleted ? (
                              <TbRestore />
                            ) : (
                              <Icon
                                icon="fluent:delete-24-regular"
                                className="menu-icon"
                              />
                            )}
                            <span className="tooltip-text">Delete</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="8" className="text-center">
                      No users found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          <Paggination
            total={data?.total || 0}
            totalPages={data?.totalPages || 0}
            currentPage={data?.currentPage || 0}
            setPageNo={setPageNo}
            startFrom={(data?.currentPage - 1) * query.limitVal + 1}
            endTo={
              (data?.currentPage - 1) * query.limitVal + data?.data?.length
            }
          />
        </div>
      </div>
    </>
  );
};

export default UsersListLayer;