import { Icon } from "@iconify/react";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import useApi from "../hook/useApi";
import { toast } from "react-toastify";
import { useAuth } from "../context/AuthContext";
import Loader from "./Loader/Loader";
import { ValidateInputs } from "../utils/helper";

const SignInLayer = () => {
  const { AsyncPostApiCall } = useApi();
  const { login: setAuthToken } = useAuth(); // get login method from context
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    email: localStorage.getItem("data") ? JSON.parse(localStorage.getItem("data"))?.email : "", // admin@mailinator.com
    password: localStorage.getItem("data") ? JSON.parse(localStorage.getItem("data"))?.password : "", // Admin@123
    isChecked: localStorage.getItem("data") ? JSON.parse(localStorage.getItem("data"))?.isChecked : false,
  });
  const [errors, setErrors] = useState({});
  const [passwordVisible, setPasswordVisible] = useState(false);

  const handleValues = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
    const updatedInputs = ValidateInputs(name, value, errors);
    setErrors(updatedInputs);
  };

  const validate = () => {
    const newErrors = {};

    // Validate email
    if (!formData?.email?.trim()) {
      newErrors.email = "Please enter an email address";
    } else if (formData.email.trim().length > 100) {
      newErrors.email = "Email cannot exceed 100 characters";
    } else if (
      !/^[a-zA-Z0-9]+(?:\.[a-zA-Z0-9]+)*@[a-zA-Z0-9]+(?:-[a-zA-Z0-9]+)*\.[a-zA-Z]{2,}$/.test(
        formData.email
      )
    ) {
      newErrors.email = "Please enter a valid email address";
    }

    // Check if password is empty
    if (!formData.password.trim()) {
      newErrors.password = "Password is required";
    } else if (formData.password.length < 8) {
      newErrors.password = "Password must be at least 8 characters long";
    } else if (!/[A-Z]/.test(formData.password)) {
      newErrors.password =
        "Password must contain at least one uppercase letter";
    } else if (!/[a-z]/.test(formData.password)) {
      newErrors.password =
        "Password must contain at least one lowercase letter";
    } else if (!/[0-9]/.test(formData.password)) {
      newErrors.password = "Password must contain at least one number";
    } else if (!/[!@#$%^&*(),.?":{}|<>]/.test(formData.password)) {
      newErrors.password =
        "Password must contain at least one special character";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const login = async (e) => {
    e.preventDefault();
    if (!validate()) {
      return;
    }
    const payload = { email: formData?.email, password: formData?.password };
    setLoading(true);
    const result = await AsyncPostApiCall("/auth/admin-login", payload);

    if (result.errors) {
      toast.error(result.errors[0]);
    } else if (result.accessToken) {
      setAuthToken(result.accessToken, result.admin); // save token to localStorage and context
      toast.success("You have successfully logged in.");
      if (formData?.isChecked) {
        localStorage.setItem("data", JSON.stringify(formData));
      }
      navigate("/dashboard"); // redirect to dashboard or home
      setErrors({});
    }
    setLoading(false);
  };

  return (
    <>
      {loading && <Loader />}

      <section className="auth bg-base d-flex flex-wrap">
        <div className="auth-left d-lg-block d-none">
          <div className="d-flex align-items-center flex-column h-100 justify-content-center">
            <img src="assets/images/signup.svg" alt="Login Visual" />
          </div>
        </div>
        <div className="auth-right py-32 px-24 d-flex flex-column justify-content-center">
          <div className="max-w-464-px mx-auto w-100">
            <div>
              <Link to="/" className="mb-40 max-w-290-px d-block">
                <img src="assets/images/logo.svg" alt="Logo" />
              </Link>
              <h4 className="mb-12">Sign In to your Account</h4>
              <p className="mb-32 text-secondary-light text-lg">
                Welcome back! Please enter your details
              </p>
            </div>

            <form onSubmit={login}>
              <div className="icon-field mb-16">
                <span className="icon top-50 translate-middle-y">
                  <Icon icon="mage:email" />
                </span>
                <input
                  name="email"
                  type="email"
                  className={`form-control h-56-px bg-neutral-50 radius-12 ${errors.email ? "is-invalid" : ""
                    }`}
                  placeholder="Email"
                  value={formData?.email}
                  onChange={handleValues}
                // required
                />
                {errors.email && (
                  <div className="invalid-feedback">{errors.email}</div>
                )}
              </div>

              <div className="position-relative mb-20">
                <div className="icon-field" style={{ display: "flex" }}>
                  <span className="icon top-50 translate-middle-y">
                    <Icon icon="solar:lock-password-outline" />
                  </span>
                  <input
                    name="password"
                    type={passwordVisible ? "text" : "password"}
                    className={`form-control h-56-px bg-neutral-50 radius-12 ${errors.password ? "is-invalid" : ""
                      }`}
                    id="your-password"
                    placeholder="Password"
                    value={formData?.password}
                    onChange={handleValues}
                  />
                  <span
                    type="button"
                    className="icon password-eye-icon top-50 translate-middle-y"
                    style={{
                      position: "absolute",
                      left: "auto",
                      right: `${errors.password ? "1em" : "0"} `,
                    }}
                    onClick={() => setPasswordVisible(!passwordVisible)}
                  >
                    <Icon
                      icon={
                        passwordVisible
                          ? "solar:eye-closed-bold"
                          : "solar:eye-bold"
                      }
                    />
                  </span>
                </div>
                {errors.password && (
                  <div className="invalid-feedback d-block">
                    {errors.password}
                  </div>
                )}
              </div>

              <div className="d-flex justify-content-between gap-2">
                <div className="form-check style-check d-flex align-items-center">
                  <input
                    className="form-check-input border border-neutral-300"
                    type="checkbox"
                    id="remember"
                    onChange={handleValues}
                    name="isChecked"
                    checked={formData.isChecked}
                  />
                  <label className="form-check-label" htmlFor="remember">
                    Remember me
                  </label>
                </div>
                <Link
                  to="/forgot-password"
                  className="text-primary-600 fw-medium"
                >
                  Forgot Password?
                </Link>
              </div>

              <button
                type="submit"
                className="btn btn-primary text-sm btn-sm px-12 py-16 w-100 radius-12 mt-32"
              >
                Sign In
              </button>
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default SignInLayer;
