import React, { useCallback, useEffect, useState } from "react";
import { Icon } from "@iconify/react";
import { toast } from "react-toastify";
import { debounce } from "lodash";
import dayjs from "dayjs";

import useApi from "../hook/useApi";
import Loader from "./Loader/Loader";
import Paggination from "./Paggination";
import NotificationModal from "./model/NotificationModal";

const MAX_FETCH_LIMIT = 100000000000000000; // Arbitrary high limit to fetch all notifications

const NotificationLayer = () => {
  /* ─────────────────────────────────────────────────────────────── *
   *  STATE & HOOKS
   * ─────────────────────────────────────────────────────────────── */
  const [response, setResponse] = useState(null); // full API payload
  const [loading, setLoading] = useState(false);

  // modal (create / update)
  const [showModal, setShowModal] = useState(false);
  const [modalMode, setModalMode] = useState("create"); // "create" | "update"
  const [modalData, setModalData] = useState(null);

  // API query for search
  const [search, setSearch] = useState("");

  // Local pagination state
  const [localPage, setLocalPage] = useState(1);
  const [localLimit, setLocalLimit] = useState(10);

  const {
    AsyncGetApiCall,
    AsyncDeleteApiCall,
    AsyncPatchAPICall,
  } = useApi();

  /* ─────────────────────────────────────────────────────────────── *
   *  DATA FETCH
   * ─────────────────────────────────────────────────────────────── */
  const fetchNotifications = async () => {
    setLoading(true);
    const apiQuery = {
      pageNo: 1,
      limitVal: MAX_FETCH_LIMIT,
      search,
    };
    const res = await AsyncGetApiCall("/notifications/admin/list", apiQuery);
    if (res?.errors) {
      toast.error(res.errors[0]);
    } else {
      setResponse(res);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchNotifications();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search]);

  /* ─────────────────────────────────────────────────────────────── *
   *  SEARCH (debounced)
   * ─────────────────────────────────────────────────────────────── */
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const debouncedSearch = useCallback(
    debounce((value) => {
      setSearch(value);
      setLocalPage(1); // Reset to first page on search
    }, 500),
    []
  );
  const handleSearchChange = (e) => debouncedSearch(e.target.value);

  /* ─────────────────────────────────────────────────────────────── *
   *  ACTIONS
   * ─────────────────────────────────────────────────────────────── */
  const markAsRead = async (id) => {
    setLoading(true);
    const targetNotification = response?.data?.find((n) => n._id === id);
    if (targetNotification?.role === "admin") {
      const key = `${dayjs(targetNotification.createdAt).format('YYYY-MM-DD HH:mm')}-${targetNotification.title}-${targetNotification.body}`;
      // Find all admin notifications with the same key
      const relatedNotifications = response?.data?.filter(
        (n) => {
          if (n.role !== "admin") return false;
          const nKey = `${dayjs(n.createdAt).format('YYYY-MM-DD HH:mm')}-${n.title}-${n.body}`;
          return nKey === key;
        }
      ) || [];
      // Update all related notifications
      const updatePromises = relatedNotifications.map((n) =>
        AsyncPatchAPICall(`/notifications/update/${n._id}`, {
          isRead: true,
        })
      );
      const results = await Promise.allSettled(updatePromises);
      results.forEach((result) => {
        if (result.status === "rejected" || result.value?.errors) {
          toast.error(result.value?.errors?.[0] || "Update failed");
        }
      });
    } else {
      // Update single notification
      const res = await AsyncPatchAPICall(`/notifications/update/${id}`, {
        isRead: true,
      });
      if (res?.errors) {
        toast.error(res.errors[0]);
      }
    }
    fetchNotifications();
    setLoading(false);
  };

  /* ─────────────────────────────────────────────────────────────── *
   *  MODAL CLOSE HANDLER
   * ─────────────────────────────────────────────────────────────── */
  const handleModalClose = (shouldRefresh = false) => {
    setShowModal(false);
    setModalData(null);
    if (shouldRefresh) fetchNotifications();
  };

  /* ─────────────────────────────────────────────────────────────── *
   *  DERIVED
   * ─────────────────────────────────────────────────────────────── */
  const notifications = response?.data ?? [];

  const updatedNotification = (() => {
    const groups = {};
    notifications.forEach((curr) => {
      if (curr.role === "admin" && curr.createdAt) {
        const key = `${dayjs(curr.createdAt).format('YYYY-MM-DD HH:mm')}-${curr.title}-${curr.body}`;
        if (!groups[key]) {
          groups[key] = [];
        }
        groups[key].push(curr);
      }
    });

    const consolidated = notifications.filter(
      (curr) => curr.role !== "admin" || !curr.createdAt
    );

    Object.values(groups).forEach((group) => {
      if (group.length > 0) {
        const rep = { ...group[0], userId: "All-User" };
        rep.isRead = group.every((n) => n.isRead);
        consolidated.push(rep);
      }
    });

    // Sort by createdAt descending to maintain order
    return consolidated.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  })();

  // Recalculate pagination based on updatedNotification
  const totalItems = updatedNotification.length;
  const calculatedTotalPages = Math.ceil(totalItems / localLimit);

  // Sliced list for current local page
  const paginatedNotifications = updatedNotification.slice(
    (localPage - 1) * localLimit,
    localPage * localLimit
  );

  /* ─────────────────────────────────────────────────────────────── *
   *  RENDER
   * ─────────────────────────────────────────────────────────────── */
  return (
    <>
      {loading && <Loader />}
      <div className="card h-100 p-0 radius-12">
        {/* ───── Header ───── */}
        <div className="card-header border-bottom bg-base py-16 px-24 d-flex flex-wrap gap-3 justify-content-between">
          <div className="d-flex align-items-center gap-3 flex-wrap w-100">
            {/* Limit selector */}
            <span className="text-md fw-medium text-secondary-light">Show</span>
            <select
              className="form-select form-select-sm w-auto ps-12 py-6 radius-12 h-40-px"
              value={localLimit}
              onChange={(e) => {
                setLocalLimit(Number(e.target.value));
                setLocalPage(1);
              }}
            >
              {Array.from({ length: 20 }, (_, i) => (i + 1) * 5).map((v) => (
                <option key={v} value={v}>
                  {v}
                </option>
              ))}
            </select>

            {/* Search */}
            <div className="navbar-search">
              <input
                type="text"
                className="bg-base h-40-px w-auto"
                placeholder="Search by title / body"
                onChange={handleSearchChange}
              />
              <Icon icon="ion:search-outline" className="icon" />
            </div>

            {/* Add button */}
            <button
              type="button"
              className="btn btn-primary-600 radius-8 px-17 py-9 d-flex align-items-center gap-2 ms-auto"
              disabled={loading}
              onClick={() => {
                setModalMode("create");
                setModalData(null);
                setShowModal(true);
              }}
            >
              <Icon icon="mdi:bell-plus-outline" style={{ fontSize: 20 }} />
              Create&nbsp;Notification
            </button>
          </div>
        </div>

        {/* ───── Table ───── */}
        <div className="card-body p-24">
          <div className="table-responsive scroll-sm">
            <table className="table bordered-table sm-table mb-0">
              <thead>
                <tr>
                  <th>S.No</th>
                  <th>User Id</th>
                  <th>Title</th>
                  <th>Body</th>
                  <th>Role</th>
                  <th>Read</th>
                  <th>Created&nbsp;At</th>
                  <th style={{ textAlign: "center" }}>Action</th>
                </tr>
              </thead>

              <tbody>
                {paginatedNotifications.length ? (
                  paginatedNotifications.map((n, i) => {
                    const rowNo = (localPage - 1) * localLimit + i + 1;
                    return (
                      <tr key={n._id}>
                        <td>{rowNo}</td>
                        <td>{n.userId}</td>
                        <td>{n.title}</td>
                        <td>
                          {n.body.length > 40
                            ? `${n.body.slice(0, 40)}…`
                            : n.body}
                        </td>
                        <td className="text-capitalize">{n.role || "—"}</td>
                        <td>
                          <span
                            className={`px-20 py-3 radius-4 fw-medium text-sm ${n.isRead
                              ? "bg-success-focus text-success-600"
                              : "bg-warning-focus text-warning-700"
                              }`}
                          >
                            {n.isRead ? "Read" : "Unread"}
                          </span>
                        </td>
                        <td>{dayjs(n.createdAt).format("DD-MMM-YYYY HH:mm")}</td>

                        {/* Actions */}
                        <td className="text-center">
                          <div className="d-flex gap-10 justify-content-center">
                            {!n.isRead ? (
                              <button
                                className="bg-success-focus bg-hover-success-200 text-success-600 w-40-px h-40-px rounded-circle d-flex justify-content-center align-items-center"
                                title="Mark as read"
                                onClick={() => markAsRead(n._id)}
                                disabled={loading}
                              >
                                <Icon icon="mdi:check-bold" />
                                <span className="tooltip-text">Read</span>
                              </button>
                            ) : (
                              <span>Done</span>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan="8" className="text-center">
                      No notifications found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* ───── Pagination ───── */}
          <Paggination
            total={totalItems}
            totalPages={calculatedTotalPages}
            currentPage={localPage}
            startFrom={(localPage - 1) * localLimit + 1}
            endTo={Math.min(localPage * localLimit, totalItems)}
            setPageNo={setLocalPage}
          />
        </div>
      </div>

      {/* ───── Modal ───── */}
      <NotificationModal
        show={showModal}
        handleClose={handleModalClose}
        mode={modalMode}
        data={modalData}
      />
    </>
  );
};

export default NotificationLayer;
