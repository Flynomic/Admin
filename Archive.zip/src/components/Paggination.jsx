import { Icon } from "@iconify/react/dist/iconify.js";
import React from "react";
import { Link } from "react-router-dom";

const Paggination = ({
  total,
  totalPages,
  currentPage,
  setPageNo,
  startFrom,
  endTo,
}) => {
  return (
    <div>
      {total > 0 && (
        <div className="d-flex align-items-center justify-content-between flex-wrap gap-2 mt-24">
          <span>
            Showing {startFrom} to {endTo} of {total} entries
          </span>
          <ul className="pagination d-flex flex-wrap align-items-center gap-2 justify-content-center">
            {currentPage !== 1 && (
              <li
                className="page-item"
                onClick={() => {
                  setPageNo(1);
                }}
              >
                <Link
                  className="page-link bg-neutral-200 text-secondary-light fw-semibold radius-8 border-0 d-flex align-items-center justify-content-center h-32-px  text-md"
                  to="#"
                >
                  <Icon icon="ep:d-arrow-left" className="" />
                </Link>
              </li>
            )}

            {Array.from({ length: totalPages }, (_, i) => {
              const page = i + 1;
              const isActive = page === currentPage;
              return (
                <li
                  className="page-item"
                  key={i}
                  onClick={() => {
                    setPageNo(page);
                  }}
                >
                  <Link
                    className={`page-link ${
                      isActive
                        ? "text-white bg-primary-600"
                        : "text-secondary-light"
                    } fw-semibold radius-8 border-0 d-flex align-items-center justify-content-center h-32-px w-32-px text-md ${
                      isActive && "bg-primary-600 text-white"
                    }`}
                    to="#"
                  >
                    {page}
                  </Link>
                </li>
              );
            })}

            {currentPage !== totalPages && (
              <li
                className="page-item"
                onClick={() => {
                  setPageNo(totalPages);
                }}
              >
                <Link
                  className="page-link bg-neutral-200 text-secondary-light fw-semibold radius-8 border-0 d-flex align-items-center justify-content-center h-32-px  text-md"
                  to="#"
                >
                  {" "}
                  <Icon icon="ep:d-arrow-right" className="" />{" "}
                </Link>
              </li>
            )}
          </ul>
        </div>
      )}
    </div>
  );
};

export default Paggination;
