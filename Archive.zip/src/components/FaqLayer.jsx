import React, { useEffect, useState } from "react";
import AddFaqModal from "./model/AddFaqModal";
import useApi from "../hook/useApi";
import { toast } from "react-toastify";
import { FAQTAG, PLATFORM_TYPE } from "../utils/enum";
import { Icon } from "@iconify/react/dist/iconify.js";
import Paggination from "./Paggination";
import Loader from "./Loader/Loader";

const FaqLayer = () => {
  const {
    AsyncPostApiCall,
    AsyncGetApiCall,
    AsyncDeleteApiCall,
    AsyncPatchAPICall,
  } = useApi();
  const [faqs, setFaqs] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [currentTask, setCurrentTask] = useState(null);
  const [loading, setLoading] = useState(false);
  const [activeTag, setActiveTag] = useState(FAQTAG.ABOUT_US);
  const [selectedFaqId, setSelectedFaqId] = useState(null);
  // const [platformType, setPlatformType] = useState(PLATFORM_TYPE.ICO);
  const [query, setQuery] = useState({
    pageNo: 1,
    limitVal: 10,
    webType: PLATFORM_TYPE.ICO,
  });
  const [data, setData] = useState(null);

  const setPageNo = (pageNo) => {
    setQuery((prev) => ({
      ...prev,
      pageNo: pageNo,
    }));
  };

  useEffect(() => {
    getFaqData();
  }, [query]);

  console.log("query : ", query);

  const getFaqData = async () => {
    setLoading(true);
    try {
      const result = await AsyncGetApiCall("/cmspage/get-faqs", query);
      console.log("API result:", result);
      if (result.success && Array.isArray(result.data)) {
        const faqsWithIds = result.data.map((faq) => ({
          ...faq,
          id: faq._id, // Map _id to id for consistency
        }));
        setFaqs(faqsWithIds);
        setData(result);
      } else {
        toast.error("Failed to fetch FAQs");
      }
    } catch (error) {
      console.error("Error fetching FAQs:", error);
      toast.error("An error occurred while fetching FAQs");
    } finally {
      setLoading(false);
    }
  };

  const handleSaveTask = async (task, isEdit) => {
    setLoading(true);
    try {
      if (isEdit) {
        const id = task.id; // Preserve ID for state update
        const taskPayload = { ...task, _id: id };
        delete taskPayload.id; // Remove id from payload
        const response = await AsyncPatchAPICall(
          `/cmspage/update-faq/${id}`,
          taskPayload
        );
        if (response.success && response.faq) {
          const updatedFaq = {
            ...response.faq,
            id: response.faq._id, // Map _id to id
          };
          setFaqs((prev) =>
            prev.map((faq) => (faq.id === id ? updatedFaq : faq))
          );
          toast.success("FAQ updated successfully");
          setSelectedFaqId(null); // Clear selection after edit
        } else {
          toast.error(response.errors?.[0]);
        }
      } else {
        const result = await AsyncPostApiCall("/cmspage/create-faq", task);
        if (result.success && result.data) {
          const newFaq = {
            ...result.data,
            id: result.data._id, // Map _id to id
          };
          setFaqs((prev) => [...prev, newFaq]);
          toast.success("FAQ created successfully");
        } else {
          toast.error(result.errors?.[0] || "Failed to create FAQ");
        }
      }
    } catch (error) {
      console.error("Error saving FAQ:", error);
      toast.error("An error occurred while saving FAQ");
    } finally {
      setLoading(false);
      setShowModal(false);
    }
  };

  const handleEdit = () => {
    if (!selectedFaqId) {
      toast.info("Please select an FAQ to edit");
      return;
    }
    const faqToEdit = faqs.find((faq) => faq.id === selectedFaqId);

    if (faqToEdit) {
      setCurrentTask(faqToEdit);
      setShowModal(true);
    }
  };

  const handleDelete = async () => {
    if (!selectedFaqId) {
      toast.info("Please select an FAQ to delete");
      return;
    }
    if (!window.confirm("Are you sure you want to delete this FAQ?")) return;
    setLoading(true);
    try {
      const response = await AsyncDeleteApiCall(`/cmspage/delete-faq`, {
        id: selectedFaqId,
      });
      if (response.success) {
        setFaqs((prev) => prev.filter((faq) => faq.id !== selectedFaqId));
        toast.success("FAQ deleted successfully");
        setSelectedFaqId(null);
      } else {
        toast.error(response.errors?.[0] || "Failed to delete FAQ");
      }
    } catch (error) {
      console.error("Error deleting FAQ:", error);
      toast.error("An error occurred while deleting FAQ");
    } finally {
      setLoading(false);
    }
  };

  const handleSelectFaq = (faqId) => {
    setSelectedFaqId((prev) => (prev === faqId ? null : faqId)); // Toggle selection
  };

  const renderFaqs = () => {
    if (!faqs.length) {
      return (
        <p className="text-secondary-light">
          No FAQs available for this platform.
        </p>
      );
    }
    return faqs.map((faq, index) => (
      <div className="accordion-item" key={faq.id}>
        <h2 className="accordion-header" id={`header-${faq.id}`}>
          <button
            className={`accordion-button text-primary-light text-xl ${index !== 0 ? "collapsed" : ""
              }`}
            type="button"
            data-bs-toggle="collapse"
            data-bs-target={`#collapse-${faq.id}`}
            aria-expanded={index === 0}
            aria-controls={`collapse-${faq.id}`}
          >
            <div className="d-flex align-items-center justify-content-between w-100 gap-2">
              <span>{faq.question}</span>
              <button
                type="button"
                className={`btn btn-sm ${selectedFaqId === faq.id
                  ? "btn-primary-600"
                  : "btn-outline-secondary"
                  }`}
                onClick={(e) => {
                  e.stopPropagation();
                  handleSelectFaq(faq.id);
                }}
                aria-label={
                  selectedFaqId === faq.id ? "Deselect FAQ" : "Select FAQ"
                }
                aria-pressed={selectedFaqId === faq.id}
              >
                <Icon
                  icon="mdi:check-circle"
                  className="text-lg"
                  style={{
                    color: selectedFaqId === faq.id ? "white" : "inherit",
                  }}
                />
              </button>
            </div>
          </button>
        </h2>
        <div
          id={`collapse-${faq.id}`}
          className={`accordion-collapse collapse ${index === 0 ? "show" : ""}`}
          aria-labelledby={`header-${faq.id}`}
          data-bs-parent="#accordion-faqs"
        >
          <div className="accordion-body">{faq.answer}</div>
        </div>
      </div>
    ));
  };

  const handlePlatformChange = (e) => {
    const selected = e.target.value;
    console.log("Selected platform:", selected);
    setQuery((prev) => ({
      ...prev,
      webType: selected,
    }));
  };

  return (
    <div className="card basic-data-table">


      <div
        style={{
          display: "flex",
          justifyContent: "flex-end",
          alignItems: "center",
          padding: "10px",
          gap: "10px",
        }}
      >
        <div>
          <select
            className="form-select w-auto px-20 py-12 radius-8 border border-gray-300"
            style={{ height: "48px", backgroundColor: "white" }}
            value={query.webType}
            onChange={handlePlatformChange}
          >
            <option value="Select Status" disabled>
              Select Platform
            </option>
            <option value={PLATFORM_TYPE.ICO}>ICO</option>
            <option value={PLATFORM_TYPE.TRAVEL}>TRAVEL</option>
          </select>
        </div>
        <button
          type="button"
          className="btn btn-primary-600 radius-8 px-20 py-11 d-flex align-items-center gap-2"
          onClick={() => {
            setCurrentTask(null);
            setShowModal(true);
          }}
          disabled={loading}
          aria-label="Add new FAQ"
        >
          <Icon icon="mingcute:square-arrow-left-line" className="text-xl" />
          Add FAQ
        </button>
        <button
          type="button"
          className="btn btn-success-600 radius-8 px-20 py-11 d-flex align-items-center gap-2"
          onClick={handleEdit}
          disabled={loading || !selectedFaqId}
          aria-label="Edit selected FAQ"
        >
          <Icon icon="lucide:edit" className="text-xl" />
          Edit FAQ
        </button>
        <button
          type="button"
          className="btn btn-danger-600 radius-8 px-20 py-11 d-flex align-items-center gap-2"
          onClick={handleDelete}
          disabled={loading || !selectedFaqId}
          aria-label="Delete selected FAQ"
        >
          <Icon icon="fluent:delete-24-regular" className="text-xl" />
          Delete FAQ
        </button>
      </div>
      <div className="card-body bg-base responsive-padding-40-150">
        <div className="row gy-4">
          <div className="col-lg-8">
            <div className="accordion" id="accordion-faqs">
              {loading ? (
                <Loader />
              ) : (
                renderFaqs()
              )}
            </div>
          </div>
        </div>
      </div>
      <AddFaqModal
        show={showModal}
        handleClose={() => setShowModal(false)}
        handleSave={handleSaveTask}
        task={currentTask}
        loading={loading}
        faqs={faqs}
      />
      <Paggination
        total={data?.totalFAQs || 0}
        totalPages={data?.totalPages || 0}
        currentPage={data?.currentPage || 0}
        setPageNo={setPageNo}
        startFrom={(data?.currentPage - 1) * query.limitVal + 1}
        endTo={(data?.currentPage - 1) * query.limitVal + data?.data?.length}
      />
    </div>
  );
};

export default FaqLayer;
