import { Icon } from "@iconify/react";
import React, { useCallback, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import useApi from "../../hook/useApi";
import { toast } from "react-toastify";
import Loader from "../Loader/Loader";
import Paggination from "../Paggination";
import { debounce } from "lodash";
import AddFaqModal from "../model/AddFaqModal";
import AddBlogModal from "../model/AddBlogModel";
import { MdOutlineAddCard } from "react-icons/md";
import { ValidateInputs } from "../../utils/helper";

const BlogLayer = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [limitVal, setLimitVal] = useState("10");
  const [pageNo, setPageNo] = useState(1);
  const [search, setSearch] = useState("");
  const [query, setQuery] = useState({
    pageNo: 1,
    limitVal: 5,
    search: "",
  });
  const [showModal, setShowModal] = useState(false);
  const { AsyncGetApiCall, AsyncDeleteApiCall } = useApi();
  const navigate = useNavigate();

  const fetchBlogs = async () => {
    setLoading(true);

    const result = await AsyncGetApiCall(`/blogs/list/`, query);

    if (result?.errors) {
      toast.error(result.errors[0]);
    } else if (result?.data) {
      setData(result);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchBlogs();
  }, [query, showModal]);

  const debouncedSearch = useCallback(
    debounce((value) => {
      setQuery((prev) => ({ ...prev, search: value, pageNo: 1 }));
    }, 500),
    []
  );

  const handleSearchChange = (e) => {
    debouncedSearch(e.target.value);
  };

  const handleEditBlog = (id) => {
    console.log("handleId", id);
    navigate("/blog/edit-blog/" + id);
  };

  const deleteBlog = async (id) => {
    setLoading(true);
    const result = await AsyncDeleteApiCall(`/blogs/delete/${id}`);

    if (result.errors) {
      toast.error(result.errors[0]);
    } else if (result.success) {
      toast.success(`Blog deleted successfully`);
      fetchBlogs();
    }
    setLoading(false);
  };

  return (
    <>
      {loading && <Loader />}
      <div className="card h-100 p-0 radius-12">
        <div className="card-header border-bottom bg-base py-16 px-24 d-flex align-items-center flex-wrap gap-3 justify-content-between">
          <div className="d-flex align-items-center justify-content-between gap-3 w-100">
            <div className="d-flex align-items-center gap-3">
              <span className="text-md fw-medium text-secondary-light mb-0">
                Show
              </span>
              <select
                className="form-select form-select-sm w-auto ps-12 py-6 radius-12 h-40-px"
                defaultValue="Select Number"
                onChange={(e) => {
                  const value = parseInt(e.target.value, 10);
                  setQuery((prev) => ({
                    ...prev,
                    limitVal: value,
                  }));
                }}
              >
                <option value="5">Select Number</option>
                {Array.from({ length: 20 }, (_, i) => {
                  const value = (i + 1) * 5;
                  return (
                    <option key={value} value={value}>
                      {value}
                    </option>
                  );
                })}
              </select>
              <form className="navbar-search">
                <input
                  type="text"
                  className="bg-base h-40-px w-auto"
                  placeholder="Search"
                  // value={search}
                  onChange={handleSearchChange}
                  name="search"
                />
                <Icon icon="ion:search-outline" className="icon" />
              </form>
            </div>
            <div>
              <button
                type="button"
                className="btn btn-primary-600 radius-8 px-17 py-9 d-flex align-items-center gap-2"
                onClick={() => {
                  setShowModal(true);
                }}
                disabled={loading}
                aria-label="Add new Blog"
              >
                <MdOutlineAddCard className="text-xl" />
                Add Blog
              </button>
            </div>
          </div>
        </div>

        <div className="card-body p-24">
          <div className="table-responsive scroll-sm">
            <table className="table bordered-table sm-table mb-0">
              <thead>
                <tr>
                  <th>S.No</th>
                  <th>Title</th>
                  <th>Category</th>
                  <th>Content</th>
                  <th style={{ textAlign: "center" }}>Action</th>
                </tr>
              </thead>
              <tbody>
                {data?.data && data?.data.length > 0 ? (
                  data?.data.map((blog, index) => (
                    <tr key={blog._id}>
                      <td>{(pageNo - 1) * limitVal + index + 1}</td>
                      <td>{blog.title}</td>
                      <td>{blog.category}</td>
                      <td>
                        {blog.content.split(" ").length > 10
                          ? blog.content.split(" ").slice(0, 10).join(" ") +
                            "..."
                          : blog.content}
                      </td>
                      <td className="text-center">
                        <div className="d-flex align-items-center gap-10 justify-content-center">
                          <button
                            type="button"
                            className="bg-success-focus text-success-600 bg-hover-success-200 fw-medium w-40-px h-40-px d-flex justify-content-center align-items-center rounded-circle"
                            onClick={() => handleEditBlog(blog._id)}
                          >
                            <Icon icon="lucide:edit" className="menu-icon" />
                          </button>
                          <button
                            type="button"
                            className="remove-item-btn bg-danger-focus bg-hover-danger-200 text-danger-600 fw-medium w-40-px h-40-px d-flex justify-content-center align-items-center rounded-circle"
                            onClick={() => deleteBlog(blog._id)}
                          >
                            <Icon
                              icon="fluent:delete-24-regular"
                              className="menu-icon"
                            />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="5" className="text-center">
                      No blogs found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          {/* <div className="d-flex justify-content-center mt-3"> */}
          <Paggination
            total={data?.total || 0}
            totalPages={data?.totalPages || 0}
            currentPage={data?.currentPage || 0}
            setPageNo={setPageNo}
            startFrom={(data?.currentPage - 1) * query.limitVal + 1}
            endTo={
              (data?.currentPage - 1) * query.limitVal + data?.data?.length
            }
          />
          {/* </div> */}
          <AddBlogModal
            show={showModal}
            handleClose={() => setShowModal(false)}
            loading={loading}
          />
        </div>
      </div>
    </>
  );
};

export default BlogLayer;
