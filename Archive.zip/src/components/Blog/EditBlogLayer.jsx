import { Icon } from "@iconify/react/dist/iconify.js";
import React, { useEffect, useRef, useState } from "react";
import useApi from "../../hook/useApi";
import Loader from "../Loader/Loader";
import { toast } from "react-toastify";
import ReactQuill from "react-quill-new";
import hljs from "highlight.js";
import { stripHtml, ValidateInputs } from "../../utils/helper";
import { blogCategories } from "../../utils/enum";
import { useNavigate } from "react-router-dom";

const EditBlogLayer = ({ id }) => {
  console.log("id", id);
  const { AsyncGetApiCall, AsyncPatchApiCall } = useApi();
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState({
    title: "",
    content: "",
    category: "",
  });
  const [errors, setErrors] = useState({});
  const quillRef = useRef(null);
  const [isHighlightReady, setIsHighlightReady] = useState(false);
  const navigate = useNavigate();

  const getBlog = async () => {
    setLoading(true);
    const result = await AsyncGetApiCall(`/blogs/${id}`);
    console.log("blog", result);

    if (result.success && result.blog) {
      setData(result.blog); // assuming result.blog has { title, content, category, isActive }
    }
    setLoading(false);
  };

  // Quill editor modules with syntax highlighting (only load if highlight.js is ready)
  const modules = isHighlightReady
    ? {
        syntax: {
          highlight: (text) => hljs?.highlightAuto(text).value, // Enable highlight.js in Quill
        },
        toolbar: {
          container: "#toolbar-container", // Custom toolbar container
        },
      }
    : {
        toolbar: {
          container: "#toolbar-container", // Custom toolbar container
        },
      };

  const formats = [
    "font",
    "size",
    "bold",
    "italic",
    "underline",
    "strike",
    "color",
    "background",
    "script",
    "header",
    "blockquote",
    "code-block",
    "list",
    "indent",
    "direction",
    "align",
    "link",
    "image",
    "video",
    "formula",
  ];

  useEffect(() => {
    getBlog();
  }, [id]);

  const handleValues = (e) => {
    const { name, value } = e.target;

    setData((prev) => ({
      ...prev,
      [name]: value,
    }));

    // Update error for category immediately
    if (name === "category" && value === "") {
      setErrors((prev) => ({
        ...prev,
        category: "Category is required",
      }));
    } else {
      // clear error if selected valid category
      setErrors((prev) => ({
        ...prev,
        [name]: "",
      }));
    }

    const updatedInputs = ValidateInputs(name, value, errors);
    setErrors((prev) => ({
      ...prev,
      ...updatedInputs,
    }));
  };

  const validateBlogForm = () => {
    const newErrors = {};

    const plainTextContent = stripHtml(data?.content).trim();
    console.log("plainTextContent", plainTextContent);
    // Title: required
    if (!data?.title.trim()) {
      newErrors.title = "Title is required";
    }

    // Content: required
    if (!plainTextContent) {
      newErrors.content = "Content is required";
    }

    // Category: required
    if (!data?.category.trim()) {
      newErrors.category = "Category is required";
    }

    // No need to validate isActive (user can only pick from dropdown)

    setErrors(newErrors);
    console.log("errors of content", errors.content);
    return Object.keys(newErrors).length === 0;
  };

  const updateBlog = async (e) => {
    console.log("clicked");
    e.preventDefault();
    if (!validateBlogForm()) {
      return;
    }
    setLoading(true);
    const cleanedContent = stripHtml(data?.content).trim();

    const result = await AsyncPatchApiCall(`/blogs/update/${id}`, {
      ...data,
      content: cleanedContent,
    });
    console.log("result", result);

    if (result.errors) {
      toast.error(result.errors[0]);
    } else if (result.success && result.blog) {
      setData(result.blog); // assuming result.blog has updated blog data
      toast.success("Blog Data Updated Successfully.");
      navigate("/blog");
    }
    setLoading(false);
  };

  return (
    <>
      {loading && <Loader />}
      <div className="col-md-6">
        <div className="card" style={{ width: "200%" }}>
          <div className="card-header">
            <h5 className="card-title mb-0">Edit Blog</h5>
          </div>
          <div className="card-body">
            <form onSubmit={updateBlog}>
              <div className="row gy-3">
                {/* Title */}
                <div className="col-12">
                  <label className="form-label">Title</label>
                  <div className="icon-field d-flex flex-column align-items-center gap-2">
                    <input
                      type="text"
                      className={`form-control ${
                        errors.title ? "is-invalid" : ""
                      }`}
                      name="title"
                      value={data?.title}
                      onChange={handleValues}
                      placeholder="Enter blog title"
                    />
                    {errors.title && (
                      <div className="invalid-feedback">{errors.title}</div>
                    )}
                  </div>
                </div>

                {/* Category */}
                <div className="col-12">
                  <label className="form-label">Category</label>
                  <div className="icon-field d-flex flex-column align-items-center gap-2">
                    <select
                      className={`form-select ${
                        errors.category ? "is-invalid" : ""
                      }`}
                      name="category"
                      value={data?.category}
                      onChange={handleValues}
                    >
                      <option value="">Select a category</option>
                      <option value={blogCategories.TECHNICAL}>
                        {blogCategories.TECHNICAL.charAt(0).toUpperCase() +
                          blogCategories.TECHNICAL.slice(1).toLowerCase()}
                      </option>
                      <option value={blogCategories.LIFESTYLE}>
                        {blogCategories.LIFESTYLE.charAt(0).toUpperCase() +
                          blogCategories.LIFESTYLE.slice(1).toLowerCase()}
                      </option>
                      <option value={blogCategories.FINANCE}>
                        {blogCategories.FINANCE.charAt(0).toUpperCase() +
                          blogCategories.FINANCE.slice(1).toLowerCase()}
                      </option>
                    </select>
                    {errors.category && (
                      <div className="invalid-feedback">{errors.category}</div>
                    )}
                  </div>
                </div>

                {/* Content */}
                <div className="col-12">
                  <label className="form-label">Content</label>

                  <div
                    className={`card-body p-0 ${
                      errors.content ? "is-invalid" : ""
                    }`}
                  >
                    {/* Editor Toolbar */}
                    <div id="toolbar-container">
                      <span className="ql-formats">
                        <select className="ql-font"></select>
                        <select className="ql-size"></select>
                      </span>
                      <span className="ql-formats">
                        <button className="ql-bold"></button>
                        {/* <button className="ql-italic"></button>
                        <button className="ql-underline"></button>
                        <button className="ql-strike"></button> */}
                      </span>
                      <span className="ql-formats">
                        <select className="ql-color"></select>
                        <select className="ql-background"></select>
                      </span>
                      <span className="ql-formats">
                        <button className="ql-script" value="sub"></button>
                        <button className="ql-script" value="super"></button>
                      </span>
                      <span className="ql-formats">
                        <button className="ql-header" value="1"></button>
                        <button className="ql-header" value="2"></button>
                        <button className="ql-blockquote"></button>
                        <button className="ql-code-block"></button>
                      </span>
                      <span className="ql-formats">
                        {/* <button className="ql-list" value="ordered"></button>
                        <button className="ql-list" value="bullet"></button> */}
                        <button className="ql-indent" value="-1"></button>
                        <button className="ql-indent" value="+1"></button>
                      </span>
                      <span className="ql-formats">
                        <button className="ql-direction" value="rtl"></button>
                        <select className="ql-align"></select>
                      </span>
                      <span className="ql-formats">
                        <button className="ql-link"></button>
                        <button className="ql-image"></button>
                        <button className="ql-video"></button>
                        <button className="ql-formula"></button>
                      </span>
                      <span className="ql-formats">
                        <button className="ql-clean"></button>
                      </span>
                    </div>

                    {/* Quill Editor */}
                    <ReactQuill
                      ref={quillRef}
                      theme="snow"
                      value={data?.content}
                      onChange={(content) =>
                        handleValues({
                          target: { name: "content", value: content },
                        })
                      }
                      modules={modules}
                      formats={formats}
                      placeholder="Start Your Blog here..."
                      name="content"
                    />
                  </div>
                  {errors.content && (
                    <div className="invalid-feedback">{errors.content}</div>
                  )}
                </div>

                {/* Submit button */}
                <div className="col-12">
                  <button type="submit" className="btn btn-primary">
                    Save
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default EditBlogLayer;
