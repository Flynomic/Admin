import React, { useEffect, useState } from "react";
import useApi from "../../hook/useApi";

import { useNavigate } from "react-router-dom";
import Loader from "../Loader/Loader";
import { FaRegEdit } from "react-icons/fa";
import { Icon } from "@iconify/react/dist/iconify.js";

const MarkupListLayer = () => {
  const { AsyncGetApiCall } = useApi();
  const navigate = useNavigate();

  const [query, setQuery] = useState({
    pageNo: 1,
    limitVal: 5,
    search: "",
  });

  const [loading, setLoading] = useState(false);
  const [data, setData] = useState(null);

  const getAllMarkupsList = async () => {
    setLoading(true);
    const result = await AsyncGetApiCall("/markups/list", query);
    console.log("Result status: ", result);
    console.log("Result activation: ", result?.data?.isActive);

    if (result.success) {
      setData(result);
    }
    setLoading(false);
  };

  const setPageNo = (pageNo) => {
    setQuery((prev) => ({
      ...prev,
      pageNo: pageNo,
    }));
  };

  useEffect(() => {
    getAllMarkupsList();
  }, [query]);

  console.log("data : ", data);

  return (
    <>
      {loading && <Loader />}
      <div className="card h-100 p-0 radius-12">
        <div className="card-body p-24">
          <div className="table-responsive scroll-sm">
            <table className="table bordered-table sm-table mb-0">
              <thead>
                <tr>
                  <th scope="col">
                    <div className="d-flex align-items-center gap-10">S.No</div>
                  </th>
                  <th scope="col">Type</th>
                  <th scope="col">Value</th>
                  <th scope="col">Type</th>
                  <th scope="col">Activation Status</th>
                  <th scope="col" className="text-center">
                    Action
                  </th>
                </tr>
              </thead>
              <tbody>
                {data && data.data.length > 0 ? (
                  data.data.map((item, index) => (
                    <tr key={item._id}>
                      <td>
                        <div className="d-flex align-items-center gap-10">
                          {(data?.currentPage - 1) * query.limitVal + index + 1}
                        </div>
                      </td>
                      <td>{item?.type?.charAt(0).toUpperCase() + item?.type.slice(1)}</td>
                      <td>{item?.value}</td>
                      <td>{item?.mode?.charAt(0).toUpperCase() + item?.mode.slice(1)}</td>
                      <td>{item?.isActive ? "Active" : "Inactive"}</td>
                      <td className="text-center">
                        <div className="d-flex align-items-center gap-10 justify-content-center">
                          <button
                            type="button"
                            className="bg-success-focus text-success-600 bg-hover-success-200 fw-medium w-40-px h-40-px d-flex justify-content-center align-items-center rounded-circle"
                            onClick={() => {
                              navigate("/markups/edit-markup/" + item._id);
                            }}>
                            <Icon icon="lucide:edit" className="menu-icon" />
                            <span className="tooltip-text">Edit</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="6" className="text-center">
                      No data found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          {/* <Paggination
            total={data?.total || 0}
            totalPages={data?.totalPages || 0}
            currentPage={data?.currentPage || 0}
            setPageNo={setPageNo}
            startFrom={(data?.currentPage - 1) * query.limitVal + 1}
            endTo={
              (data?.currentPage - 1) * query.limitVal + data?.data?.length
            }
          /> */}
        </div>
      </div>
    </>
  );
};

export default MarkupListLayer;
