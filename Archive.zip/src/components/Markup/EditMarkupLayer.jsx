import { Icon } from "@iconify/react/dist/iconify.js";
import React, { useEffect, useState } from "react";
import useApi from "../../hook/useApi";
import Loader from "../Loader/Loader";
import { activeStatus, percentMode } from "../../utils/enum";
import { ValidateInputs } from "../../utils/helper";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";

const EditMarkupLayer = ({ id }) => {
  const { AsyncGetApiCall, AsyncPatchAPICall } = useApi();
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState({
    value: "",
    mode: "",
    isActive: false,
  });
  const [errors, setErrors] = useState({});
  const [markupType, setMarkupType] = useState("");
  const [markupAmountType, setMarkupAmountType] = useState("");
  const navigate = useNavigate();

  const getMarkup = async () => {
    setLoading(true);
    const result = await AsyncGetApiCall(`/markups/${id}`);
    console.log("result", result);

    if (result.success && result.markup) {
      setData(result.markup); // assuming result.data has { type, value, mode, isActive }
      console.log("markup", result.markup)
      const markupTypeValue = result?.markup?.type.charAt(0).toUpperCase() + result?.markup?.type.slice(1)
      setMarkupType(markupTypeValue)
      setMarkupAmountType(result?.markup?.mode.charAt(0).toUpperCase() + result?.markup?.mode.slice(1))
    }
    setLoading(false);
  };

  useEffect(() => {
    getMarkup();
  }, []);

  const handleValues = (e) => {
    const { name, value } = e.target;
    console.log("value", name, typeof (value), value);

    // Clamp the value to 1–50
    let newValue = value === "" ? "" : Math.max(1, Math.min(50, Number(value) || 0));

    // Update data state with clamped value
    setData((prev) => ({
      ...prev,
      [name]: name === "isActive" ? value === "true" : newValue,
    }));

    // Validate and update errors
    const updatedInputs = ValidateInputs(name, newValue, errors); // Use clamped value for validation
    setErrors((prev) => {
      if (name === "value") {
        if (newValue === "" || isNaN(Number(newValue))) {
          return { ...prev, value: "Value is required and must be a number" };
        } else if (Number(newValue) < 1 || Number(newValue) > 50) {
          return { ...prev, value: "Value must be between 1 and 50" };
        } else {
          return { ...prev, value: "" }; // Clear error if valid
        }
      }
      return { ...prev, ...updatedInputs };
    });
  };

  const validateMarkupForm = () => {
    const newErrors = {};

    // Value: required and must be positive number
    if (!data?.value) {
      newErrors.value = "Value is required";
    } else if (isNaN(data.value) || Number(data.value) <= 0) {
      newErrors.value = "Value must be a positive number";
    }

    // Mode: required
    if (!data?.mode.trim()) {
      newErrors.mode = "Mode is required";
    } else if (
      data.mode !== percentMode.PERCENTAGE &&
      data.mode !== percentMode.FIXED
    ) {
      newErrors.mode = "Invalid mode selected";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const updateMarkup = async (e) => {
    e.preventDefault();
    if (!validateMarkupForm()) {
      return;
    }
    setLoading(true);
    console.log("data", data)
    const result = await AsyncPatchAPICall(`/markups/update/${id}`, data);
    console.log("result", result);

    if (result.errors) {
      toast.error(result.errors[0]);
    } else if (result.success && result.markup) {
      setData(result.markup); // assuming result.data has { type, value, mode, isActive }
      const markupTypeValue = result?.markup?.type.charAt(0).toUpperCase() + result?.markup?.type.slice(1)
      setMarkupType(markupTypeValue)
      setMarkupAmountType(result?.markup?.mode.charAt(0).toUpperCase() + result?.markup?.mode.slice(1))
      toast.success("Markup Data Updated Successfully.");
    }
    getMarkup();
    setLoading(false);
    navigate("/markups")
  };

  return (
    <>
      {loading && <Loader />}
      <div className="col-md-6">
        <div className="card">
          <div className="card-header">
            <h5 className="card-title mb-0">Edit Markup</h5>
          </div>
          <div className="card-body">
            <form onSubmit={updateMarkup}>
              <div className="row gy-3">
                {/* Type */}
                <div className="col-12">
                  <label className="form-label">Type</label>
                  <div className="d-flex align-items-center gap-2">
                    <input
                      type="text"
                      className="form-control"
                      name="type"
                      value={markupType}
                      disabled
                    />
                  </div>
                </div>

                {/* Value */}
                <div className="col-12">
                  <label className="form-label">Value</label>
                  <div className="d-flex flex-column salign-items-center gap-2">
                    <input
                      type="number"
                      className={`form-control radius-8 ${errors.value ? "is-invalid" : ""
                        }`}
                      name="value"
                      value={data?.value}
                      onChange={handleValues}
                      placeholder="Enter value"
                      min={1}
                      max={50}
                      onKeyDown={(e) => {
                        // Prevent typing negative numbers or 'e' (exponential)
                        if (["e", "E", "+", "-"].includes(e.key)) {
                          e.preventDefault();
                        }
                      }}
                    />
                    {errors.value && (
                      <div className="invalid-feedback">{errors.value}</div>
                    )}
                  </div>
                </div>

                {/* Mode */}
                <div className="col-12">
                  <label className="form-label">Mode</label>
                  <div className="icon-field d-flex flex-column align-items-center gap-2">
                    {/* <select
                      name="mode"
                      className={`form-control radius-8 ${errors.mode ? "is-invalid" : ""
                        }`}
                      value={markupAmountType}
                      onChange={handleValues}>
                      <option value="">Select Mode</option>
                      <option value={percentMode?.PERCENTAGE}>
                        {percentMode?.PERCENTAGE.charAt(0).toUpperCase() + percentMode?.PERCENTAGE.slice(1)}
                      </option>
                      <option value={percentMode?.FIXED}>
                        {percentMode?.FIXED.charAt(0).toUpperCase() + percentMode?.FIXED.slice(1)}
                      </option>
                    </select> */}

                    <input
                      type="text"
                      className="form-control"
                      name="mode"
                      value={markupAmountType}
                      disabled
                    />
                    {errors.mode && (
                      <div className="invalid-feedback">{errors.mode}</div>
                    )}
                  </div>
                </div>

                {/* Activation Status */}
                <div className="col-12">
                  <label className="form-label">Activation Status</label>
                  <div className="d-flex flex-column align-items-center gap-2">
                    <select
                      name="isActive"
                      className={`form-control radius-8 ${errors.isActive ? "is-invalid" : ""
                        }`}
                      value={data.isActive}
                      onChange={handleValues}>
                      <option value="">Select Status</option>
                      <option value={activeStatus.ACTIVE}>Active</option>
                      <option value={activeStatus.INACTIVE}>Inactive</option>
                    </select>
                    {errors.isActive && (
                      <div className="invalid-feedback">{errors.isActive}</div>
                    )}
                  </div>
                </div>

                {/* Submit button */}
                <div className="col-12">
                  <button type="submit" className="btn btn-primary">
                    Save
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default EditMarkupLayer;
