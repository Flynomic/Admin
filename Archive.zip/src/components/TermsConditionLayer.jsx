import React, { useEffect, useRef, useState } from "react";

import useApi from "../hook/useApi";
import { toast } from "react-toastify";
import Loader from "./Loader/Loader";
import { CMS_WEBSITE_TYPE, PAGE_TYPE, PLATFORM_TYPE } from "../utils/enum";
import { stripHtml } from "../utils/helper";
import JoditEditor from "jodit-react";

const TermsConditionLayer = () => {
  const { AsyncGetApiCall, AsyncPatchAPICall } = useApi();
  const [errors, setErrors] = useState({});
  const editor = useRef(null);
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState({ title: "", content: "" });
  const [platformType, setPlatformType] = useState(PLATFORM_TYPE.ICO);

  const getData = async () => {
    setLoading(true);
    const url = "/cmspage/get-page";

    const query = {
      pageType: PAGE_TYPE.TERMS_AND_CONDITIONS,
      webType:
        platformType === PLATFORM_TYPE.ICO
          ? CMS_WEBSITE_TYPE.ICO
          : CMS_WEBSITE_TYPE.TRAVEL,
    };

    const result = await AsyncGetApiCall(url, query);
    console.log("API result:", result);
    if (result.success) {
      setData(result.data);
    } else {
      toast.error(result.errors[0]);
    }
    setLoading(false);
  };

  useEffect(() => {
    getData();
  }, [platformType]);

  const handleContentChange = (content) => {
    console.log("content", content)
    setData((prev) => ({ ...prev, content }));

    // Validate content on change
    const plainTextContent = stripHtml(content).trim();
    console.log("plainTextContent", plainTextContent)
    if (!plainTextContent) {
      setErrors((prev) => ({
        ...prev,
        content: "Content is required",
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    const plainTextContent = stripHtml(data.content).trim();

    if (!plainTextContent) {
      newErrors.content = "Content is required";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = async () => {
    if (!validateForm()) {
      toast.error("Please fill in all required fields");
      return;
    }

    setLoading(true);
    const result = await AsyncPatchAPICall(
      `/cmspage/update-page/${data?._id}`,
      {
        title: data?.title,
        content: data?.content,
      }
    );
    if (result.success) {
      setData(result.data);
      toast.success("Content updated successfully");
    } else {
      toast.error(result.errors[0]);
    }
    setLoading(false);
  };

  const handlePlatformChange = (e) => {
    const selected = e.target.value;
    console.log("Selected platform:", selected);
    setPlatformType(selected);
  };

  const editorConfig = {
    placeholder: stripHtml(data.content).trim() ? "" : "Start typing...",
    // ...other config options
  };

  return (
    <>
      {loading && <Loader />}
      <div className="mb-3">
        <select
          className="form-select form-select-sm w-auto ps-12 py-6 radius-12 h-40-px"
          defaultValue="Select Status"
          value={platformType}
          onChange={handlePlatformChange}
        >
          <option value="Select Status" disabled>
            Select Platform
          </option>
          <option value={PLATFORM_TYPE.ICO}>ICO</option>
          <option value={PLATFORM_TYPE.TRAVEL}>TRAVEL</option>
        </select>
      </div>
      <div className="card basic-data-table radius-12 overflow-hidden">
        <div className="card-body p-0">
          <div className={errors.content ? "is-invalid" : ""}>
            <JoditEditor
              ref={editor}
              value={data?.content}
              config={{ placeholder: "Start typing..." }}
              onBlur={handleContentChange}
            />
            {errors.content && (
              <div className="invalid-feedback">{errors.content}</div>
            )}
          </div>
        </div>

        <div className="card-footer p-24 bg-base border border-bottom-0 border-end-0 border-start-0">
          <div className="d-flex align-items-center justify-content-center gap-3">
            <button
              type="button"
              className="border border-danger-600 bg-hover-danger-200 text-danger-600 text-md px-50 py-11 radius-8"
            >
              Cancel
            </button>
            <button
              type="button"
              className="btn btn-primary border border-primary-600 text-md px-28 py-12 radius-8"
              onClick={handleSave}
            >
              Save Changes
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default TermsConditionLayer;
